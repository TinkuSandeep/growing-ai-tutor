#!/bin/sh

set -eu

exec python3 -m autosys_phase1.source_check \
  --settings /opt/batch-dashboard/config/settings.yaml \
  --write
