#!/bin/sh

set -eu

exec python3 -m autosys_phase1.reset_job_times \
  --settings /opt/batch-dashboard/config/settings.yaml
