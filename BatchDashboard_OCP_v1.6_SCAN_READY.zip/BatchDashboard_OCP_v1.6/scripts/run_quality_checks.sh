#!/usr/bin/env sh
set -eu

python -m compileall -q src tests
python -m coverage run --source=src/autosys_phase1 -m pytest
python -m coverage xml -o coverage.xml
