from __future__ import annotations

import argparse
import json
import logging
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

from .config import DatabaseSettings, load_settings
from .database import SQLServerRepository
from .errors import DatabaseError


@dataclass(frozen=True)
class ProcedureTask:
    description: str
    file_stem: str
    logger_name: str
    procedure_attribute: str
    repository_action: Callable[[SQLServerRepository], None]
    start_message: str
    success_message: str
    failure_message: str
    passed_result: str
    failed_result: str
    update_field: str


def _arguments(task: ProcedureTask) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=task.description)
    parser.add_argument("--settings", default="config/settings.yaml")
    parser.add_argument("--env-file", default=".env")
    return parser.parse_args()


def _json_default(value: object) -> str:
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(type(value).__name__)


def _configure_logging(name: str, log_path: Path | None) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    if log_path is not None:
        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    return logger


def _procedure_name(database: DatabaseSettings, attribute: str) -> str:
    value = getattr(database, attribute, None)
    if not isinstance(value, str) or not value:
        raise DatabaseError(f"Procedure configuration is missing: {attribute}")
    return value


def run_task(task: ProcedureTask) -> int:
    args = _arguments(task)
    load_dotenv(args.env_file, override=False)
    settings = load_settings(args.settings)

    timezone = ZoneInfo(settings.autosys.timezone)
    started = datetime.now(timezone)
    stamp = started.strftime("%Y%m%d_%H%M%S_%f")
    report_path: Path | None = None
    log_path: Path | None = None
    if settings.ingestion.file_output_enabled:
        output_dir = Path(settings.ingestion.output_directory)
        log_dir = Path(settings.ingestion.log_directory)
        output_dir.mkdir(parents=True, exist_ok=True)
        log_dir.mkdir(parents=True, exist_ok=True)
        report_path = output_dir / f"{task.file_stem}_{stamp}.json"
        log_path = log_dir / f"{task.file_stem}_{stamp}.log"
    logger = _configure_logging(task.logger_name, log_path)

    procedure = _procedure_name(settings.database, task.procedure_attribute)
    logger.info(task.start_message, procedure)
    error: str | None = None
    try:
        task.repository_action(SQLServerRepository(settings.database))
        logger.info(task.success_message, procedure)
    except DatabaseError as exc:
        error = str(exc)
        logger.error("%s error=%s", task.failure_message, error)

    completed = datetime.now(timezone)
    result = task.passed_result if error is None else task.failed_result
    report = {
        "version": "1.6.0",
        "result": result,
        "stored_procedure": procedure,
        "started_at_et": started,
        "completed_at_et": completed,
        task.update_field: error is None,
        "error": error,
    }
    if report_path is not None:
        report_path.write_text(
            json.dumps(report, indent=2, default=_json_default), encoding="utf-8"
        )
        logger.info("Report written to %s", report_path)
        logger.info("Log written to %s", log_path)

    output = {
        "result": result,
        "stored_procedure": procedure,
        task.update_field: error is None,
        "error": error,
        "report": str(report_path) if report_path is not None else None,
        "log": str(log_path) if log_path is not None else None,
    }
    print(json.dumps(output, indent=2))
    return 0 if error is None else 1


TASKS = {
    "summary": ProcedureTask(
        description="Refresh the database-owned critical batch summary",
        file_stem="summary_refresh",
        logger_name="batch_dashboard_summary_refresh",
        procedure_attribute="summary_stored_procedure",
        repository_action=SQLServerRepository.refresh_summary,
        start_message="Starting summary refresh through %s",
        success_message="Committed summary refresh through %s",
        failure_message="SUMMARY REFRESH FAILED",
        passed_result="SUMMARY_REFRESH_PASSED",
        failed_result="SUMMARY_REFRESH_FAILED",
        update_field="summary_database_updated",
    ),
    "stream": ProcedureTask(
        description="Refresh critical batch stream status, completion and SLA values",
        file_stem="stream_refresh",
        logger_name="batch_dashboard_stream_refresh",
        procedure_attribute="stream_stored_procedure",
        repository_action=SQLServerRepository.refresh_stream,
        start_message="Starting stream refresh through %s",
        success_message="Committed stream refresh through %s",
        failure_message="STREAM REFRESH FAILED",
        passed_result="STREAM_REFRESH_PASSED",
        failed_result="STREAM_REFRESH_FAILED",
        update_field="stream_database_updated",
    ),
    "reset": ProcedureTask(
        description="Reset Batch Dashboard job start and end times",
        file_stem="reset_job_times",
        logger_name="batch_dashboard_reset_job_times",
        procedure_attribute="reset_stored_procedure",
        repository_action=SQLServerRepository.reset_job_times,
        start_message="Starting daily job-time reset through %s",
        success_message="Committed daily job-time reset through %s",
        failure_message="JOB-TIME RESET FAILED",
        passed_result="JOB_TIME_RESET_PASSED",
        failed_result="JOB_TIME_RESET_FAILED",
        update_field="job_times_reset",
    ),
}


def run_named_task(name: str) -> int:
    try:
        task = TASKS[name]
    except KeyError as exc:
        raise DatabaseError(f"Unknown procedure task: {name}") from exc
    return run_task(task)
