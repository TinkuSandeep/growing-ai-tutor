from .procedure_runner import run_named_task


def main() -> int:
    return run_named_task("reset")


if __name__ == "__main__":
    raise SystemExit(main())
