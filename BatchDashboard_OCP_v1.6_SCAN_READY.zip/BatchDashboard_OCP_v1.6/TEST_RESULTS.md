# Version 1.6 validation results

Validation date: 2026-10-02

- Python compilation: passed.
- Automated tests: **29 passed**.
- Application-owned authentication identifiers use identity/credential terminology.
- AEWS error messages do not include upstream response content.
- Shared procedure runner removes the duplicated summary, stream and reset logic.
- Reset procedure configuration and SQL command generation: passed.
- Reset transaction commit and rollback behavior: passed.
- AutoSys API certificate path contract: `/mnt/ssl_dir/prdautosys.crt`.
- SQL Server encryption and certificate identity validation are enabled with
  `trust_server_certificate: false`.
- The AutoSys example schedules ingestion every 15 minutes.
- The independent daily reset calls `dbo.cp_Reset_Job_Times` at 12:05 AM Eastern.

Validation command:

```bash
python3 -m pytest -q
```

Production database writes, AEWS connectivity, certificate-chain validation,
image scanning and AutoSys/OCP agent registration must still be validated in the
approved target environment.
