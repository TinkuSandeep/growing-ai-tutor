from argparse import Namespace

import pytest

from autosys_phase1.config import load_settings
from autosys_phase1.errors import DatabaseError
from autosys_phase1.procedure_runner import ProcedureTask, _procedure_name, run_task


def _task(action):
    return ProcedureTask(
        description="Test task",
        file_stem="test_task",
        logger_name="batch_dashboard_test_task",
        procedure_attribute="summary_stored_procedure",
        repository_action=action,
        start_message="Starting test through %s",
        success_message="Committed test through %s",
        failure_message="TEST FAILED",
        passed_result="TEST_PASSED",
        failed_result="TEST_FAILED",
        update_field="database_updated",
    )


def _prepare(monkeypatch):
    settings = load_settings("config/settings.yaml")
    monkeypatch.setattr(
        "autosys_phase1.procedure_runner._arguments",
        lambda task: Namespace(settings="config/settings.yaml", env_file=".env"),
    )
    monkeypatch.setattr(
        "autosys_phase1.procedure_runner.load_settings", lambda path: settings
    )
    monkeypatch.setattr(
        "autosys_phase1.procedure_runner.load_dotenv", lambda *args, **kwargs: False
    )


def test_procedure_name_rejects_missing_configuration():
    settings = load_settings("config/settings.yaml")
    with pytest.raises(DatabaseError, match="Procedure configuration is missing"):
        _procedure_name(settings.database, "missing_attribute")


def test_runner_returns_zero_and_emits_success(monkeypatch, capsys):
    _prepare(monkeypatch)
    called = []

    def action(repository):
        called.append(repository)

    assert run_task(_task(action)) == 0
    assert called
    assert '"result": "TEST_PASSED"' in capsys.readouterr().out


def test_runner_returns_one_and_emits_failure(monkeypatch, capsys):
    _prepare(monkeypatch)

    def action(repository):
        raise DatabaseError("controlled test failure")

    assert run_task(_task(action)) == 1
    output = capsys.readouterr().out
    assert '"result": "TEST_FAILED"' in output
    assert "controlled test failure" in output
