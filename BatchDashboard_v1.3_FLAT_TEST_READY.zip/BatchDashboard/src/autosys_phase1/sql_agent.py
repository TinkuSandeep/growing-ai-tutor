from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from .errors import DatabaseError, DataValidationError
from .source_config import SQLAgentSourceSettings


SQL_AGENT_STATUS = {
    0: "FA",
    1: "SU",
    2: "RE",
    3: "CA",
    4: "RU",
}


@dataclass(frozen=True)
class SQLAgentRun:
    execution_id: int
    job_start_time: datetime | None
    job_end_time: datetime | None
    job_status: str


def duration_to_seconds(value: int) -> int:
    """Convert SQL Agent HHMMSS duration, including durations over 24 hours."""
    raw = int(value)
    hours = raw // 10000
    minutes = (raw % 10000) // 100
    seconds = raw % 100
    if minutes > 59 or seconds > 59:
        raise DataValidationError(f"Invalid SQL Agent run_duration: {value}")
    return hours * 3600 + minutes * 60 + seconds


def normalize_sql_agent_status(value: Any) -> str:
    try:
        code = int(value)
    except (TypeError, ValueError) as exc:
        raise DataValidationError(f"Invalid SQL Agent run_status: {value!r}") from exc
    try:
        return SQL_AGENT_STATUS[code]
    except KeyError as exc:
        raise DataValidationError(f"Unsupported SQL Agent run_status: {code}") from exc


def _convert_time(
    value: datetime | None,
    source_timezone: str,
    output_timezone: str,
    naive: bool,
) -> datetime | None:
    if value is None:
        return None
    source_zone = ZoneInfo(source_timezone)
    output_zone = ZoneInfo(output_timezone)
    aware = value.replace(tzinfo=source_zone) if value.tzinfo is None else value
    converted = aware.astimezone(output_zone)
    return converted.replace(tzinfo=None) if naive else converted


class SQLAgentClient:
    """Read-only SQL Server Agent runtime client."""

    def __init__(self, settings: SQLAgentSourceSettings):
        self.settings = settings

    def _connect(self):
        try:
            import pyodbc
        except ImportError as exc:
            raise DatabaseError(
                "pyodbc is required for SAPBI SQL Agent checks; "
                "install requirements-sqlserver.txt"
            ) from exc
        try:
            return pyodbc.connect(
                self.settings.connection_string(),
                autocommit=True,
                timeout=30,
            )
        except Exception as exc:
            raise DatabaseError(f"SAPBI SQL Agent connection failed: {exc}") from exc

    def get_latest_run(self, job_name: str) -> SQLAgentRun:
        running_sql = """
            SELECT TOP (1)
                a.start_execution_date
            FROM msdb.dbo.sysjobactivity AS a
            INNER JOIN msdb.dbo.sysjobs AS j ON a.job_id = j.job_id
            WHERE a.session_id = (SELECT MAX(session_id) FROM msdb.dbo.syssessions)
              AND j.name = ?
              AND a.start_execution_date IS NOT NULL
              AND a.stop_execution_date IS NULL
            ORDER BY a.start_execution_date DESC
        """
        completed_sql = """
            SELECT TOP (1)
                h.instance_id,
                msdb.dbo.agent_datetime(h.run_date, h.run_time) AS start_time,
                h.run_duration,
                h.run_status
            FROM msdb.dbo.sysjobs AS j
            INNER JOIN msdb.dbo.sysjobhistory AS h ON j.job_id = h.job_id
            WHERE j.name = ?
              AND h.step_id = 0
            ORDER BY h.instance_id DESC
        """
        exists_sql = "SELECT COUNT(*) FROM msdb.dbo.sysjobs WHERE name = ?"

        connection = self._connect()
        try:
            cursor = connection.cursor()
            running = cursor.execute(running_sql, job_name).fetchone()
            if running:
                start = _convert_time(
                    running[0],
                    self.settings.server_timezone,
                    self.settings.output_timezone,
                    self.settings.store_naive_local_time,
                )
                return SQLAgentRun(
                    execution_id=-1,
                    job_start_time=start,
                    job_end_time=None,
                    job_status="RU",
                )

            completed = cursor.execute(completed_sql, job_name).fetchone()
            if not completed:
                exists = int(cursor.execute(exists_sql, job_name).fetchone()[0])
                if not exists:
                    raise DataValidationError(f"SQL Agent job does not exist: {job_name}")
                raise DataValidationError(
                    f"SQL Agent job has no completed execution history: {job_name}"
                )

            execution_id = int(completed[0])
            raw_start = completed[1]
            duration = duration_to_seconds(int(completed[2]))
            status = normalize_sql_agent_status(completed[3])
            raw_end = raw_start + timedelta(seconds=duration) if raw_start else None
            start = _convert_time(
                raw_start,
                self.settings.server_timezone,
                self.settings.output_timezone,
                self.settings.store_naive_local_time,
            )
            end = _convert_time(
                raw_end,
                self.settings.server_timezone,
                self.settings.output_timezone,
                self.settings.store_naive_local_time,
            )
            return SQLAgentRun(execution_id, start, end, status)
        except (DatabaseError, DataValidationError):
            raise
        except Exception as exc:
            raise DatabaseError(f"SQL Agent query failed for {job_name}: {exc}") from exc
        finally:
            connection.close()


class MockSQLAgentClient:
    def __init__(self, fixture_path: str | Path):
        with Path(fixture_path).open("r", encoding="utf-8") as handle:
            self.payload = json.load(handle)

    def get_latest_run(self, job_name: str) -> SQLAgentRun:
        if job_name not in self.payload:
            raise DataValidationError(f"Mock SQL Agent fixture has no entry for {job_name}")
        row = self.payload[job_name]
        start = datetime.fromisoformat(row["job_start_time"]) if row.get("job_start_time") else None
        end = datetime.fromisoformat(row["job_end_time"]) if row.get("job_end_time") else None
        return SQLAgentRun(
            execution_id=int(row.get("execution_id", -1)),
            job_start_time=start,
            job_end_time=end,
            job_status=str(row["job_status"]),
        )
