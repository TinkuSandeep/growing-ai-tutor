from __future__ import annotations

import argparse
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

from .aews import AEWSClient, MockAEWSClient
from .config import load_settings
from .models import TargetJob
from .source_config import SourceJob, load_source_check_settings
from .sql_agent import MockSQLAgentClient, SQLAgentClient
from .transform import latest_runtime_update


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read-only ODIN AEWS and SAPBI SQL Agent source validation"
    )
    parser.add_argument("--config", default="config/source_jobs.yaml")
    parser.add_argument("--settings", default="config/settings.yaml")
    parser.add_argument("--env-file", default=".env")
    parser.add_argument(
        "--source",
        choices=("all", "aews", "sql_agent"),
        default="all",
        help="Limit validation to one source type",
    )
    parser.add_argument("--mock-aews", help="AEWS JSON fixture for offline testing")
    parser.add_argument("--mock-sql-agent", help="SQL Agent JSON fixture for offline testing")
    return parser.parse_args()


def _json_default(value: Any):
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(type(value).__name__)


def _configure_logging(log_path: Path) -> logging.Logger:
    logger = logging.getLogger("source_check")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger


def _base_result(job: SourceJob) -> dict[str, Any]:
    return {
        "app_id": job.app_id,
        "batch_stream_name": job.batch_stream_name,
        "job_name": job.job_name,
        "source": job.source,
        "instance": job.instance,
    }


def main() -> int:
    args = _arguments()
    load_dotenv(args.env_file, override=False)
    app_settings = load_settings(args.settings)
    source_settings = load_source_check_settings(args.config)
    selected = [
        job
        for job in source_settings.jobs
        if args.source == "all" or job.source == args.source
    ]

    output_dir = Path(source_settings.output_directory)
    log_dir = Path(source_settings.log_directory)
    output_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    now = datetime.now(ZoneInfo(source_settings.sql_agent.output_timezone))
    # Microseconds prevent back-to-back ODIN and SAPBI checks from overwriting
    # one another when they start within the same second.
    stamp = now.strftime("%Y%m%d_%H%M%S_%f")
    report_path = output_dir / f"source_validation_{stamp}.json"
    log_path = log_dir / f"source_validation_{stamp}.log"
    logger = _configure_logging(log_path)

    aews = None
    aews_setup_error: Exception | None = None
    if any(job.source == "aews" for job in selected):
        try:
            aews = MockAEWSClient(args.mock_aews) if args.mock_aews else AEWSClient(app_settings.autosys)
        except Exception as exc:
            aews_setup_error = exc
    sql_agent = None
    sql_agent_setup_error: Exception | None = None
    if any(job.source == "sql_agent" for job in selected):
        try:
            sql_agent = (
                MockSQLAgentClient(args.mock_sql_agent)
                if args.mock_sql_agent
                else SQLAgentClient(source_settings.sql_agent)
            )
        except Exception as exc:
            sql_agent_setup_error = exc

    logger.info("Starting read-only source validation for %d jobs", len(selected))
    results: list[dict[str, Any]] = []
    failed = 0
    for job in selected:
        result = _base_result(job)
        try:
            if job.source == "aews":
                if aews_setup_error:
                    raise aews_setup_error
                target = TargetJob(
                    app_id=job.app_id,
                    batch_stream_name=job.batch_stream_name,
                    job_name=job.job_name,
                    instance=job.instance or app_settings.autosys.default_instance,
                )
                payload = aews.get_job_runs(target)
                update = latest_runtime_update(
                    target,
                    payload,
                    app_settings.autosys.timezone,
                    app_settings.autosys.store_naive_local_time,
                )
                result.update(
                    {
                        "execution_id": update.run_number,
                        "job_start_time_et": update.job_start_time,
                        "job_end_time_et": update.job_end_time,
                        "job_status": update.job_status,
                    }
                )
            else:
                if sql_agent_setup_error:
                    raise sql_agent_setup_error
                run = sql_agent.get_latest_run(job.job_name)
                result.update(
                    {
                        "execution_id": run.execution_id,
                        "job_start_time_et": run.job_start_time,
                        "job_end_time_et": run.job_end_time,
                        "job_status": run.job_status,
                    }
                )
            result["result"] = "PASSED"
            logger.info("PASSED source=%s job=%s status=%s", job.source, job.job_name, result["job_status"])
        except Exception as exc:  # preserve the other source results
            failed += 1
            result.update({"result": "FAILED", "error": str(exc)})
            logger.error("FAILED source=%s job=%s error=%s", job.source, job.job_name, exc)
        results.append(result)

    completed = datetime.now(ZoneInfo(source_settings.sql_agent.output_timezone))
    report = {
        "result": "SOURCE_TEST_PASSED" if failed == 0 else "SOURCE_TEST_FAILED",
        "started_at_et": now,
        "completed_at_et": completed,
        "requested": len(selected),
        "succeeded": len(selected) - failed,
        "failed": failed,
        "target_database_connected": False,
        "target_database_updated": False,
        "jobs": results,
    }
    report_path.write_text(
        json.dumps(report, indent=2, default=_json_default),
        encoding="utf-8",
    )
    logger.info("Report written to %s", report_path)
    logger.info("Log written to %s", log_path)
    print(json.dumps({
        "result": report["result"],
        "requested": report["requested"],
        "succeeded": report["succeeded"],
        "failed": report["failed"],
        "report": str(report_path),
        "log": str(log_path),
    }, indent=2))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
