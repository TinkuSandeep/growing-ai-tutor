from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .errors import ConfigurationError


@dataclass(frozen=True)
class SourceJob:
    app_id: str
    batch_stream_name: str
    job_name: str
    source: str
    instance: str | None = None


@dataclass(frozen=True)
class SQLAgentSourceSettings:
    connection_string_env: str
    server_timezone: str
    output_timezone: str
    store_naive_local_time: bool

    def connection_string(self) -> str:
        value = os.getenv(self.connection_string_env, "").strip()
        if not value:
            raise ConfigurationError(
                f"Required environment variable is not set: {self.connection_string_env}"
            )
        return value


@dataclass(frozen=True)
class SourceCheckSettings:
    jobs: tuple[SourceJob, ...]
    sql_agent: SQLAgentSourceSettings
    output_directory: str
    log_directory: str


def load_source_check_settings(path: str | Path) -> SourceCheckSettings:
    with Path(path).open("r", encoding="utf-8") as handle:
        raw: Any = yaml.safe_load(handle) or {}
    if not isinstance(raw, dict):
        raise ConfigurationError("Source configuration root must be a YAML mapping")

    output = raw.get("output", {}) or {}
    sql = raw.get("sql_agent", {}) or {}
    raw_jobs = raw.get("jobs", []) or []
    if not isinstance(raw_jobs, list) or not raw_jobs:
        raise ConfigurationError("source_jobs.yaml must contain a non-empty jobs list")

    jobs: list[SourceJob] = []
    seen: set[tuple[str, str]] = set()
    for position, item in enumerate(raw_jobs, start=1):
        if not isinstance(item, dict):
            raise ConfigurationError(f"Job entry {position} must be a YAML mapping")
        source = str(item.get("source", "")).strip().lower()
        if source not in {"aews", "sql_agent"}:
            raise ConfigurationError(
                f"Job entry {position} has unsupported source {source!r}"
            )
        app_id = str(item.get("app_id", "")).strip()
        stream = str(item.get("batch_stream_name", "")).strip()
        job_name = str(item.get("job_name", "")).strip()
        if not app_id or not stream or not job_name:
            raise ConfigurationError(
                f"Job entry {position} requires app_id, batch_stream_name and job_name"
            )
        key = (source, job_name.casefold())
        if key in seen:
            raise ConfigurationError(f"Duplicate {source} job name: {job_name}")
        seen.add(key)
        instance = str(item.get("instance", "")).strip().upper() or None
        if source == "aews" and not instance:
            raise ConfigurationError(f"AEWS job {job_name} requires an instance")
        jobs.append(
            SourceJob(
                app_id=app_id,
                batch_stream_name=stream,
                job_name=job_name,
                source=source,
                instance=instance,
            )
        )

    return SourceCheckSettings(
        jobs=tuple(jobs),
        sql_agent=SQLAgentSourceSettings(
            connection_string_env=str(
                sql.get("connection_string_env", "SAPBI_SQL_CONNECTION_STRING")
            ),
            server_timezone=str(sql.get("server_timezone", "America/New_York")),
            output_timezone=str(sql.get("output_timezone", "America/New_York")),
            store_naive_local_time=bool(sql.get("store_naive_local_time", True)),
        ),
        output_directory=str(output.get("directory", "output")),
        log_directory=str(output.get("log_directory", "logs")),
    )
