# Batch Dashboard Source Validation v1.3

This version validates production source data without connecting to or updating
the Batch Dashboard target table.

## Sources

- ODIN: PB3 AutoSys Web Services (AEWS), read-only HTTPS GET.
- SAPBI: SQL Server Agent `msdb` activity and history, read-only SELECT.

Configured jobs are in `config/source_jobs.yaml`. Correct names there before
testing if a SharePoint label differs from the actual AutoSys or SQL Agent name.

## Required runtime values

Copy `.env.example` to `.env` and populate only the approved values:

```text
AUTOSYS_API_USER
AUTOSYS_API_PASSWORD
SAPBI_SQL_CONNECTION_STRING
```

`SQLSERVER_CONNECTION_STRING` is not used by the source-validation commands.

## Test order

Test ODIN production AEWS only:

```bat
scripts\test_odin_prod.bat
```

Test SAPBI production SQL Agent only:

```bat
scripts\test_sapbi_prod.bat
```

After both succeed, test both sources together:

```bat
scripts\test_all_sources.bat
```

Offline validation with bundled mock fixtures:

```bat
scripts\test_all_sources_mock.bat
```

Every run creates timestamped files:

```text
output\source_validation_YYYYMMDD_HHMMSS_microseconds.json
logs\source_validation_YYYYMMDD_HHMMSS_microseconds.log
```

The JSON explicitly records:

```json
"target_database_connected": false,
"target_database_updated": false
```

## SQL Agent status mapping

```text
0 Failed      -> FA
1 Succeeded   -> SU
2 Retry       -> RE
3 Canceled    -> CA
4 In progress -> RU
```

For running-state detection, the collector checks the latest SQL Agent session
in `msdb.dbo.sysjobactivity`. For completed executions it reads the overall job
row (`step_id = 0`) from `msdb.dbo.sysjobhistory`.
