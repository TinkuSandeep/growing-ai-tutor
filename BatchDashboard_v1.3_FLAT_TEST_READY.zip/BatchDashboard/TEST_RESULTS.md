# Verification Results

Verification date: 2026-09-21

## v1.3 multi-source validation

- Automated tests: `14 passed`.
- Offline end-to-end source validation: `7 requested, 7 succeeded, 0 failed`.
- Validated three PB3 AEWS jobs through bundled AEWS fixtures.
- Validated four SAPBI SQL Agent jobs through bundled SQL Agent fixtures.
- Confirmed timestamped JSON output and log creation.
- Confirmed the source-validation report records target database connection and
  update values as `false`.

Production endpoints and SAPBI SQL Server connectivity must be validated in the
approved runtime environment.

## Automated tests

```text
.........                                                                [100%]
9 passed in 0.11s
```

Coverage includes:

- latest `runNum` selection;
- UTC-offset timestamp conversion to America/New_York;
- success and running status normalization;
- forced NULL end time for active runs;
- rejection of unknown statuses;
- rejection of incomplete terminal runs;
- dry-run write prevention;
- transactional-cycle abort after an extraction failure;
- SQL object-name safety validation.

## End-to-end mock dry run

```text
requested=3 extracted=3 updated=0 failures=0 dry_run=True
```

## AEWS-only checker

The dedicated one-job checker was executed with the local AEWS fixture. It
returned the latest run number, converted ET timestamps, and `SU` status while
reporting `database_connected=false` and `database_updated=false`.

## End-to-end mock write path

The write path was executed against the in-memory repository only:

```text
requested=3 extracted=3 updated=3 failures=0 dry_run=False
```

No Wells Fargo endpoint, credential, or database was used during verification.
Real AEWS and SQL Server validation must follow the controlled rollout in
`README.md`.
