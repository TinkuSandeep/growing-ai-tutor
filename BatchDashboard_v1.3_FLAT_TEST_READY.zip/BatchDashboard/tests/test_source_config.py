from pathlib import Path

from autosys_phase1.source_config import load_source_check_settings


def test_source_configuration_loads():
    config = Path(__file__).parents[1] / "config" / "source_jobs.yaml"
    settings = load_source_check_settings(config)
    assert len(settings.jobs) == 7
    assert sum(job.source == "aews" for job in settings.jobs) == 3
    assert sum(job.source == "sql_agent" for job in settings.jobs) == 4
    assert settings.sql_agent.connection_string_env == "SAPBI_SQL_CONNECTION_STRING"
