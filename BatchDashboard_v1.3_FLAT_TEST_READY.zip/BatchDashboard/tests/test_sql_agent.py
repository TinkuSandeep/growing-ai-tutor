from datetime import datetime

import pytest

from autosys_phase1.errors import DataValidationError
from autosys_phase1.sql_agent import duration_to_seconds, normalize_sql_agent_status


def test_duration_to_seconds():
    assert duration_to_seconds(10530) == 3930
    assert duration_to_seconds(250000) == 90000


def test_invalid_duration():
    with pytest.raises(DataValidationError):
        duration_to_seconds(126199)


def test_sql_agent_status_mapping():
    assert normalize_sql_agent_status(0) == "FA"
    assert normalize_sql_agent_status(1) == "SU"
    assert normalize_sql_agent_status(4) == "RU"


def test_unknown_sql_agent_status():
    with pytest.raises(DataValidationError):
        normalize_sql_agent_status(99)
