BatchDashboard - Source Validation v1.3
=======================================

Application folder:
  D:\BatchDashboard

Current purpose:
  Read production runtime information from two source systems without
  connecting to or updating the Batch Dashboard target database.

  ODIN  -> PB3 AEWS REST API
  SAPBI -> SQL Server Agent msdb activity/history

Configured source jobs:
  3 ODIN jobs and 4 SAPBI jobs in config\source_jobs.yaml.

Initial server setup:
  1. cd /d D:\BatchDashboard
  2. python -m venv venv
  3. venv\Scripts\python.exe -m pip install -r requirements.txt
  4. venv\Scripts\python.exe -m pip install -r requirements-sqlserver.txt
  5. Copy .env.example to .env.
  6. Populate AUTOSYS_API_USER, AUTOSYS_API_PASSWORD and
     SAPBI_SQL_CONNECTION_STRING with approved values.
  7. Review the exact source job names in config\source_jobs.yaml.

Production test order:
  1. scripts\test_odin_prod.bat
  2. scripts\test_sapbi_prod.bat
  3. scripts\test_all_sources.bat

Offline package validation:
  scripts\test_all_sources_mock.bat

Every source test creates:
  output\source_validation_YYYYMMDD_HHMMSS_microseconds.json
  logs\source_validation_YYYYMMDD_HHMMSS_microseconds.log

Current safety boundary:
  The source-validation commands execute AEWS GET requests and SQL SELECT
  statements only. They do not use SQLSERVER_CONNECTION_STRING, do not connect
  to the Batch Dashboard target database and do not update any tables.

Security:
  Never commit .env. Restrict it to the runtime service account and
  administrators. Use the organization's approved secret store in production.
