# AutoSys Phase 1 Runtime Ingestion

> **v1.3 testing path:** use `README_V1.3_MULTI_SOURCE.md` and the
> `test_odin_prod.bat`, `test_sapbi_prod.bat`, and `test_all_sources.bat`
> scripts. Those commands validate ODIN AEWS and SAPBI SQL Agent sources
> without connecting to or updating the Batch Dashboard target database.

Standalone Python application that reads current/latest execution data from the
AutoSys Web Services (AEWS) REST API and updates the existing SQL Server table
used by Grafana.

## Phase 1 scope

The application updates only these runtime fields in
`TCOO_TOOLS.dbo.cp_critical_batch_jobs`:

- `job_start_time`
- `job_end_time`
- `job_status`

Optional audit-column maintenance is supported by the code but disabled in
`config/settings.yaml`, so the Phase 1 deployment updates only the three
runtime fields. It does not create dashboards, send
AutoSys control events, start/restart jobs, or create database tables.

## Processing flow

1. Read the target AutoSys rows already configured in SQL Server.
2. Resolve each row to PB3 or an explicitly configured instance override.
3. Call read-only `GET /AEWS/job-run-info/{jobname}?version=3&verbose=1`.
4. Select the run with the highest `runNum`.
5. Convert the offset-aware AEWS timestamp to `America/New_York`.
6. Validate status and timestamp consistency.
7. Update all valid rows in one SQL Server transaction.
8. Roll back the transaction if any database key matches zero or multiple rows.

## Safety behavior

- Dry-run is enabled by default.
- A real write requires the explicit `--write` argument.
- Only HTTP GET is implemented; the client cannot send AutoSys events.
- Secrets are read only from environment variables.
- A terminal job without both timestamps is rejected.
- A running job always writes `job_end_time = NULL`.
- Unknown statuses are rejected instead of being written incorrectly.
- With `abort_on_job_error: true`, any AEWS/validation failure prevents the
  entire database update cycle.
- `require_exact_target_count: 10` prevents unexpected target expansion or
  loss. Change this only after the approved database list changes.

## Project structure

```text
autosys-phase1-runtime-ingestion/
├── config/
│   ├── settings.yaml
│   ├── mock_targets.yaml
│   └── mock_job_runs.json
├── scripts/
│   ├── run_mock.bat
│   ├── run_prod_dry_run.bat
│   ├── run_prod_write.bat
│   ├── start_ingestion.sh
│   └── test_local.bat
├── sql/
│   ├── preflight_and_validation.sql
│   └── post_run_validation.sql
├── src/autosys_phase1/
├── tests/
├── .env.example
├── autosys_phase1_ingestion.jil.example
└── requirements-sqlserver.txt
```

## Local mock test on Windows

From the project directory:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements-dev.txt
scripts\test_local.bat
```

This test requires no credentials, AEWS connectivity, or SQL Server access.
The result is written under `output`.

## Test AEWS only — no database connection

After the local mock test passes, create `.env` from `.env.example` and fill
only the two AEWS values:

```dotenv
AUTOSYS_API_USER=<AEWS service account>
AUTOSYS_API_PASSWORD=<AEWS service secret>
```

You may leave `SQLSERVER_CONNECTION_STRING` empty for this test. Run:

```bat
scripts\test_aews_only.bat PB3 EXACT_AUTOSYS_JOB_NAME
```

Use a real critical job name from the same AutoSys instance. This command:

- makes one read-only `GET /AEWS/job-run-info/{jobname}` call;
- does not initialize `pyodbc`;
- does not connect to SQL Server;
- does not update any database row;
- does not invoke an AutoSys POST/event operation;
- prints only the mapped runtime fields.

Successful output resembles:

```json
{
  "result": "AEWS_TEST_PASSED",
  "instance": "PB3",
  "job_name": "EXACT_AUTOSYS_JOB_NAME",
  "run_number": 64035,
  "job_start_time_et": "2026-09-21T06:00:00",
  "job_end_time_et": "2026-09-21T06:20:00",
  "job_status": "SU",
  "database_connected": false,
  "database_updated": false
}
```

The local no-network version can be checked first with:

```bat
scripts\test_aews_mock.bat
```

## Prepare the real environment

1. Install the Microsoft ODBC Driver 18 for SQL Server.
2. Install Python dependencies:

   ```bat
   python -m pip install -r requirements-sqlserver.txt
   ```

3. Copy `.env.example` to `.env`.
4. Fill `.env` locally. Never commit or share it:

   ```dotenv
   AUTOSYS_API_USER=<AEWS service account>
   AUTOSYS_API_PASSWORD=<AEWS service secret>
   SQLSERVER_CONNECTION_STRING=DRIVER={ODBC Driver 18 for SQL Server};SERVER=<server>;DATABASE=TCOO_TOOLS;Trusted_Connection=yes;TrustServerCertificate=yes;
   ```

`APIGEE_KEY` and `APIGEE_SECRET` are not needed. They belong to the separate
Dispatch Email integration.

## Configuration

Edit `config/settings.yaml`:

- Confirm the AEWS base URL and default scheduler instance.
- Keep `api_version: 3` to request `strStatus`.
- Add `app_instance_overrides` if DB3, UB3, PC3, or another instance is needed.
- Keep `timezone: America/New_York` for ET with daylight-saving handling.
- Confirm the three-part table name.
- Keep `dry_run: true` until end-to-end validation is complete.

Example override:

```yaml
autosys:
  default_instance: PB3
  app_instance_overrides:
    SOME_APP_ID: DB3
```

## Controlled rollout

### 1. Database preflight

Run `sql/preflight_and_validation.sql`. Confirm:

- exactly 10 `AUTOSYS` targets;
- column types are compatible with `DATETIME2` and `VARCHAR`;
- whether the DBA requires a stored procedure.

If a stored procedure is required, set:

```yaml
database:
  write_mode: stored_procedure
  stored_procedure: dbo.cp_Update_Critical_Batch_Job_Runtime
```

The expected parameter order is:

```text
app_id, batch_stream_name, job_name, job_start_time,
job_end_time, job_status, last_updated_by
```

### 2. Mock validation

```bat
scripts\test_local.bat
```

### 3. Real AEWS and database read-only validation

```bat
scripts\run_prod_dry_run.bat
```

Expected result: 10 requested, 10 extracted, 0 updated, 0 failures.

### 4. Approved write test

Take a database snapshot/query result first, then run:

```bat
scripts\run_prod_write.bat
```

Run `sql/post_run_validation.sql` immediately afterward and compare several
jobs with AutoSys Web UI/Swagger.

## Status handling

`strStatus` is preferred; numeric `status` is the fallback. Examples:

| AEWS | Stored value | End time |
|---|---|---|
| SUCCESS | SU | Required |
| RUNNING | RU | NULL |
| FAILURE | FA | Required |
| TERMINATED | TE | Required |
| STARTING | ST | NULL |
| PEND_MACHINE | PE | NULL |
| EVENT_WAIT | SE | NULL |
| PEND_TIME | PT | NULL |

## AutoSys scheduling

Use `autosys_phase1_ingestion.jil.example` only as a reviewed template. Start
with a longer interval during validation, then use the approved Grafana data
freshness requirement. The ingestion job should use a read-only AEWS service
account and the minimum SQL permissions required to select and update the
existing target table.
