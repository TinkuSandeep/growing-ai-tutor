# Batch Dashboard AutoSys OCP Runtime Ingestion - Version 1.1

This is the OCP-ready release of the working database-driven AutoSys runtime
ingestion solution. It retains the validated discovery, AEWS collection,
timestamp normalization, transactional runtime update and dependent database
summary refresh behavior.

## Version 1.1 changes

- Removed production dependency on Windows `.bat` and shell wrapper files.
- AutoSys invokes Python modules directly.
- Added OCP `Containerfile`, ConfigMap, secret example and runtime fragment.
- Added stdout-first logging for OCP and Splunk collection.
- File reports are optional and disabled by default for ephemeral containers.
- Enabled TLS verification in the OCP settings template.
- Added an OCP-specific two-job JIL example.

## AutoSys commands

Runtime ingestion:

```bash
python -m autosys_phase1.source_check --settings /opt/batch-dashboard/config/settings.yaml --write
```

Summary refresh:

```bash
python -m autosys_phase1.summary_refresh --settings /opt/batch-dashboard/config/settings.yaml
```

The summary job must depend on successful completion of the ingestion job.

## Database contracts

- Discovery: `dbo.cp_Get_Critical_Batch_Jobs`
- Required discovery columns: `job_name`, `scheduler_instance`
- Runtime update: `dbo.cp_UpdateJobExecutionStatus`
- Summary refresh: `dbo.cp_Update_Critical_Batch_Summary`

Job names remain database-driven. Do not hard-code production jobs in Python or
YAML.

See `README_OCP_DEPLOYMENT.md` for deployment and validation instructions.
