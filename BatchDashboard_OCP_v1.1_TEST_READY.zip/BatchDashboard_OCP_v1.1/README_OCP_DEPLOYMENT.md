# Batch Dashboard OCP deployment - Version 1.1

## Production execution model

Version 1.1 does not require Windows batch files. AutoSys directly invokes two
installed Python modules inside the approved OCP runtime.

Job 1:

```bash
python -m autosys_phase1.source_check \
  --settings /opt/batch-dashboard/config/settings.yaml \
  --write
```

Job 2:

```bash
python -m autosys_phase1.summary_refresh \
  --settings /opt/batch-dashboard/config/settings.yaml
```

Job 2 must have a success dependency on Job 1. Both modules return zero on
success and one on failure, allowing AutoSys to set SU or FA correctly.

## OCP prerequisites

- Python 3.10 or later.
- Microsoft ODBC Driver 18 and unixODBC in the approved image.
- Internal CA certificates for AEWS and SQL Server TLS.
- Network routes from the namespace to all approved AEWS instances and the SQL
  Server target.
- An approved AutoSys service identity with read-only AEWS access.
- An approved SQL Server service identity with EXECUTE permission on the three
  configured stored procedures.
- The AutoSys System Agent, or another approved mechanism that waits for module
  completion and propagates its return code.

## Configuration and secrets

Apply `ocp/configmap.yaml` after validating the environment-specific values.
Create `batch-dashboard-secrets` through the approved secret-management process.
Never apply `ocp/secret.example.yaml` with placeholder or real values stored in
Git.

Required variables:

- `AUTOSYS_API_USER`
- `AUTOSYS_API_PASSWORD`
- `SQLSERVER_CONNECTION_STRING`

No `.env` file is required in OCP. The existing dotenv call is retained only
for local testing and does not override injected variables.

## Logging

`file_output_enabled` is false by default. Logs and final JSON results go to
stdout/stderr for collection by OCP and Splunk. Set it to true only when the
configured output and log directories are backed by persistent storage.

## Deployment validation

1. Build and scan the image from `Containerfile`.
2. Confirm `python -m autosys_phase1.source_check --help` succeeds in the image.
3. Confirm the three required secret variables are present without printing
   their values.
4. Run Job 1 without `--write` as a dry run.
5. Compare the returned job count, start time, end time and status with AutoSys.
6. Run Job 1 with `--write` in an approved test window.
7. Validate the runtime detail table.
8. Run Job 2 and validate the summary table.
9. Import the reviewed JIL and confirm Job 2 runs only after Job 1 succeeds.

## Important integration rule

Do not use a fire-and-forget `oc create job` command from AutoSys. If the
AutoSys agent is outside OCP, the approved launcher must wait for the OCP Job,
collect its termination status and return a nonzero code to AutoSys when the
container fails.
