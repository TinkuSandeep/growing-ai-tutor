import pytest

from autosys_phase1.config import (
    ConfigurationError,
    load_settings,
    quote_sql_object_name,
)


def test_quotes_three_part_table_name():
    assert quote_sql_object_name("TCOO_TOOLS.dbo.cp_critical_batch_jobs") == (
        "[TCOO_TOOLS].[dbo].[cp_critical_batch_jobs]"
    )


def test_rejects_unsafe_table_name():
    with pytest.raises(ConfigurationError):
        quote_sql_object_name("dbo.jobs; DROP TABLE dbo.jobs")


def test_v11_ocp_contract_uses_scheduler_instance_and_summary_procedure():
    settings = load_settings("config/settings.yaml")
    assert settings.database.instance_column == "scheduler_instance"
    assert settings.database.summary_stored_procedure == (
        "dbo.cp_Update_Critical_Batch_Summary"
    )
    assert settings.ingestion.file_output_enabled is False
