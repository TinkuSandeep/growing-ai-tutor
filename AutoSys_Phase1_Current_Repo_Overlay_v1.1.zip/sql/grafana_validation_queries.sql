-- Latest collection health
SELECT TOP (20) collection_run_id, environment, source_instance, observed_at,
       completed_at, status, records_written, error_message
FROM dbo.cp_collection_run
ORDER BY collection_run_id DESC;

-- Current critical batch streams
SELECT * FROM dbo.cp_critical_batch_stream_ui ORDER BY batch_stream_name;

-- Current scheduler totals
SELECT * FROM dbo.cp_critical_batch_summary_ui ORDER BY scheduler_type;

-- Recent stream SLA trend
SELECT observed_at, stream_id, progress, status, sla_status
FROM dbo.cp_stream_status_history
WHERE observed_at >= DATEADD(day, -7, SYSDATETIMEOFFSET())
ORDER BY observed_at;

-- Stale feed check; should return zero rows for a healthy scheduled collector
SELECT scheduler_type, observed_at
FROM dbo.cp_scheduler_summary_current
WHERE observed_at < DATEADD(minute, -15, SYSDATETIMEOFFSET());

