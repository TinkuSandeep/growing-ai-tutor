PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS cp_collection_run (
    collection_run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    environment TEXT NOT NULL,
    source_instance TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    completed_at TEXT,
    status TEXT NOT NULL,
    records_written INTEGER NOT NULL DEFAULT 0,
    error_message TEXT
);

CREATE TABLE IF NOT EXISTS cp_critical_stream (
    stream_id TEXT PRIMARY KEY,
    stream_name TEXT NOT NULL,
    stream_type TEXT NOT NULL,
    scheduler_type TEXT NOT NULL,
    sla_time TEXT NOT NULL,
    target_completion_time TEXT NOT NULL,
    business_impact TEXT NOT NULL DEFAULT '',
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS cp_critical_stream_job (
    stream_id TEXT NOT NULL REFERENCES cp_critical_stream(stream_id),
    application_id TEXT NOT NULL,
    job_name TEXT NOT NULL,
    job_sequence INTEGER NOT NULL,
    expected_duration_minutes INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (stream_id, application_id, job_name),
    UNIQUE (stream_id, job_sequence)
);

CREATE TABLE IF NOT EXISTS cp_job_current_state (
    source_instance TEXT NOT NULL,
    application_id TEXT NOT NULL,
    job_name TEXT NOT NULL,
    box_name TEXT,
    job_status TEXT NOT NULL,
    status_group TEXT NOT NULL,
    job_start_time TEXT,
    job_end_time TEXT,
    run_number INTEGER,
    average_runtime_seconds INTEGER,
    observed_at TEXT NOT NULL,
    collection_run_id INTEGER NOT NULL REFERENCES cp_collection_run(collection_run_id),
    PRIMARY KEY (source_instance, application_id, job_name)
);

CREATE TABLE IF NOT EXISTS cp_job_status_history (
    history_id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_instance TEXT NOT NULL,
    application_id TEXT NOT NULL,
    job_name TEXT NOT NULL,
    job_status TEXT NOT NULL,
    status_group TEXT NOT NULL,
    job_start_time TEXT,
    job_end_time TEXT,
    run_number INTEGER,
    average_runtime_seconds INTEGER,
    observed_at TEXT NOT NULL,
    collection_run_id INTEGER NOT NULL REFERENCES cp_collection_run(collection_run_id)
);

CREATE TABLE IF NOT EXISTS cp_stream_current_state (
    stream_id TEXT PRIMARY KEY REFERENCES cp_critical_stream(stream_id),
    status TEXT NOT NULL,
    sla_status TEXT NOT NULL,
    progress INTEGER NOT NULL CHECK(progress BETWEEN 0 AND 100),
    total_jobs INTEGER NOT NULL,
    jobs_completed INTEGER NOT NULL,
    jobs_running INTEGER NOT NULL,
    jobs_failed INTEGER NOT NULL,
    jobs_waiting INTEGER NOT NULL,
    business_impact TEXT NOT NULL DEFAULT '',
    observed_at TEXT NOT NULL,
    collection_run_id INTEGER NOT NULL REFERENCES cp_collection_run(collection_run_id)
);

CREATE TABLE IF NOT EXISTS cp_stream_status_history (
    history_id INTEGER PRIMARY KEY AUTOINCREMENT,
    stream_id TEXT NOT NULL REFERENCES cp_critical_stream(stream_id),
    status TEXT NOT NULL,
    sla_status TEXT NOT NULL,
    progress INTEGER NOT NULL,
    total_jobs INTEGER NOT NULL,
    jobs_completed INTEGER NOT NULL,
    jobs_running INTEGER NOT NULL,
    jobs_failed INTEGER NOT NULL,
    jobs_waiting INTEGER NOT NULL,
    business_impact TEXT NOT NULL DEFAULT '',
    observed_at TEXT NOT NULL,
    collection_run_id INTEGER NOT NULL REFERENCES cp_collection_run(collection_run_id)
);

CREATE TABLE IF NOT EXISTS cp_scheduler_summary_current (
    scheduler_type TEXT PRIMARY KEY,
    total_critical_jobs INTEGER NOT NULL,
    jobs_completed INTEGER NOT NULL,
    jobs_running INTEGER NOT NULL,
    jobs_failed INTEGER NOT NULL,
    jobs_waiting INTEGER NOT NULL,
    sla_breach_count INTEGER NOT NULL,
    observed_at TEXT NOT NULL,
    collection_run_id INTEGER NOT NULL REFERENCES cp_collection_run(collection_run_id)
);

CREATE INDEX IF NOT EXISTS ix_job_history_observed_at ON cp_job_status_history(observed_at);
CREATE INDEX IF NOT EXISTS ix_stream_history_observed_at ON cp_stream_status_history(observed_at);

CREATE VIEW IF NOT EXISTS cp_critical_process_stream_ui AS
SELECT c.stream_name, s.status, c.sla_time, s.sla_status, s.progress,
       c.target_completion_time, s.business_impact, s.observed_at
FROM cp_critical_stream c JOIN cp_stream_current_state s ON s.stream_id = c.stream_id
WHERE c.stream_type = 'PROCESS';

CREATE VIEW IF NOT EXISTS cp_critical_batch_stream_ui AS
SELECT c.stream_name AS batch_stream_name, j.application_id, s.status, c.sla_time,
       s.sla_status, s.progress, c.target_completion_time, s.business_impact, s.observed_at
FROM cp_critical_stream c
JOIN cp_stream_current_state s ON s.stream_id = c.stream_id
LEFT JOIN cp_critical_stream_job j ON j.stream_id = c.stream_id
WHERE c.stream_type = 'BATCH';

CREATE VIEW IF NOT EXISTS cp_critical_batch_summary_ui AS
SELECT * FROM cp_scheduler_summary_current;

CREATE VIEW IF NOT EXISTS cp_critical_batch_jobs AS
SELECT j.application_id AS app_id, c.stream_name AS batch_stream_name, j.job_name,
       c.scheduler_type AS scheduler, j.job_sequence, c.sla_time,
       cs.average_runtime_seconds, cs.job_start_time, cs.job_end_time, cs.job_status,
       cs.observed_at
FROM cp_critical_stream_job j
JOIN cp_critical_stream c ON c.stream_id = j.stream_id
LEFT JOIN cp_job_current_state cs
  ON cs.application_id = j.application_id AND cs.job_name = j.job_name;

