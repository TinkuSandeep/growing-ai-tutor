/*
  Reference SQL Server 2019+ schema for Phase 1.
  Review naming, permissions, retention and deployment standards with the database team.
*/
SET XACT_ABORT ON;
GO

CREATE TABLE dbo.cp_collection_run (
    collection_run_id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    environment VARCHAR(50) NOT NULL,
    source_instance VARCHAR(20) NOT NULL,
    observed_at DATETIMEOFFSET(0) NOT NULL,
    completed_at DATETIMEOFFSET(0) NULL,
    status VARCHAR(20) NOT NULL,
    records_written INT NOT NULL CONSTRAINT DF_cp_collection_run_records DEFAULT 0,
    error_message VARCHAR(1000) NULL
);
GO

CREATE TABLE dbo.cp_critical_stream (
    stream_id VARCHAR(100) NOT NULL PRIMARY KEY,
    stream_name VARCHAR(200) NOT NULL,
    stream_type VARCHAR(20) NOT NULL,
    scheduler_type VARCHAR(50) NOT NULL,
    sla_time TIME(0) NOT NULL,
    target_completion_time TIME(0) NOT NULL,
    business_impact VARCHAR(500) NOT NULL CONSTRAINT DF_cp_stream_impact DEFAULT '',
    is_active BIT NOT NULL CONSTRAINT DF_cp_stream_active DEFAULT 1,
    updated_at DATETIMEOFFSET(0) NOT NULL CONSTRAINT DF_cp_stream_updated DEFAULT SYSDATETIMEOFFSET()
);
GO

CREATE TABLE dbo.cp_critical_stream_job (
    stream_id VARCHAR(100) NOT NULL,
    application_id VARCHAR(50) NOT NULL,
    job_name VARCHAR(200) NOT NULL,
    job_sequence INT NOT NULL,
    expected_duration_minutes INT NOT NULL,
    CONSTRAINT PK_cp_critical_stream_job PRIMARY KEY(stream_id, application_id, job_name),
    CONSTRAINT UQ_cp_critical_stream_job_sequence UNIQUE(stream_id, job_sequence),
    CONSTRAINT FK_cp_critical_stream_job_stream FOREIGN KEY(stream_id)
        REFERENCES dbo.cp_critical_stream(stream_id)
);
GO

CREATE TABLE dbo.cp_job_current_state (
    source_instance VARCHAR(20) NOT NULL,
    application_id VARCHAR(50) NOT NULL,
    job_name VARCHAR(200) NOT NULL,
    box_name VARCHAR(200) NULL,
    job_status VARCHAR(20) NOT NULL,
    status_group VARCHAR(20) NOT NULL,
    job_start_time DATETIMEOFFSET(0) NULL,
    job_end_time DATETIMEOFFSET(0) NULL,
    run_number BIGINT NULL,
    average_runtime_seconds INT NULL,
    observed_at DATETIMEOFFSET(0) NOT NULL,
    collection_run_id BIGINT NOT NULL,
    CONSTRAINT PK_cp_job_current_state PRIMARY KEY(source_instance, application_id, job_name),
    CONSTRAINT FK_cp_job_current_run FOREIGN KEY(collection_run_id)
        REFERENCES dbo.cp_collection_run(collection_run_id)
);
GO

CREATE TABLE dbo.cp_job_status_history (
    history_id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    source_instance VARCHAR(20) NOT NULL,
    application_id VARCHAR(50) NOT NULL,
    job_name VARCHAR(200) NOT NULL,
    job_status VARCHAR(20) NOT NULL,
    status_group VARCHAR(20) NOT NULL,
    job_start_time DATETIMEOFFSET(0) NULL,
    job_end_time DATETIMEOFFSET(0) NULL,
    run_number BIGINT NULL,
    average_runtime_seconds INT NULL,
    observed_at DATETIMEOFFSET(0) NOT NULL,
    collection_run_id BIGINT NOT NULL,
    CONSTRAINT FK_cp_job_history_run FOREIGN KEY(collection_run_id)
        REFERENCES dbo.cp_collection_run(collection_run_id)
);
GO

CREATE TABLE dbo.cp_stream_current_state (
    stream_id VARCHAR(100) NOT NULL PRIMARY KEY,
    status VARCHAR(20) NOT NULL,
    sla_status VARCHAR(20) NOT NULL,
    progress INT NOT NULL,
    total_jobs INT NOT NULL,
    jobs_completed INT NOT NULL,
    jobs_running INT NOT NULL,
    jobs_failed INT NOT NULL,
    jobs_waiting INT NOT NULL,
    business_impact VARCHAR(500) NOT NULL,
    observed_at DATETIMEOFFSET(0) NOT NULL,
    collection_run_id BIGINT NOT NULL,
    CONSTRAINT CK_cp_stream_progress CHECK(progress BETWEEN 0 AND 100),
    CONSTRAINT FK_cp_stream_current_stream FOREIGN KEY(stream_id)
        REFERENCES dbo.cp_critical_stream(stream_id),
    CONSTRAINT FK_cp_stream_current_run FOREIGN KEY(collection_run_id)
        REFERENCES dbo.cp_collection_run(collection_run_id)
);
GO

CREATE TABLE dbo.cp_stream_status_history (
    history_id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    stream_id VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL,
    sla_status VARCHAR(20) NOT NULL,
    progress INT NOT NULL,
    total_jobs INT NOT NULL,
    jobs_completed INT NOT NULL,
    jobs_running INT NOT NULL,
    jobs_failed INT NOT NULL,
    jobs_waiting INT NOT NULL,
    business_impact VARCHAR(500) NOT NULL,
    observed_at DATETIMEOFFSET(0) NOT NULL,
    collection_run_id BIGINT NOT NULL,
    CONSTRAINT FK_cp_stream_history_stream FOREIGN KEY(stream_id)
        REFERENCES dbo.cp_critical_stream(stream_id),
    CONSTRAINT FK_cp_stream_history_run FOREIGN KEY(collection_run_id)
        REFERENCES dbo.cp_collection_run(collection_run_id)
);
GO

CREATE TABLE dbo.cp_scheduler_summary_current (
    scheduler_type VARCHAR(50) NOT NULL PRIMARY KEY,
    total_critical_jobs INT NOT NULL,
    jobs_completed INT NOT NULL,
    jobs_running INT NOT NULL,
    jobs_failed INT NOT NULL,
    jobs_waiting INT NOT NULL,
    sla_breach_count INT NOT NULL,
    observed_at DATETIMEOFFSET(0) NOT NULL,
    collection_run_id BIGINT NOT NULL,
    CONSTRAINT FK_cp_scheduler_summary_run FOREIGN KEY(collection_run_id)
        REFERENCES dbo.cp_collection_run(collection_run_id)
);
GO

CREATE INDEX IX_cp_job_history_observed ON dbo.cp_job_status_history(observed_at)
    INCLUDE(application_id, job_name, job_status, status_group);
CREATE INDEX IX_cp_stream_history_observed ON dbo.cp_stream_status_history(observed_at)
    INCLUDE(stream_id, status, sla_status, progress);
GO

CREATE OR ALTER PROCEDURE dbo.cp_begin_collection_run
    @environment VARCHAR(50),
    @source_instance VARCHAR(20),
    @observed_at DATETIMEOFFSET(0)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT dbo.cp_collection_run(environment, source_instance, observed_at, status)
    VALUES(@environment, @source_instance, @observed_at, 'RUNNING');
    SELECT CONVERT(BIGINT, SCOPE_IDENTITY()) AS collection_run_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.cp_finish_collection_run
    @collection_run_id BIGINT,
    @status VARCHAR(20),
    @records_written INT,
    @error_message VARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.cp_collection_run
       SET status=@status, records_written=@records_written,
           error_message=@error_message, completed_at=SYSDATETIMEOFFSET()
     WHERE collection_run_id=@collection_run_id;
END;
GO

CREATE OR ALTER PROCEDURE dbo.cp_seed_critical_streams
    @streams_json NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;

    DECLARE @streams TABLE(
        stream_id VARCHAR(100), stream_name VARCHAR(200), stream_type VARCHAR(20),
        scheduler_type VARCHAR(50), sla_time TIME(0), target_completion_time TIME(0),
        business_impact VARCHAR(500), jobs NVARCHAR(MAX)
    );
    INSERT @streams
    SELECT stream_id, stream_name, stream_type, scheduler_type, sla_time,
           target_completion_time, business_impact, jobs
      FROM OPENJSON(@streams_json)
      WITH(
        stream_id VARCHAR(100), stream_name VARCHAR(200), stream_type VARCHAR(20),
        scheduler_type VARCHAR(50), sla_time TIME(0), target_completion_time TIME(0),
        business_impact VARCHAR(500), jobs NVARCHAR(MAX) AS JSON
      );

    MERGE dbo.cp_critical_stream AS target
    USING @streams AS source ON target.stream_id=source.stream_id
    WHEN MATCHED THEN UPDATE SET
        stream_name=source.stream_name, stream_type=source.stream_type,
        scheduler_type=source.scheduler_type, sla_time=source.sla_time,
        target_completion_time=source.target_completion_time,
        business_impact=source.business_impact, is_active=1,
        updated_at=SYSDATETIMEOFFSET()
    WHEN NOT MATCHED THEN INSERT
        (stream_id, stream_name, stream_type, scheduler_type, sla_time,
         target_completion_time, business_impact, is_active)
        VALUES(source.stream_id, source.stream_name, source.stream_type,
               source.scheduler_type, source.sla_time, source.target_completion_time,
               source.business_impact, 1);

    DELETE target
      FROM dbo.cp_critical_stream_job target
      JOIN @streams source ON source.stream_id=target.stream_id;

    INSERT dbo.cp_critical_stream_job
        (stream_id, application_id, job_name, job_sequence, expected_duration_minutes)
    SELECT s.stream_id, j.application_id, j.job_name, j.sequence, j.expected_duration_minutes
      FROM @streams s
      CROSS APPLY OPENJSON(s.jobs)
      WITH(
        application_id VARCHAR(50), job_name VARCHAR(200), sequence INT,
        expected_duration_minutes INT
      ) j;

    COMMIT TRANSACTION;
END;
GO

CREATE OR ALTER PROCEDURE dbo.cp_load_phase1_snapshot
    @collection_run_id BIGINT,
    @observed_at DATETIMEOFFSET(0),
    @jobs_json NVARCHAR(MAX),
    @streams_json NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;

    DECLARE @jobs TABLE(
        instance VARCHAR(20), application_id VARCHAR(50), job_name VARCHAR(200),
        box_name VARCHAR(200), status VARCHAR(20), status_group VARCHAR(20),
        start_time DATETIMEOFFSET(0), end_time DATETIMEOFFSET(0), run_number BIGINT,
        average_runtime_seconds INT
    );
    INSERT @jobs
    SELECT * FROM OPENJSON(@jobs_json)
    WITH(
        instance VARCHAR(20), application_id VARCHAR(50), job_name VARCHAR(200),
        box_name VARCHAR(200), status VARCHAR(20), status_group VARCHAR(20),
        start_time DATETIMEOFFSET(0), end_time DATETIMEOFFSET(0), run_number BIGINT,
        average_runtime_seconds INT
    );

    MERGE dbo.cp_job_current_state AS target
    USING @jobs AS source
       ON target.source_instance=source.instance
      AND target.application_id=source.application_id
      AND target.job_name=source.job_name
    WHEN MATCHED THEN UPDATE SET
        box_name=source.box_name, job_status=source.status, status_group=source.status_group,
        job_start_time=source.start_time, job_end_time=source.end_time,
        run_number=source.run_number, average_runtime_seconds=source.average_runtime_seconds,
        observed_at=@observed_at, collection_run_id=@collection_run_id
    WHEN NOT MATCHED THEN INSERT
        (source_instance, application_id, job_name, box_name, job_status, status_group,
         job_start_time, job_end_time, run_number, average_runtime_seconds, observed_at, collection_run_id)
        VALUES(source.instance, source.application_id, source.job_name, source.box_name,
               source.status, source.status_group, source.start_time, source.end_time,
               source.run_number, source.average_runtime_seconds, @observed_at, @collection_run_id);

    INSERT dbo.cp_job_status_history
        (source_instance, application_id, job_name, job_status, status_group,
         job_start_time, job_end_time, run_number, average_runtime_seconds,
         observed_at, collection_run_id)
    SELECT instance, application_id, job_name, status, status_group, start_time,
           end_time, run_number, average_runtime_seconds, @observed_at, @collection_run_id
      FROM @jobs;

    DECLARE @streams TABLE(
        stream_id VARCHAR(100), status VARCHAR(20), sla_status VARCHAR(20), progress INT,
        total_jobs INT, jobs_completed INT, jobs_running INT, jobs_failed INT,
        jobs_waiting INT, business_impact VARCHAR(500), scheduler_type VARCHAR(50)
    );
    INSERT @streams
    SELECT stream_id, status, sla_status, progress, total_jobs, jobs_completed,
           jobs_running, jobs_failed, jobs_waiting, business_impact, scheduler_type
      FROM OPENJSON(@streams_json)
      WITH(
        stream_id VARCHAR(100), status VARCHAR(20), sla_status VARCHAR(20), progress INT,
        total_jobs INT, jobs_completed INT, jobs_running INT, jobs_failed INT,
        jobs_waiting INT, business_impact VARCHAR(500), scheduler_type VARCHAR(50)
      );

    MERGE dbo.cp_stream_current_state AS target
    USING @streams AS source ON target.stream_id=source.stream_id
    WHEN MATCHED THEN UPDATE SET
        status=source.status, sla_status=source.sla_status, progress=source.progress,
        total_jobs=source.total_jobs, jobs_completed=source.jobs_completed,
        jobs_running=source.jobs_running, jobs_failed=source.jobs_failed,
        jobs_waiting=source.jobs_waiting, business_impact=source.business_impact,
        observed_at=@observed_at, collection_run_id=@collection_run_id
    WHEN NOT MATCHED THEN INSERT
        (stream_id, status, sla_status, progress, total_jobs, jobs_completed,
         jobs_running, jobs_failed, jobs_waiting, business_impact, observed_at, collection_run_id)
        VALUES(source.stream_id, source.status, source.sla_status, source.progress,
               source.total_jobs, source.jobs_completed, source.jobs_running,
               source.jobs_failed, source.jobs_waiting, source.business_impact,
               @observed_at, @collection_run_id);

    INSERT dbo.cp_stream_status_history
        (stream_id, status, sla_status, progress, total_jobs, jobs_completed,
         jobs_running, jobs_failed, jobs_waiting, business_impact, observed_at, collection_run_id)
    SELECT stream_id, status, sla_status, progress, total_jobs, jobs_completed,
           jobs_running, jobs_failed, jobs_waiting, business_impact,
           @observed_at, @collection_run_id
      FROM @streams;

    MERGE dbo.cp_scheduler_summary_current AS target
    USING(
        SELECT scheduler_type,
               SUM(total_jobs) total_critical_jobs,
               SUM(jobs_completed) jobs_completed,
               SUM(jobs_running) jobs_running,
               SUM(jobs_failed) jobs_failed,
               SUM(jobs_waiting) jobs_waiting,
               SUM(CASE WHEN sla_status='BREACHED' THEN 1 ELSE 0 END) sla_breach_count
          FROM @streams GROUP BY scheduler_type
    ) AS source ON target.scheduler_type=source.scheduler_type
    WHEN MATCHED THEN UPDATE SET
        total_critical_jobs=source.total_critical_jobs, jobs_completed=source.jobs_completed,
        jobs_running=source.jobs_running, jobs_failed=source.jobs_failed,
        jobs_waiting=source.jobs_waiting, sla_breach_count=source.sla_breach_count,
        observed_at=@observed_at, collection_run_id=@collection_run_id
    WHEN NOT MATCHED THEN INSERT
        (scheduler_type, total_critical_jobs, jobs_completed, jobs_running, jobs_failed,
         jobs_waiting, sla_breach_count, observed_at, collection_run_id)
        VALUES(source.scheduler_type, source.total_critical_jobs, source.jobs_completed,
               source.jobs_running, source.jobs_failed, source.jobs_waiting,
               source.sla_breach_count, @observed_at, @collection_run_id);

    COMMIT TRANSACTION;
END;
GO

CREATE OR ALTER VIEW dbo.cp_critical_process_stream_ui AS
SELECT c.stream_name, s.status, c.sla_time, s.sla_status, s.progress,
       c.target_completion_time, s.business_impact, s.observed_at
FROM dbo.cp_critical_stream c
JOIN dbo.cp_stream_current_state s ON s.stream_id=c.stream_id
WHERE c.stream_type='PROCESS';
GO

CREATE OR ALTER VIEW dbo.cp_critical_batch_stream_ui AS
SELECT c.stream_name AS batch_stream_name, s.status, c.sla_time, s.sla_status,
       s.progress, c.target_completion_time, s.business_impact, s.observed_at
FROM dbo.cp_critical_stream c
JOIN dbo.cp_stream_current_state s ON s.stream_id=c.stream_id
WHERE c.stream_type='BATCH';
GO

CREATE OR ALTER VIEW dbo.cp_critical_batch_summary_ui AS
SELECT scheduler_type, total_critical_jobs, jobs_completed, jobs_running,
       jobs_failed, jobs_waiting, sla_breach_count, observed_at
FROM dbo.cp_scheduler_summary_current;
GO

CREATE OR ALTER VIEW dbo.cp_critical_batch_jobs AS
SELECT j.application_id AS app_id, c.stream_name AS batch_stream_name,
       j.job_name, c.scheduler_type AS scheduler, j.job_sequence, c.sla_time,
       cs.average_runtime_seconds, cs.job_start_time, cs.job_end_time,
       cs.job_status, cs.observed_at
FROM dbo.cp_critical_stream_job j
JOIN dbo.cp_critical_stream c ON c.stream_id=j.stream_id
LEFT JOIN dbo.cp_job_current_state cs
  ON cs.application_id=j.application_id AND cs.job_name=j.job_name;
GO

