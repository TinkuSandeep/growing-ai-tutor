@echo off
setlocal
cd /d "%~dp0\.."
if not exist .venv (
  py -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements-phase1.txt
set AUTOSYS_SOURCE=mock
python src\ingestion_main.py --config config\ingestion.yaml --flows config\critical_flows.yaml --init-db
if errorlevel 1 exit /b 1
echo Mock ingestion completed: output\autosys_phase1.db
