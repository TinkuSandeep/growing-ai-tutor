@echo off
setlocal
cd /d "%~dp0\.."
if not exist .venv (
  py -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements-phase1.txt
set PYTHONPATH=src
python -m unittest discover -s tests -v
if errorlevel 1 exit /b 1
echo Phase 1 ingestion tests passed.
