#!/usr/bin/env sh
set -eu

exec python src/ingestion_main.py \
  --config "${INGESTION_CONFIG_PATH:-config/ingestion.yaml}" \
  --flows "${CRITICAL_FLOWS_CONFIG_PATH:-config/critical_flows.yaml}"

