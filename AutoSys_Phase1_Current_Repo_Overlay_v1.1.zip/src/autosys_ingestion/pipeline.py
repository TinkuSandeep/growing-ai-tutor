from __future__ import annotations

from datetime import datetime
from typing import Iterable

from .autosys import AutoSysClient
from .database import Repository
from .engines import average_runtimes, build_stream_snapshot, normalize_jobs, utc_now
from .models import StreamDefinition, StreamSnapshot
from .validation import validate_source_rows


class IngestionPipeline:
    def __init__(
        self,
        client: AutoSysClient,
        repository: Repository,
        streams: Iterable[StreamDefinition],
        environment: str,
        source_instance: str,
        timezone_name: str,
        history_lookback_days: int = 30,
        risk_window_minutes: int = 30,
    ):
        self.client = client
        self.repository = repository
        self.streams = tuple(streams)
        self.environment = environment
        self.source_instance = source_instance
        self.timezone_name = timezone_name
        self.history_lookback_days = history_lookback_days
        self.risk_window_minutes = risk_window_minutes

    def run(self, now: datetime | None = None) -> dict[str, int | str]:
        observed = now or utc_now()
        observed_at = observed.isoformat()
        run_id = self.repository.start_run(self.environment, self.source_instance, observed_at)
        try:
            application_ids = sorted({job.application_id for stream in self.streams for job in stream.jobs})
            current_rows = []
            history_rows = []
            for application_id in application_ids:
                current_rows.extend(self.client.list_jobs(application_id))
                history_rows.extend(self.client.get_job_history(application_id, self.history_lookback_days))

            validate_source_rows(current_rows, self.streams)
            jobs = normalize_jobs(current_rows, average_runtimes(history_rows))
            configured = {(job.application_id, job.job_name) for stream in self.streams for job in stream.jobs}
            jobs = [job for job in jobs if (job.application_id, job.job_name) in configured]

            snapshots: list[StreamSnapshot] = [
                build_stream_snapshot(
                    stream, jobs, observed, self.timezone_name, self.risk_window_minutes
                ) for stream in self.streams
            ]
            self.repository.seed_configuration(self.streams)
            self.repository.write_cycle(run_id, observed_at, jobs, snapshots)
            records_written = len(jobs) + len(snapshots)
            self.repository.finish_run(run_id, "SUCCEEDED", records_written)
            return {"run_id": run_id, "status": "SUCCEEDED", "jobs": len(jobs), "streams": len(snapshots)}
        except Exception as error:
            self.repository.finish_run(run_id, "FAILED", 0, str(error)[:1000])
            raise
