from __future__ import annotations

import base64
import json
import ssl
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlencode
from urllib.request import Request, urlopen


class AutoSysClient(Protocol):
    def list_jobs(self, application_id: str) -> list[dict[str, Any]]: ...
    def get_job_history(self, application_id: str, lookback_days: int) -> list[dict[str, Any]]: ...
    def health_check(self) -> bool: ...


class MockAutoSysClient:
    def __init__(self, fixture_path: str | Path):
        with Path(fixture_path).open("r", encoding="utf-8") as handle:
            self.data = json.load(handle)

    def list_jobs(self, application_id: str) -> list[dict[str, Any]]:
        return [row.copy() for row in self.data.get("current_jobs", []) if row.get("application_id") == application_id]

    def get_job_history(self, application_id: str, lookback_days: int) -> list[dict[str, Any]]:
        del lookback_days
        return [row.copy() for row in self.data.get("history", []) if row.get("application_id") == application_id]

    def health_check(self) -> bool:
        return True


class AEWSClient:
    """Read-only AEWS adapter. Response-field mapping may be customized internally."""

    def __init__(
        self,
        base_url: str,
        principal: str,
        secret: str,
        verify_tls: bool = True,
        timeout_seconds: int = 30,
    ):
        self.base_url = base_url.rstrip("/")
        token = base64.b64encode(f"{principal}:{secret}".encode()).decode()
        self.headers = {"Authorization": f"Basic {token}", "Accept": "application/json"}
        self.timeout_seconds = timeout_seconds
        self.context = ssl.create_default_context() if verify_tls else ssl._create_unverified_context()

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        query = f"?{urlencode(params)}" if params else ""
        request = Request(f"{self.base_url}{path}{query}", headers=self.headers, method="GET")
        with urlopen(request, timeout=self.timeout_seconds, context=self.context) as response:
            return json.loads(response.read().decode("utf-8"))

    @staticmethod
    def _items(payload: Any) -> list[dict[str, Any]]:
        if isinstance(payload, list):
            return payload
        if isinstance(payload, dict):
            for key in ("items", "jobs", "data", "result"):
                value = payload.get(key)
                if isinstance(value, list):
                    return value
        raise ValueError("Unsupported AEWS response shape; update AEWSClient._items for the internal contract")

    def list_jobs(self, application_id: str) -> list[dict[str, Any]]:
        return self._items(self._get("/AEWS/job", {"filter-application": application_id}))

    def get_job_history(self, application_id: str, lookback_days: int) -> list[dict[str, Any]]:
        return self._items(self._get("/AEWS/job-run-info", {
            "filter-application": application_id,
            "verbose": 1,
            "lookback-days": lookback_days,
        }))

    def health_check(self) -> bool:
        try:
            self._get("/AEWS/job", {"filter-application": "__health_check__"})
            return True
        except Exception:
            return False

