from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable, Protocol

from .models import JobState, StreamDefinition, StreamSnapshot


class Repository(Protocol):
    def initialize(self) -> None: ...
    def start_run(self, environment: str, source_instance: str, observed_at: str) -> int: ...
    def seed_configuration(self, streams: Iterable[StreamDefinition]) -> None: ...
    def write_cycle(self, run_id: int, observed_at: str, jobs: Iterable[JobState], streams: Iterable[StreamSnapshot]) -> None: ...
    def finish_run(self, run_id: int, status: str, records_written: int, error_message: str | None = None) -> None: ...
    def close(self) -> None: ...


class SQLiteRepository:
    def __init__(self, path: str | Path, schema_path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.schema_path = Path(schema_path)
        self.connection = sqlite3.connect(self.path)
        self.connection.row_factory = sqlite3.Row

    def initialize(self) -> None:
        self.connection.executescript(self.schema_path.read_text(encoding="utf-8"))
        self.connection.commit()

    def start_run(self, environment: str, source_instance: str, observed_at: str) -> int:
        cursor = self.connection.execute(
            "INSERT INTO cp_collection_run(environment, source_instance, observed_at, status) VALUES (?, ?, ?, 'RUNNING')",
            (environment, source_instance, observed_at),
        )
        self.connection.commit()
        return int(cursor.lastrowid)

    def seed_configuration(self, streams: Iterable[StreamDefinition]) -> None:
        with self.connection:
            for stream in streams:
                self.connection.execute(
                    """INSERT INTO cp_critical_stream(stream_id, stream_name, stream_type, scheduler_type, sla_time,
                       target_completion_time, business_impact, is_active)
                       VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                       ON CONFLICT(stream_id) DO UPDATE SET stream_name=excluded.stream_name,
                       stream_type=excluded.stream_type, scheduler_type=excluded.scheduler_type,
                       sla_time=excluded.sla_time, target_completion_time=excluded.target_completion_time,
                       business_impact=excluded.business_impact, is_active=1""",
                    (stream.stream_id, stream.stream_name, stream.stream_type, stream.scheduler_type,
                     stream.sla_time, stream.target_completion_time, stream.business_impact),
                )
                self.connection.execute("DELETE FROM cp_critical_stream_job WHERE stream_id=?", (stream.stream_id,))
                self.connection.executemany(
                    """INSERT INTO cp_critical_stream_job
                       (stream_id, application_id, job_name, job_sequence, expected_duration_minutes)
                       VALUES (?, ?, ?, ?, ?)""",
                    [(stream.stream_id, job.application_id, job.job_name, job.sequence, job.expected_duration_minutes)
                     for job in stream.jobs],
                )

    def write_cycle(
        self,
        run_id: int,
        observed_at: str,
        jobs: Iterable[JobState],
        streams: Iterable[StreamSnapshot],
    ) -> None:
        job_rows = list(jobs)
        stream_rows = list(streams)
        with self.connection:
            for job in job_rows:
                record = job.to_record()
                values = (job.instance, job.application_id, job.job_name, job.box_name, job.status,
                          job.status_group, record["start_time"], record["end_time"], job.run_number,
                          job.average_runtime_seconds, observed_at, run_id)
                self.connection.execute(
                    """INSERT INTO cp_job_current_state
                       (source_instance, application_id, job_name, box_name, job_status, status_group,
                        job_start_time, job_end_time, run_number, average_runtime_seconds, observed_at, collection_run_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(source_instance, application_id, job_name) DO UPDATE SET
                       box_name=excluded.box_name, job_status=excluded.job_status, status_group=excluded.status_group,
                       job_start_time=excluded.job_start_time, job_end_time=excluded.job_end_time,
                       run_number=excluded.run_number, average_runtime_seconds=excluded.average_runtime_seconds,
                       observed_at=excluded.observed_at, collection_run_id=excluded.collection_run_id""", values)
                self.connection.execute(
                    """INSERT INTO cp_job_status_history
                       (source_instance, application_id, job_name, job_status, status_group, job_start_time,
                        job_end_time, run_number, average_runtime_seconds, observed_at, collection_run_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (job.instance, job.application_id, job.job_name, job.status, job.status_group,
                     record["start_time"], record["end_time"], job.run_number, job.average_runtime_seconds,
                     observed_at, run_id),
                )

            for stream in stream_rows:
                record = stream.to_record()
                values = tuple(record[key] for key in (
                    "stream_id", "status", "sla_status", "progress", "total_jobs", "jobs_completed",
                    "jobs_running", "jobs_failed", "jobs_waiting", "business_impact"
                )) + (observed_at, run_id)
                self.connection.execute(
                    """INSERT INTO cp_stream_current_state
                       (stream_id, status, sla_status, progress, total_jobs, jobs_completed, jobs_running,
                        jobs_failed, jobs_waiting, business_impact, observed_at, collection_run_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(stream_id) DO UPDATE SET status=excluded.status, sla_status=excluded.sla_status,
                       progress=excluded.progress, total_jobs=excluded.total_jobs,
                       jobs_completed=excluded.jobs_completed, jobs_running=excluded.jobs_running,
                       jobs_failed=excluded.jobs_failed, jobs_waiting=excluded.jobs_waiting,
                       business_impact=excluded.business_impact, observed_at=excluded.observed_at,
                       collection_run_id=excluded.collection_run_id""", values)
                self.connection.execute(
                    """INSERT INTO cp_stream_status_history
                       (stream_id, status, sla_status, progress, total_jobs, jobs_completed, jobs_running,
                        jobs_failed, jobs_waiting, business_impact, observed_at, collection_run_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", values)

            summary: dict[str, dict[str, int]] = {}
            for stream in stream_rows:
                row = summary.setdefault(stream.scheduler_type, {
                    "total": 0, "completed": 0, "running": 0, "failed": 0, "waiting": 0, "breaches": 0
                })
                row["total"] += stream.total_jobs
                row["completed"] += stream.jobs_completed
                row["running"] += stream.jobs_running
                row["failed"] += stream.jobs_failed
                row["waiting"] += stream.jobs_waiting
                row["breaches"] += int(stream.sla_status == "BREACHED")
            for scheduler_type, row in summary.items():
                self.connection.execute(
                    """INSERT INTO cp_scheduler_summary_current
                       (scheduler_type, total_critical_jobs, jobs_completed, jobs_running, jobs_failed,
                        jobs_waiting, sla_breach_count, observed_at, collection_run_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(scheduler_type) DO UPDATE SET total_critical_jobs=excluded.total_critical_jobs,
                       jobs_completed=excluded.jobs_completed, jobs_running=excluded.jobs_running,
                       jobs_failed=excluded.jobs_failed, jobs_waiting=excluded.jobs_waiting,
                       sla_breach_count=excluded.sla_breach_count, observed_at=excluded.observed_at,
                       collection_run_id=excluded.collection_run_id""",
                    (scheduler_type, row["total"], row["completed"], row["running"], row["failed"],
                     row["waiting"], row["breaches"], observed_at, run_id),
                )

    def finish_run(self, run_id: int, status: str, records_written: int, error_message: str | None = None) -> None:
        self.connection.execute(
            """UPDATE cp_collection_run SET status=?, records_written=?, error_message=?,
               completed_at=CURRENT_TIMESTAMP WHERE collection_run_id=?""",
            (status, records_written, error_message, run_id),
        )
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()


class SQLServerRepository:
    """SQL Server writer using the stored procedures supplied in sql/sqlserver_schema.sql."""

    def __init__(self, connection_string: str):
        try:
            import pyodbc
        except ImportError as error:
            raise RuntimeError("Install requirements-sqlserver.txt to use SQL Server") from error
        self.connection = pyodbc.connect(connection_string, autocommit=False)

    def initialize(self) -> None:
        return None

    def start_run(self, environment: str, source_instance: str, observed_at: str) -> int:
        cursor = self.connection.cursor()
        row = cursor.execute("EXEC dbo.cp_begin_collection_run ?, ?, ?", environment, source_instance, observed_at).fetchone()
        self.connection.commit()
        return int(row[0])

    def seed_configuration(self, streams: Iterable[StreamDefinition]) -> None:
        payload = json.dumps([
            {**stream.__dict__, "jobs": [job.__dict__ for job in stream.jobs]}
            for stream in streams
        ])
        self.connection.cursor().execute("EXEC dbo.cp_seed_critical_streams ?", payload)
        self.connection.commit()

    def write_cycle(self, run_id: int, observed_at: str, jobs: Iterable[JobState], streams: Iterable[StreamSnapshot]) -> None:
        jobs_payload = json.dumps([job.to_record() for job in jobs])
        streams_payload = json.dumps([stream.to_record() for stream in streams])
        self.connection.cursor().execute(
            "EXEC dbo.cp_load_phase1_snapshot ?, ?, ?, ?", run_id, observed_at, jobs_payload, streams_payload
        )
        self.connection.commit()

    def finish_run(self, run_id: int, status: str, records_written: int, error_message: str | None = None) -> None:
        self.connection.cursor().execute(
            "EXEC dbo.cp_finish_collection_run ?, ?, ?, ?", run_id, status, records_written, error_message
        )
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()

