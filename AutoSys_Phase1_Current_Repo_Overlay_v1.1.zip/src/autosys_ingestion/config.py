from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

from .models import JobDefinition, StreamDefinition


class ConfigurationError(ValueError):
    pass


def load_yaml(path: str | Path) -> dict[str, Any]:
    config_path = Path(path)
    if not config_path.exists():
        raise ConfigurationError(f"Configuration file not found: {config_path}")
    with config_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    if not isinstance(data, dict):
        raise ConfigurationError(f"Expected a mapping in {config_path}")
    return data


def load_streams(path: str | Path) -> tuple[StreamDefinition, ...]:
    raw = load_yaml(path).get("critical_flows", [])
    if not raw:
        raise ConfigurationError("At least one critical flow is required")

    streams: list[StreamDefinition] = []
    seen_streams: set[str] = set()
    for item in raw:
        stream_id = str(item.get("stream_id", "")).strip()
        if not stream_id or stream_id in seen_streams:
            raise ConfigurationError(f"Missing or duplicate stream_id: {stream_id!r}")
        seen_streams.add(stream_id)

        jobs: list[JobDefinition] = []
        seen_jobs: set[tuple[str, str]] = set()
        for job in item.get("jobs", []):
            key = (str(job.get("application_id", "")).strip(), str(job.get("job_name", "")).strip())
            if not all(key) or key in seen_jobs:
                raise ConfigurationError(f"Missing or duplicate job in {stream_id}: {key}")
            seen_jobs.add(key)
            jobs.append(JobDefinition(
                application_id=key[0],
                job_name=key[1],
                sequence=int(job["sequence"]),
                expected_duration_minutes=int(job.get("expected_duration_minutes", 0)),
            ))
        if not jobs:
            raise ConfigurationError(f"Stream {stream_id} has no jobs")
        if len({job.sequence for job in jobs}) != len(jobs):
            raise ConfigurationError(f"Stream {stream_id} contains duplicate job sequences")

        streams.append(StreamDefinition(
            stream_id=stream_id,
            stream_name=str(item["stream_name"]),
            stream_type=str(item.get("stream_type", "BATCH")).upper(),
            scheduler_type=str(item.get("scheduler_type", "AUTOSYS")).upper(),
            sla_time=str(item["sla_time"]),
            target_completion_time=str(item.get("target_completion_time", item["sla_time"])),
            business_impact=str(item.get("business_impact", "")),
            jobs=tuple(sorted(jobs, key=lambda value: value.sequence)),
        ))
    return tuple(streams)


def env(name: str, default: str | None = None) -> str | None:
    return os.environ.get(name, default)

