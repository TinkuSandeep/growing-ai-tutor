from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, time, timedelta, timezone
from statistics import mean
from typing import Any, Iterable
from zoneinfo import ZoneInfo

from .models import JobState, StreamDefinition, StreamSnapshot, parse_datetime


STATUS_GROUPS = {
    "SU": "COMPLETED",
    "FA": "FAILED",
    "TE": "FAILED",
    "RU": "RUNNING",
    "ST": "WAITING",
    "PE": "WAITING",
    "SE": "WAITING",
    "PT": "WAITING",
    "IN": "WAITING",
    "OI": "WAITING",
    "AC": "WAITING",
}


def normalize_status(value: Any) -> tuple[str, str]:
    status = str(value or "UNKNOWN").strip().upper()
    return status, STATUS_GROUPS.get(status, "UNKNOWN")


def average_runtimes(history: Iterable[dict[str, Any]]) -> dict[tuple[str, str], int]:
    grouped: dict[tuple[str, str], list[int]] = defaultdict(list)
    for row in history:
        duration = row.get("duration_seconds")
        if duration is not None and int(duration) >= 0:
            grouped[(str(row["application_id"]), str(row["job_name"]))].append(int(duration))
    return {key: round(mean(values)) for key, values in grouped.items()}


def normalize_jobs(rows: Iterable[dict[str, Any]], runtimes: dict[tuple[str, str], int]) -> list[JobState]:
    states: list[JobState] = []
    for row in rows:
        status, group = normalize_status(row.get("status"))
        key = (str(row["application_id"]), str(row["job_name"]))
        states.append(JobState(
            instance=str(row.get("instance", "UNKNOWN")),
            application_id=key[0],
            job_name=key[1],
            box_name=row.get("box_name"),
            status=status,
            status_group=group,
            start_time=parse_datetime(row.get("start_time")),
            end_time=parse_datetime(row.get("end_time")),
            run_number=int(row["run_number"]) if row.get("run_number") is not None else None,
            average_runtime_seconds=runtimes.get(key),
        ))
    return states


def _deadline(now: datetime, hhmm: str, timezone_name: str) -> datetime:
    zone = ZoneInfo(timezone_name)
    local_now = now.astimezone(zone)
    parsed = time.fromisoformat(hhmm)
    return datetime.combine(local_now.date(), parsed, tzinfo=zone)


def build_stream_snapshot(
    stream: StreamDefinition,
    states: Iterable[JobState],
    now: datetime,
    timezone_name: str,
    risk_window_minutes: int,
) -> StreamSnapshot:
    state_by_key = {(state.application_id, state.job_name): state for state in states}
    selected = [state_by_key.get((job.application_id, job.job_name)) for job in stream.jobs]
    groups = Counter(state.status_group if state else "WAITING" for state in selected)
    total = len(stream.jobs)
    completed = groups["COMPLETED"]
    failed = groups["FAILED"]
    running = groups["RUNNING"]
    waiting = total - completed - failed - running

    if failed:
        status = "FAILED"
    elif completed == total:
        status = "COMPLETED"
    elif running:
        status = "RUNNING"
    else:
        status = "WAITING"

    deadline = _deadline(now, stream.sla_time, timezone_name)
    completed_end_times = [state.end_time for state in selected if state and state.end_time]
    if completed == total:
        latest_end = max(completed_end_times) if completed_end_times else now
        sla_status = "MET" if latest_end.astimezone(deadline.tzinfo) <= deadline else "BREACHED"
    elif now.astimezone(deadline.tzinfo) > deadline:
        sla_status = "BREACHED"
    else:
        remaining_minutes = sum(
            job.expected_duration_minutes
            for job, state in zip(stream.jobs, selected)
            if not state or state.status_group != "COMPLETED"
        )
        projected = now.astimezone(deadline.tzinfo) + timedelta(minutes=remaining_minutes)
        within_window = deadline - now.astimezone(deadline.tzinfo) <= timedelta(minutes=risk_window_minutes)
        sla_status = "AT_RISK" if projected > deadline or within_window or failed else "ON_TARGET"

    return StreamSnapshot(
        stream_id=stream.stream_id,
        stream_name=stream.stream_name,
        stream_type=stream.stream_type,
        scheduler_type=stream.scheduler_type,
        status=status,
        sla_time=stream.sla_time,
        sla_status=sla_status,
        progress=round(completed * 100 / total),
        target_completion_time=stream.target_completion_time,
        business_impact=stream.business_impact if sla_status in {"AT_RISK", "BREACHED"} or failed else "",
        total_jobs=total,
        jobs_completed=completed,
        jobs_running=running,
        jobs_failed=failed,
        jobs_waiting=waiting,
    )


def utc_now() -> datetime:
    return datetime.now(timezone.utc)

