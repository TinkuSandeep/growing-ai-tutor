from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any


def parse_datetime(value: str | datetime | None) -> datetime | None:
    if value is None or isinstance(value, datetime):
        return value
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


@dataclass(frozen=True)
class JobDefinition:
    application_id: str
    job_name: str
    sequence: int
    expected_duration_minutes: int


@dataclass(frozen=True)
class StreamDefinition:
    stream_id: str
    stream_name: str
    stream_type: str
    scheduler_type: str
    sla_time: str
    target_completion_time: str
    business_impact: str
    jobs: tuple[JobDefinition, ...]


@dataclass(frozen=True)
class JobState:
    instance: str
    application_id: str
    job_name: str
    box_name: str | None
    status: str
    status_group: str
    start_time: datetime | None
    end_time: datetime | None
    run_number: int | None
    average_runtime_seconds: int | None = None

    def to_record(self) -> dict[str, Any]:
        data = asdict(self)
        data["start_time"] = iso(self.start_time)
        data["end_time"] = iso(self.end_time)
        return data


@dataclass(frozen=True)
class StreamSnapshot:
    stream_id: str
    stream_name: str
    stream_type: str
    scheduler_type: str
    status: str
    sla_time: str
    sla_status: str
    progress: int
    target_completion_time: str
    business_impact: str
    total_jobs: int
    jobs_completed: int
    jobs_running: int
    jobs_failed: int
    jobs_waiting: int

    def to_record(self) -> dict[str, Any]:
        return asdict(self)

