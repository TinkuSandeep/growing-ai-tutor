from __future__ import annotations

from collections import Counter
from typing import Any, Iterable

from .models import StreamDefinition


class SourceDataError(ValueError):
    pass


def validate_source_rows(rows: Iterable[dict[str, Any]], streams: Iterable[StreamDefinition]) -> None:
    rows = list(rows)
    required = {"application_id", "job_name", "status"}
    for index, row in enumerate(rows):
        missing = sorted(key for key in required if row.get(key) in (None, ""))
        if missing:
            raise SourceDataError(f"Source row {index} is missing required fields: {', '.join(missing)}")

    source_keys = [(str(row["application_id"]), str(row["job_name"])) for row in rows]
    duplicates = sorted(key for key, count in Counter(source_keys).items() if count > 1)
    if duplicates:
        raise SourceDataError(f"Duplicate current-state jobs returned by source: {duplicates}")

    configured = {
        (job.application_id, job.job_name)
        for stream in streams
        for job in stream.jobs
    }
    missing_jobs = sorted(configured - set(source_keys))
    if missing_jobs:
        raise SourceDataError(f"Configured jobs missing from source response: {missing_jobs}")

