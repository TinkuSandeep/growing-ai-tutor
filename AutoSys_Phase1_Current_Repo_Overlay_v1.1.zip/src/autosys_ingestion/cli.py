from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from .autosys import AEWSClient, MockAutoSysClient
from .config import load_streams, load_yaml
from .database import SQLServerRepository, SQLiteRepository
from .pipeline import IngestionPipeline


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Collect AutoSys data and load the Phase 1 database")
    parser.add_argument("--config", default=os.getenv("APP_CONFIG_PATH", "config/application.yaml"))
    parser.add_argument("--flows", default=os.getenv("FLOW_CONFIG_PATH", "config/critical_flows.yaml"))
    parser.add_argument("--init-db", action="store_true", help="Initialize the local SQLite schema")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    app = load_yaml(args.config)
    streams = load_streams(args.flows)
    autosys = app.get("autosys", {})
    database = app.get("database", {})
    collection = app.get("collection", {})
    source = os.getenv("AUTOSYS_SOURCE", autosys.get("source", "mock")).lower()
    instance = str(autosys.get("instance", "TEST"))

    if source == "mock":
        client = MockAutoSysClient(os.getenv("MOCK_DATA_PATH", autosys.get("mock_data_path", "config/mock_jobs.json")))
    elif source == "aews":
        template = os.getenv("AEWS_BASE_URL_TEMPLATE") or os.environ["AUTOSYS_API_BASE_URL_TEMPLATE"]
        client = AEWSClient(
            base_url=template.format(instance=instance.lower()),
            principal=os.getenv("AEWS_PRINCIPAL") or os.environ["AUTOSYS_API_USER"],
            secret=os.getenv("AEWS_SECRET") or os.environ["AUTOSYS_API_PASSWORD"],
            verify_tls=(os.getenv("AEWS_VERIFY_TLS") or os.getenv("AUTOSYS_API_VERIFY_SSL", "true")).lower() == "true",
            timeout_seconds=int(os.getenv("AEWS_TIMEOUT_SECONDS") or os.getenv("AUTOSYS_API_TIMEOUT", "30")),
        )
    else:
        raise ValueError(f"Unsupported autosys source: {source}")

    driver = str(database.get("driver", "sqlite")).lower()
    if driver == "sqlite":
        schema = Path(__file__).resolve().parents[2] / "sql" / "sqlite_schema.sql"
        repository = SQLiteRepository(database.get("sqlite_path", "output/autosys_phase1.db"), schema)
        if args.init_db:
            repository.initialize()
    elif driver == "sqlserver":
        connection_env = database.get("sqlserver_connection_env", "SQLSERVER_CONNECTION_STRING")
        repository = SQLServerRepository(os.environ[connection_env])
    else:
        raise ValueError(f"Unsupported database driver: {driver}")

    try:
        result = IngestionPipeline(
            client=client,
            repository=repository,
            streams=streams,
            environment=str(app.get("environment", "local")),
            source_instance=instance,
            timezone_name=str(app.get("timezone", "UTC")),
            history_lookback_days=int(collection.get("history_lookback_days", 30)),
            risk_window_minutes=int(collection.get("risk_window_minutes", 30)),
        ).run()
        print(json.dumps(result, indent=2))
        return 0
    finally:
        repository.close()
