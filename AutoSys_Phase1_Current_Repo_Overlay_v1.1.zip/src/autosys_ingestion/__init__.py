"""AutoSys Phase 1 ingestion package."""

__version__ = "1.0.0"

