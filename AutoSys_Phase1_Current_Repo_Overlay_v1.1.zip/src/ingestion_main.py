"""Separate Phase 1 database-ingestion entry point.

This file does not import or modify the existing src/main.py monitoring entry point.
"""

from autosys_ingestion.cli import main


if __name__ == "__main__":
    raise SystemExit(main())

