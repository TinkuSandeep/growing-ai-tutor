import unittest
from datetime import datetime, timezone

from autosys_ingestion.engines import average_runtimes, build_stream_snapshot, normalize_jobs, normalize_status
from autosys_ingestion.models import JobDefinition, StreamDefinition
from autosys_ingestion.validation import SourceDataError, validate_source_rows


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.stream = StreamDefinition(
            stream_id="s1", stream_name="Stream", stream_type="BATCH", scheduler_type="AUTOSYS",
            sla_time="12:00", target_completion_time="11:30", business_impact="Delayed",
            jobs=(
                JobDefinition("APP", "J1", 1, 10),
                JobDefinition("APP", "J2", 2, 20),
            ),
        )

    def test_status_normalization(self):
        self.assertEqual(normalize_status("su"), ("SU", "COMPLETED"))
        self.assertEqual(normalize_status("FA"), ("FA", "FAILED"))
        self.assertEqual(normalize_status("new"), ("NEW", "UNKNOWN"))

    def test_average_runtime(self):
        values = average_runtimes([
            {"application_id": "APP", "job_name": "J1", "duration_seconds": 10},
            {"application_id": "APP", "job_name": "J1", "duration_seconds": 20},
        ])
        self.assertEqual(values[("APP", "J1")], 15)

    def test_stream_progress_and_sla(self):
        rows = [
            {"instance": "T", "application_id": "APP", "job_name": "J1", "status": "SU",
             "start_time": "2026-09-11T14:00:00Z", "end_time": "2026-09-11T14:10:00Z"},
            {"instance": "T", "application_id": "APP", "job_name": "J2", "status": "RU",
             "start_time": "2026-09-11T14:11:00Z", "end_time": None},
        ]
        states = normalize_jobs(rows, {})
        snapshot = build_stream_snapshot(
            self.stream, states, datetime(2026, 9, 11, 14, 15, tzinfo=timezone.utc),
            "America/New_York", 30,
        )
        self.assertEqual(snapshot.progress, 50)
        self.assertEqual(snapshot.status, "RUNNING")
        self.assertEqual(snapshot.sla_status, "ON_TARGET")

    def test_missing_configured_job_is_rejected(self):
        with self.assertRaises(SourceDataError):
            validate_source_rows([
                {"application_id": "APP", "job_name": "J1", "status": "SU"}
            ], [self.stream])


if __name__ == "__main__":
    unittest.main()
