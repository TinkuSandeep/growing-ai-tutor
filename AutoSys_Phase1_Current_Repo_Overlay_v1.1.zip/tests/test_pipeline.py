import sqlite3
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from autosys_ingestion.autosys import MockAutoSysClient
from autosys_ingestion.config import load_streams
from autosys_ingestion.database import SQLiteRepository
from autosys_ingestion.pipeline import IngestionPipeline


ROOT = Path(__file__).resolve().parents[1]


class PipelineTests(unittest.TestCase):
    def test_end_to_end_mock_load(self):
        with tempfile.TemporaryDirectory() as directory:
            db_path = Path(directory) / "phase1.db"
            repository = SQLiteRepository(db_path, ROOT / "sql" / "sqlite_schema.sql")
            repository.initialize()
            pipeline = IngestionPipeline(
                client=MockAutoSysClient(ROOT / "config" / "mock_jobs.json"),
                repository=repository,
                streams=load_streams(ROOT / "config" / "critical_flows.yaml"),
                environment="test",
                source_instance="TEST",
                timezone_name="America/New_York",
            )
            result = pipeline.run(datetime(2026, 9, 11, 12, 30, tzinfo=timezone.utc))
            self.assertEqual(result["status"], "SUCCEEDED")
            repository.close()

            connection = sqlite3.connect(db_path)
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM cp_job_current_state").fetchone()[0], 3)
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM cp_job_status_history").fetchone()[0], 3)
            row = connection.execute(
                "SELECT progress, status FROM cp_stream_current_state WHERE stream_id='sample-rto-reporting'"
            ).fetchone()
            self.assertEqual(row, (33, "RUNNING"))
            self.assertEqual(connection.execute("SELECT status FROM cp_collection_run").fetchone()[0], "SUCCEEDED")
            connection.close()


if __name__ == "__main__":
    unittest.main()

