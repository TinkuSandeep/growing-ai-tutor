# Phase 1 Integration with the Current AutoSys Monitoring Repository

## Resulting design

The current repository will build one application image with two independent entry points:

| Workload | Entry point | Output |
| --- | --- | --- |
| Existing monitoring | `python src/main.py` | Existing HTML/email report |
| Phase 1 ingestion | `python src/ingestion_main.py --config config/ingestion.yaml --flows config/critical_flows.yaml` | SQL Server records for Grafana |

This overlay deliberately does not contain `src/main.py`, `src/scripts/monitoring.py`, `src/scripts/build_html.py`, or `src/scripts/send_email.py`. Extracting it into the repository therefore does not replace the existing monitoring implementation.

## Files added

- `src/ingestion_main.py`: separate scheduled-job entry point.
- `src/autosys_ingestion/`: generic collection, calculation, validation and persistence modules.
- `config/ingestion.yaml`: ingestion runtime configuration.
- `config/critical_flows.yaml`: critical streams and jobs.
- `config/mock_jobs.json`: safe synthetic data.
- `sql/`: SQLite local schema, SQL Server reference schema and Grafana validation queries.
- `tests/`: unit and mock end-to-end tests.
- `requirements-phase1.txt` and `requirements-phase1-sqlserver.txt`: additions that do not replace the existing dependency files.
- `scripts/start_ingestion.sh`: container/OCP command.
- `scripts/run_ingestion_local.bat`: Windows mock execution.
- `scripts/run_ingestion_tests.bat`: Windows test execution.

## Existing environment compatibility

The ingestion entry point accepts the settings already documented by the current repository:

- `AUTOSYS_API_BASE_URL_TEMPLATE`
- `AUTOSYS_API_USER`
- `AUTOSYS_API_PASSWORD`
- `AUTOSYS_API_VERIFY_SSL`
- `AUTOSYS_API_TIMEOUT`

The only required new sensitive setting is `SQLSERVER_CONNECTION_STRING`. It should be mounted only into the ingestion workload. Existing monitoring does not need database access.

## Local validation

1. Make a working copy of the repository.
2. Extract this overlay into its root.
3. Do not overwrite existing files if the operating system reports a conflict; review the conflict first.
4. Run `scripts\run_ingestion_tests.bat`.
5. Run `scripts\run_ingestion_local.bat`.
6. Confirm `output\autosys_phase1.db` was created.
7. Run the existing monitoring tests and existing `src/main.py` separately to confirm no regression.

## Lower-environment integration

1. Review `sql/sqlserver_schema.sql` with the database team.
2. Merge `requirements-phase1-sqlserver.txt` into the existing dependency process.
3. Replace synthetic flow/job names in `config/critical_flows.yaml`.
4. Set `database.driver: sqlserver` in the deployed ingestion configuration.
5. Set `AUTOSYS_SOURCE=aews`.
6. Mount the existing AEWS settings and the new database setting.
7. Schedule `scripts/start_ingestion.sh` as a separate workload.
8. Reconcile collected values with the AutoSys console before Grafana onboarding.

## Isolation requirements

- The monitoring and ingestion jobs must have separate schedules and exit codes.
- Database failure must not stop the existing monitoring job.
- Email failure must not stop database ingestion.
- Use `Forbid` concurrency or an equivalent scheduler rule to prevent overlapping ingestion cycles.
- Keep all AEWS operations read-only during Phase 1.

## Known integration point

The included read-only AEWS client uses the endpoint contract documented in the current README. If the actual internal response fields differ from the generic fixture, update only `src/autosys_ingestion/autosys.py` or wrap the existing internal `src/scripts/autosys_api.py`. The calculation and persistence modules do not need to change.
