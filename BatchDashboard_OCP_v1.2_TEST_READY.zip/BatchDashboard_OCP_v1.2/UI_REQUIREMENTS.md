# Dashboard UI handoff requirements

These requirements are recorded for the dashboard/UI team. This Python package
does not contain or deploy the Grafana/dashboard implementation.

## Critical Batch Job Summary

- Display the Failed value in red regardless of whether the value is zero or
  greater than zero.

## Job detail column order

1. Job Name
2. Job Process Name
3. Job Start Time
4. Job End Time
5. Job Status
6. Avg Start Time
7. Avg End Time
8. Avg Duration (mins)
