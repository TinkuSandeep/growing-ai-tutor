from __future__ import annotations

from .errors import DataValidationError


TEXT_STATUS = {
    "SUCCESS": "SU",
    "RUNNING": "RU",
    "FAILURE": "FA",
    "FAILED": "FA",
    "TERMINATED": "TE",
    "STARTING": "ST",
    "PEND_MACHINE": "PE",
    "PENDING_MACHINE": "PE",
    "EVENT_WAIT": "SE",
    "PEND_EVENT": "SE",
    "PEND_TIME": "PT",
    "INACTIVE": "IN",
    "ACTIVATED": "AC",
    "ON_ICE": "OI",
    "ON_HOLD": "OH",
    "QUE_WAIT": "QW",
    "WAIT_REPLY": "WR",
    "SUSPENDED": "SP",
}

# Broadcom AEWS numeric values confirmed by the documented examples for
# RUNNING/SUCCESS/FAILURE/TERMINATED and the standard AutoSys status set.
NUMERIC_STATUS = {
    0: "IN",
    1: "RU",
    2: "ST",
    4: "SU",
    5: "FA",
    6: "TE",
    7: "OI",
    8: "OH",
}

ACTIVE_OR_WAITING = {"RU", "ST", "PE", "SE", "PT", "AC", "QW", "WR", "SP"}
TERMINAL = {"SU", "FA", "TE"}


def normalize_status(status: object, string_status: object = None) -> str:
    if string_status is not None:
        candidate = str(string_status).strip().upper().replace(" ", "_").replace("-", "_")
        if candidate in TEXT_STATUS:
            return TEXT_STATUS[candidate]
        if candidate in set(TEXT_STATUS.values()):
            return candidate

    if isinstance(status, str):
        candidate = status.strip().upper()
        if candidate in set(TEXT_STATUS.values()):
            return candidate
        if candidate in TEXT_STATUS:
            return TEXT_STATUS[candidate]
        if candidate.isdigit():
            status = int(candidate)

    if isinstance(status, (int, float)) and int(status) in NUMERIC_STATUS:
        return NUMERIC_STATUS[int(status)]

    raise DataValidationError(f"Unsupported AEWS status: status={status!r}, strStatus={string_status!r}")
