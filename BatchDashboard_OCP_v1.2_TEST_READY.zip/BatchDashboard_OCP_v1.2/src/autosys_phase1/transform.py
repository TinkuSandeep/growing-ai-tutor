from __future__ import annotations

from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

from .errors import DataValidationError
from .models import RuntimeUpdate, TargetJob
from .status import ACTIVE_OR_WAITING, TERMINAL, normalize_status


def _collect_runs(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if not isinstance(payload, dict):
        return []

    for key in ("jobRun", "jobRuns", "items", "data", "result"):
        value = payload.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
        if isinstance(value, dict):
            nested = _collect_runs(value)
            return nested or [value]

    # A single job-run response is also valid.
    if any(key in payload for key in ("runNum", "runStartTime", "strStatus", "status")):
        return [payload]
    return []


def _parse_run_number(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return -1


def _parse_timestamp(value: Any, timezone: str, naive: bool) -> datetime | None:
    if value in (None, "", 0, "0"):
        return None
    text = str(value).strip()
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise DataValidationError(f"Unsupported AEWS timestamp: {text!r}") from exc
    if parsed.tzinfo is None:
        raise DataValidationError(f"AEWS timestamp has no UTC offset: {text!r}")
    local = parsed.astimezone(ZoneInfo(timezone))
    return local.replace(tzinfo=None) if naive else local


def latest_runtime_update(
    target: TargetJob,
    payload: Any,
    timezone: str,
    store_naive_local_time: bool,
) -> RuntimeUpdate:
    runs = _collect_runs(payload)
    if not runs:
        raise DataValidationError("AEWS response contains no job runs")

    matching = [
        row for row in runs
        if not row.get("name") or str(row.get("name")).casefold() == target.job_name.casefold()
    ]
    if not matching:
        raise DataValidationError("AEWS response contains no run matching the requested job name")

    latest = max(
        matching,
        key=lambda row: (
            _parse_run_number(row.get("runNum") or row.get("runNumber")),
            str(row.get("runStartTime") or ""),
        ),
    )
    run_number = _parse_run_number(latest.get("runNum") or latest.get("runNumber"))
    if run_number < 0:
        raise DataValidationError("Latest AEWS run has no valid runNum")

    status = normalize_status(latest.get("status"), latest.get("strStatus"))
    start_time = _parse_timestamp(
        latest.get("runStartTime"), timezone, store_naive_local_time
    )
    end_time = _parse_timestamp(
        latest.get("runEndTime"), timezone, store_naive_local_time
    )

    if status in ACTIVE_OR_WAITING:
        end_time = None
    if status in {"RU"} and start_time is None:
        raise DataValidationError("Running job has no runStartTime")
    if status in TERMINAL and (start_time is None or end_time is None):
        raise DataValidationError(f"Terminal job {status} is missing a start or end time")

    return RuntimeUpdate(
        target=target,
        run_number=run_number,
        job_start_time=start_time,
        job_end_time=end_time,
        job_status=status,
    )

