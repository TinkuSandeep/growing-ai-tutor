from __future__ import annotations

import json
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterable, Iterator
from zoneinfo import ZoneInfo

from .config import DatabaseSettings
from .errors import DatabaseError
from .models import RuntimeUpdate, TargetJob


ET_ZONE = ZoneInfo("America/New_York")


def _to_sql_datetime(value: datetime | str | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        text = value.strip()
        if text.casefold() in {"", "null", "none"}:
            return None
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError as exc:
            raise DatabaseError(f"Unsupported target timestamp: {value!r}") from exc
    elif isinstance(value, datetime):
        parsed = value
    else:
        raise DatabaseError(f"Unsupported target timestamp type: {type(value).__name__}")
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(ET_ZONE).replace(tzinfo=None)
    return parsed.strftime("%Y-%m-%d %H:%M:%S")


def update_procedure_command(
    settings: DatabaseSettings, update: RuntimeUpdate
) -> tuple[str, tuple[object, ...]]:
    """Build the four-parameter update call; business logic remains in SQL."""
    sql = f"""
        EXEC {settings.quoted_update_stored_procedure}
            @job_name = ?,
            @job_start_time = ?,
            @job_end_time = ?,
            @job_status = ?
    """
    parameters: tuple[object, ...] = (
        update.target.job_name,
        _to_sql_datetime(update.job_start_time),
        _to_sql_datetime(update.job_end_time),
        update.job_status,
    )
    return sql, parameters


def summary_procedure_command(settings: DatabaseSettings) -> str:
    """Build the parameterless summary refresh call."""
    return f"EXEC {settings.quoted_summary_stored_procedure}"


def stream_procedure_command(settings: DatabaseSettings) -> str:
    """Build the parameterless critical-batch stream refresh call."""
    return f"EXEC {settings.quoted_stream_stored_procedure}"


class SQLServerRepository:
    def __init__(self, settings: DatabaseSettings):
        self.settings = settings

    @contextmanager
    def _connection(self) -> Iterator[object]:
        try:
            import pyodbc
        except ImportError as exc:
            raise DatabaseError(
                "pyodbc is required; install requirements-sqlserver.txt"
            ) from exc
        try:
            connection = pyodbc.connect(
                self.settings.connection_string(), autocommit=False
            )
            yield connection
        except DatabaseError:
            raise
        except Exception as exc:
            raise DatabaseError(f"SQL Server operation failed: {exc}") from exc
        finally:
            if "connection" in locals():
                connection.close()

    def load_targets(self) -> list[TargetJob]:
        """Discover jobs through cp_Get_Critical_Batch_Jobs.

        Other returned columns are intentionally ignored. Python uses only the
        job name and AutoSys instance.
        """
        with self._connection() as connection:
            cursor = connection.cursor()
            cursor.execute(f"EXEC {self.settings.quoted_discovery_stored_procedure}")
            if cursor.description is None:
                raise DatabaseError("Job discovery procedure returned no result set")
            columns = [str(item[0]).strip().casefold() for item in cursor.description]
            name_key = self.settings.job_name_column.casefold()
            instance_key = self.settings.instance_column.casefold()
            if name_key not in columns or instance_key not in columns:
                raise DatabaseError(
                    "Job discovery procedure must return columns "
                    f"{self.settings.job_name_column!r} and "
                    f"{self.settings.instance_column!r}; returned {columns}"
                )
            name_index = columns.index(name_key)
            instance_index = columns.index(instance_key)
            rows = cursor.fetchall()

        targets: list[TargetJob] = []
        for row_number, row in enumerate(rows, start=1):
            job_name = "" if row[name_index] is None else str(row[name_index]).strip()
            instance = (
                "" if row[instance_index] is None else str(row[instance_index]).strip().upper()
            )
            if not job_name or not instance:
                raise DatabaseError(
                    f"Discovery row {row_number} has a blank job name or instance"
                )
            targets.append(TargetJob(job_name=job_name, instance=instance))
        _validate_unique_targets(targets)
        return targets

    def apply_updates(self, updates: Iterable[RuntimeUpdate]) -> int:
        values = list(updates)
        if not values:
            return 0
        with self._connection() as connection:
            cursor = connection.cursor()
            try:
                for update in values:
                    sql, parameters = update_procedure_command(self.settings, update)
                    cursor.execute(sql, *parameters)
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return len(values)

    def refresh_summary(self) -> None:
        """Refresh the database-owned critical batch summary in one transaction."""
        with self._connection() as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(summary_procedure_command(self.settings))
                connection.commit()
            except Exception:
                connection.rollback()
                raise

    def refresh_stream(self) -> None:
        """Refresh database-owned stream status, completion and SLA values."""
        with self._connection() as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(stream_procedure_command(self.settings))
                connection.commit()
            except Exception:
                connection.rollback()
                raise


def load_mock_targets(path: str | Path) -> list[TargetJob]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, list):
        raise DatabaseError("Mock target file must contain a JSON list")
    targets = [
        TargetJob(
            job_name=str(item.get("job_name", "")).strip(),
            instance=str(item.get("instance_name", "")).strip().upper(),
        )
        for item in payload
        if isinstance(item, dict)
    ]
    if any(not item.job_name or not item.instance for item in targets):
        raise DatabaseError("Every mock target requires job_name and instance_name")
    _validate_unique_targets(targets)
    return targets


def _validate_unique_targets(targets: list[TargetJob]) -> None:
    seen: set[str] = set()
    duplicates: set[str] = set()
    for target in targets:
        key = target.job_name.casefold()
        if key in seen:
            duplicates.add(target.job_name)
        seen.add(key)
    if duplicates:
        raise DatabaseError(
            "The update procedure identifies rows by job_name; duplicate names "
            f"are not allowed: {sorted(duplicates)}"
        )
