from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class TargetJob:
    """The only catalog values used by the Python integration layer."""

    job_name: str
    instance: str


@dataclass(frozen=True)
class RuntimeUpdate:
    target: TargetJob
    run_number: int
    job_start_time: datetime | None
    job_end_time: datetime | None
    job_status: str
