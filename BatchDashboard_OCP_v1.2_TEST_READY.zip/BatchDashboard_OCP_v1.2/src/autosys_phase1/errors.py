class Phase1Error(Exception):
    """Base application error."""


class ConfigurationError(Phase1Error):
    """Configuration is missing or unsafe."""


class AEWSError(Phase1Error):
    """AEWS request or response failed validation."""


class DataValidationError(Phase1Error):
    """Runtime data cannot safely be written."""


class DatabaseError(Phase1Error):
    """SQL Server operation failed."""

