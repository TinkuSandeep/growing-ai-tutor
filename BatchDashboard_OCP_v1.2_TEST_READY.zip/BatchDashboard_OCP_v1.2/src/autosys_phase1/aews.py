from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import quote

import requests
from requests.adapters import HTTPAdapter
from requests.auth import HTTPBasicAuth
from urllib3.util.retry import Retry

from .config import AutoSysSettings
from .errors import AEWSError
from .models import TargetJob


class RuntimeSource(Protocol):
    def get_job_runs(self, target: TargetJob) -> Any: ...


class AEWSClient:
    """Read-only AutoSys Web Services client."""

    def __init__(self, settings: AutoSysSettings):
        self.settings = settings
        principal, secret = settings.credentials()
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(principal, secret)
        self.session.headers.update({"Accept": "application/json"})
        self._last_request_started: float | None = None
        self.request_attempts = 0
        self.retry_count = 0
        self.rate_limit_responses = 0
        retry = Retry(
            total=settings.max_retries,
            connect=settings.max_retries,
            read=settings.max_retries,
            backoff_factor=settings.retry_backoff_seconds,
            backoff_max=settings.retry_backoff_max_seconds,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET"}),
            raise_on_status=False,
            respect_retry_after_header=settings.honor_retry_after,
        )
        self.session.mount("https://", HTTPAdapter(max_retries=retry))

    def _pace_request(self) -> None:
        delay = self.settings.request_delay_seconds
        if delay > 0 and self._last_request_started is not None:
            remaining = delay - (time.monotonic() - self._last_request_started)
            if remaining > 0:
                time.sleep(remaining)
        self._last_request_started = time.monotonic()

    def _record_attempts(self, response: requests.Response) -> None:
        retries = getattr(getattr(response, "raw", None), "retries", None)
        history = tuple(getattr(retries, "history", ()) or ())
        self.request_attempts += 1 + len(history)
        self.retry_count += len(history)
        self.rate_limit_responses += sum(item.status == 429 for item in history)
        if response.status_code == 429:
            self.rate_limit_responses += 1

    def metrics(self) -> dict[str, int]:
        return {
            "api_request_attempts": self.request_attempts,
            "api_retries": self.retry_count,
            "api_rate_limit_responses": self.rate_limit_responses,
        }

    def _base_url(self, instance: str) -> str:
        template = self.settings.base_url_template
        try:
            value = template.format(instance=instance.lower(), INSTANCE=instance.upper())
        except KeyError as exc:
            raise AEWSError(f"Unknown placeholder in base_url_template: {exc}") from exc
        return value.rstrip("/")

    def get_job_runs(self, target: TargetJob) -> Any:
        url = f"{self._base_url(target.instance)}/job-run-info/{quote(target.job_name, safe='')}"
        params = {"version": self.settings.api_version, "verbose": 1}
        try:
            self._pace_request()
            response = self.session.get(
                url,
                params=params,
                timeout=self.settings.timeout_seconds,
                verify=self.settings.verify_ssl,
            )
        except requests.RequestException as exc:
            raise AEWSError(f"AEWS request failed for {target.job_name}: {exc}") from exc

        self._record_attempts(response)

        if response.status_code != 200:
            body = response.text[:300].replace("\n", " ")
            raise AEWSError(
                f"AEWS returned HTTP {response.status_code} for {target.job_name}: {body}"
            )
        try:
            return response.json()
        except ValueError as exc:
            raise AEWSError(f"AEWS returned non-JSON data for {target.job_name}") from exc

    def health_check(self, instance: str) -> None:
        url = f"{self._base_url(instance)}/job"
        self._pace_request()
        response = self.session.get(
            url,
            params={"count": 1, "version": self.settings.api_version},
            timeout=self.settings.timeout_seconds,
            verify=self.settings.verify_ssl,
        )
        self._record_attempts(response)
        if response.status_code != 200:
            raise AEWSError(f"AEWS health check returned HTTP {response.status_code} for {instance}")


class MockAEWSClient:
    def __init__(self, fixture_path: str | Path):
        with Path(fixture_path).open("r", encoding="utf-8") as handle:
            self.payload = json.load(handle)

    def get_job_runs(self, target: TargetJob) -> Any:
        key = f"{target.instance}:{target.job_name}"
        if key not in self.payload:
            raise AEWSError(f"Mock fixture has no entry for {key}")
        return self.payload[key]

    def metrics(self) -> dict[str, int]:
        return {
            "api_request_attempts": 0,
            "api_retries": 0,
            "api_rate_limit_responses": 0,
        }
