from __future__ import annotations

import argparse
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

from .aews import AEWSClient, MockAEWSClient
from .config import load_settings
from .database import SQLServerRepository, load_mock_targets
from .models import RuntimeUpdate, TargetJob
from .transform import latest_runtime_update


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Database-driven AutoSys AEWS runtime ingestion"
    )
    parser.add_argument("--settings", default="config/settings.yaml")
    parser.add_argument("--env-file", default=".env")
    parser.add_argument(
        "--write",
        action="store_true",
        help="Call the configured target update procedure after every AEWS job passes",
    )
    parser.add_argument(
        "--mock-targets",
        help="Offline JSON replacement for cp_Get_Critical_Batch_Jobs",
    )
    parser.add_argument(
        "--mock-aews",
        help="Offline AEWS JSON fixture",
    )
    return parser.parse_args()


def _json_default(value: Any):
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(type(value).__name__)


def _configure_logging(log_path: Path | None) -> logging.Logger:
    logger = logging.getLogger("autosys_sp_ingestion")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    if log_path is not None:
        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    return logger


def _job_result(target: TargetJob) -> dict[str, Any]:
    return {
        "job_name": target.job_name,
        "instance_name": target.instance,
        "source": "AEWS",
    }


def main() -> int:
    args = _arguments()
    load_dotenv(args.env_file, override=False)
    settings = load_settings(args.settings)

    if bool(args.mock_targets) != bool(args.mock_aews):
        raise SystemExit("Offline testing requires both --mock-targets and --mock-aews")
    if args.write and (args.mock_targets or args.mock_aews):
        raise SystemExit("--write cannot be combined with mock data")

    started = datetime.now(ZoneInfo(settings.autosys.timezone))
    stamp = started.strftime("%Y%m%d_%H%M%S_%f")
    report_path: Path | None = None
    log_path: Path | None = None
    if settings.ingestion.file_output_enabled:
        output_dir = Path(settings.ingestion.output_directory)
        log_dir = Path(settings.ingestion.log_directory)
        output_dir.mkdir(parents=True, exist_ok=True)
        log_dir.mkdir(parents=True, exist_ok=True)
        report_path = output_dir / f"autosys_ingestion_{stamp}.json"
        log_path = log_dir / f"autosys_ingestion_{stamp}.log"
    logger = _configure_logging(log_path)

    repository = SQLServerRepository(settings.database)
    try:
        targets = (
            load_mock_targets(args.mock_targets)
            if args.mock_targets
            else repository.load_targets()
        )
    except Exception as exc:
        logger.error("JOB DISCOVERY FAILED error=%s", exc)
        print(json.dumps({"result": "DISCOVERY_FAILED", "error": str(exc)}, indent=2))
        return 1

    minimum = settings.ingestion.require_minimum_target_count
    if minimum is not None and len(targets) < minimum:
        error = f"Discovery returned {len(targets)} jobs; minimum required is {minimum}"
        logger.error(error)
        print(json.dumps({"result": "DISCOVERY_FAILED", "error": error}, indent=2))
        return 1
    if not targets:
        logger.error("Job discovery returned zero jobs")
        print(json.dumps({"result": "DISCOVERY_FAILED", "error": "No jobs returned"}, indent=2))
        return 1

    try:
        source = MockAEWSClient(args.mock_aews) if args.mock_aews else AEWSClient(settings.autosys)
    except Exception as exc:
        logger.error("AEWS INITIALIZATION FAILED error=%s", exc)
        print(json.dumps({"result": "AEWS_INITIALIZATION_FAILED", "error": str(exc)}, indent=2))
        return 1

    logger.info(
        "Starting AutoSys-only %s for %d dynamically discovered jobs",
        "collection and target write" if args.write else "dry run",
        len(targets),
    )
    results: list[dict[str, Any]] = []
    updates: list[RuntimeUpdate] = []
    failed = 0
    for target in targets:
        result = _job_result(target)
        try:
            payload = source.get_job_runs(target)
            update = latest_runtime_update(
                target,
                payload,
                settings.autosys.timezone,
                settings.autosys.store_naive_local_time,
            )
            updates.append(update)
            result.update(
                {
                    "run_number": update.run_number,
                    "job_start_time_et": update.job_start_time,
                    "job_end_time_et": update.job_end_time,
                    "job_status": update.job_status,
                    "result": "PASSED",
                }
            )
            logger.info(
                "PASSED instance=%s job=%s status=%s",
                target.instance,
                target.job_name,
                update.job_status,
            )
        except Exception as exc:
            failed += 1
            result.update({"result": "FAILED", "error": str(exc)})
            logger.error(
                "FAILED instance=%s job=%s error=%s",
                target.instance,
                target.job_name,
                exc,
            )
        results.append(result)

    updated = 0
    write_error: str | None = None
    if args.write:
        if failed and settings.ingestion.abort_on_job_error:
            write_error = "Target write blocked because one or more AEWS jobs failed"
        else:
            try:
                updated = repository.apply_updates(updates)
                logger.info(
                    "Committed %d updates through %s",
                    updated,
                    settings.database.update_stored_procedure,
                )
            except Exception as exc:
                write_error = str(exc)
        if write_error:
            logger.error("TARGET WRITE FAILED error=%s", write_error)

    completed = datetime.now(ZoneInfo(settings.autosys.timezone))
    if failed or write_error:
        overall = "INGESTION_FAILED" if args.write else "DRY_RUN_FAILED"
    else:
        overall = "INGESTION_PASSED" if args.write else "DRY_RUN_PASSED"
    api_metrics = source.metrics()
    report = {
        "version": "1.2.0",
        "result": overall,
        "mode": "write" if args.write else "dry_run",
        "job_catalog": (
            "mock" if args.mock_targets else settings.database.discovery_stored_procedure
        ),
        "started_at_et": started,
        "completed_at_et": completed,
        "requested": len(targets),
        "succeeded": len(targets) - failed,
        "failed": failed,
        "target_database_updated": updated > 0,
        "target_rows_updated": updated,
        "target_write_error": write_error,
        **api_metrics,
        "jobs": results,
    }
    if report_path is not None:
        report_path.write_text(
            json.dumps(report, indent=2, default=_json_default), encoding="utf-8"
        )
        logger.info("Report written to %s", report_path)
        logger.info("Log written to %s", log_path)
    print(
        json.dumps(
            {
                "result": overall,
                "requested": len(targets),
                "succeeded": len(targets) - failed,
                "failed": failed,
                "target_database_updated": updated > 0,
                "target_rows_updated": updated,
                "target_write_error": write_error,
                **api_metrics,
                "report": str(report_path) if report_path is not None else None,
                "log": str(log_path) if log_path is not None else None,
            },
            indent=2,
        )
    )
    return 0 if failed == 0 and write_error is None else 1


if __name__ == "__main__":
    raise SystemExit(main())
