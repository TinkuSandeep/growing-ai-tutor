from datetime import datetime

import pytest

from autosys_phase1.errors import DataValidationError
from autosys_phase1.models import TargetJob
from autosys_phase1.transform import latest_runtime_update


TARGET = TargetJob(job_name="JOB_A", instance="PB3")


def test_latest_success_is_converted_to_eastern_time():
    payload = {"jobRun": [
        {
            "name": "JOB_A",
            "runNum": 10,
            "runStartTime": "2026-09-21T10:00:00+0000",
            "runEndTime": "2026-09-21T10:10:00+0000",
            "status": 4,
            "strStatus": "SUCCESS",
        },
        {
            "name": "JOB_A",
            "runNum": 11,
            "runStartTime": "2026-09-21T11:00:00+0000",
            "runEndTime": "2026-09-21T11:15:00+0000",
            "status": 4,
            "strStatus": "SUCCESS",
        },
    ]}
    update = latest_runtime_update(TARGET, payload, "America/New_York", True)
    assert update.run_number == 11
    assert update.job_status == "SU"
    assert update.job_start_time == datetime(2026, 9, 21, 7, 0)
    assert update.job_end_time == datetime(2026, 9, 21, 7, 15)


def test_running_job_always_has_null_end_time():
    payload = {
        "name": "JOB_A",
        "runNum": 12,
        "runStartTime": "2026-09-21T12:00:00+0000",
        "runEndTime": "2026-09-21T12:01:00+0000",
        "status": 1,
        "strStatus": "RUNNING",
    }
    update = latest_runtime_update(TARGET, payload, "America/New_York", True)
    assert update.job_status == "RU"
    assert update.job_end_time is None


def test_unknown_status_is_rejected():
    payload = {
        "name": "JOB_A",
        "runNum": 13,
        "runStartTime": "2026-09-21T12:00:00+0000",
        "runEndTime": None,
        "status": 999,
        "strStatus": "UNKNOWN_VALUE",
    }
    with pytest.raises(DataValidationError, match="Unsupported AEWS status"):
        latest_runtime_update(TARGET, payload, "America/New_York", True)


def test_terminal_job_without_end_time_is_rejected():
    payload = {
        "name": "JOB_A",
        "runNum": 14,
        "runStartTime": "2026-09-21T12:00:00+0000",
        "runEndTime": None,
        "status": 4,
        "strStatus": "SUCCESS",
    }
    with pytest.raises(DataValidationError, match="missing a start or end time"):
        latest_runtime_update(TARGET, payload, "America/New_York", True)
