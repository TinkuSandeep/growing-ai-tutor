import pytest

from autosys_phase1.config import (
    ConfigurationError,
    load_settings,
    quote_sql_object_name,
)


def test_quotes_three_part_table_name():
    assert quote_sql_object_name("TCOO_TOOLS.dbo.cp_critical_batch_jobs") == (
        "[TCOO_TOOLS].[dbo].[cp_critical_batch_jobs]"
    )


def test_rejects_unsafe_table_name():
    with pytest.raises(ConfigurationError):
        quote_sql_object_name("dbo.jobs; DROP TABLE dbo.jobs")


def test_v12_ocp_contract_uses_scheduler_instance_and_refresh_procedures():
    settings = load_settings("config/settings.yaml")
    assert settings.database.instance_column == "scheduler_instance"
    assert settings.database.summary_stored_procedure == (
        "dbo.cp_Update_Critical_Batch_Summary"
    )
    assert settings.database.update_stored_procedure == (
        "dbo.cp_Update_Job_Execution_Status"
    )
    assert settings.database.stream_stored_procedure == (
        "dbo.cp_Update_Critical_Batch_Stream"
    )
    assert settings.autosys.request_delay_seconds == 0.2
    assert settings.autosys.max_retries == 3
    assert settings.autosys.honor_retry_after is True
    assert settings.ingestion.file_output_enabled is False
