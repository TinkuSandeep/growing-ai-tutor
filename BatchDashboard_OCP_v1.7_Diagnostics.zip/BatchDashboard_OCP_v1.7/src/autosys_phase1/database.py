from __future__ import annotations

import json
import logging
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from time import perf_counter
from typing import Iterable, Iterator
from zoneinfo import ZoneInfo

from .config import DatabaseSettings
from .errors import DatabaseError
from .models import (
    RuntimeSnapshot,
    RuntimeUpdate,
    TargetJob,
    UpdateBatchResult,
    UpdateVerification,
)


ET_ZONE = ZoneInfo("America/New_York")


def _to_sql_datetime(value: datetime | str | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        text = value.strip()
        if text.casefold() in {"", "null", "none"}:
            return None
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError as exc:
            raise DatabaseError(f"Unsupported target timestamp: {value!r}") from exc
    elif isinstance(value, datetime):
        parsed = value
    else:
        raise DatabaseError(f"Unsupported target timestamp type: {type(value).__name__}")
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(ET_ZONE).replace(tzinfo=None)
    return parsed.strftime("%Y-%m-%d %H:%M:%S")


def update_procedure_command(
    settings: DatabaseSettings, update: RuntimeUpdate
) -> tuple[str, tuple[object, ...]]:
    """Build the four-parameter update call; business logic remains in SQL."""
    sql = f"""
        EXEC {settings.quoted_update_stored_procedure}
            @job_name = ?,
            @job_start_time = ?,
            @job_end_time = ?,
            @job_status = ?
    """
    parameters: tuple[object, ...] = (
        update.target.job_name,
        _to_sql_datetime(update.job_start_time),
        _to_sql_datetime(update.job_end_time),
        update.job_status,
    )
    return sql, parameters


def summary_procedure_command(settings: DatabaseSettings) -> str:
    """Build the parameterless summary refresh call."""
    return f"EXEC {settings.quoted_summary_stored_procedure}"


def stream_procedure_command(settings: DatabaseSettings) -> str:
    """Build the parameterless critical-batch stream refresh call."""
    return f"EXEC {settings.quoted_stream_stored_procedure}"


def reset_procedure_command(settings: DatabaseSettings) -> str:
    """Build the parameterless daily job-time reset call."""
    return f"EXEC {settings.quoted_reset_stored_procedure}"


class SQLServerRepository:
    def __init__(self, settings: DatabaseSettings):
        self.settings = settings

    @contextmanager
    def _connection(self) -> Iterator[object]:
        try:
            import pyodbc
        except ImportError as exc:
            raise DatabaseError(
                "pyodbc is required; install requirements-sqlserver.txt"
            ) from exc
        try:
            connection = pyodbc.connect(
                self.settings.connection_string(), autocommit=False
            )
            yield connection
        except DatabaseError:
            raise
        except Exception as exc:
            raise DatabaseError(f"SQL Server operation failed: {exc}") from exc
        finally:
            if "connection" in locals():
                connection.close()

    def load_targets(self) -> list[TargetJob]:
        """Discover jobs through cp_Get_Critical_Batch_Jobs.

        Other returned columns are intentionally ignored. Python uses only the
        job name and AutoSys instance.
        """
        with self._connection() as connection:
            cursor = connection.cursor()
            cursor.execute(f"EXEC {self.settings.quoted_discovery_stored_procedure}")
            if cursor.description is None:
                raise DatabaseError("Job discovery procedure returned no result set")
            columns = [str(item[0]).strip().casefold() for item in cursor.description]
            name_key = self.settings.job_name_column.casefold()
            instance_key = self.settings.instance_column.casefold()
            if name_key not in columns or instance_key not in columns:
                raise DatabaseError(
                    "Job discovery procedure must return columns "
                    f"{self.settings.job_name_column!r} and "
                    f"{self.settings.instance_column!r}; returned {columns}"
                )
            name_index = columns.index(name_key)
            instance_index = columns.index(instance_key)
            rows = cursor.fetchall()

        targets: list[TargetJob] = []
        for row_number, row in enumerate(rows, start=1):
            job_name = "" if row[name_index] is None else str(row[name_index]).strip()
            instance = (
                "" if row[instance_index] is None else str(row[instance_index]).strip().upper()
            )
            if not job_name or not instance:
                raise DatabaseError(
                    f"Discovery row {row_number} has a blank job name or instance"
                )
            targets.append(TargetJob(job_name=job_name, instance=instance))
        _validate_unique_targets(targets)
        return targets

    def _runtime_snapshots(
        self, connection: object, target: TargetJob
    ) -> list[RuntimeSnapshot]:
        cursor = connection.cursor()
        try:
            cursor.execute(
                f"""
                SELECT
                    job_start_time,
                    job_end_time,
                    job_status,
                    job_eod_date,
                    last_updated_date
                FROM {self.settings.quoted_runtime_table}
                WHERE LTRIM(RTRIM(job_name)) = ?
                  AND UPPER(LTRIM(RTRIM(scheduler_instance))) =
                      UPPER(LTRIM(RTRIM(?)))
                """,
                target.job_name,
                target.instance,
            )
            return [
                RuntimeSnapshot(
                    job_start_time=row[0],
                    job_end_time=row[1],
                    job_status=None if row[2] is None else str(row[2]).strip(),
                    job_eod_date=row[3],
                    last_updated_date=row[4],
                )
                for row in cursor.fetchall()
            ]
        finally:
            close = getattr(cursor, "close", None)
            if close is not None:
                close()

    def apply_updates(
        self,
        updates: Iterable[RuntimeUpdate],
        *,
        verification_enabled: bool = True,
        run_id: str = "unknown",
        logger: logging.Logger | None = None,
    ) -> UpdateBatchResult:
        values = list(updates)
        if not values:
            return UpdateBatchResult.empty()
        operation_started = perf_counter()
        verifications: list[UpdateVerification] = []
        with self._connection() as connection:
            cursor = connection.cursor()
            try:
                for update in values:
                    job_started = perf_counter()
                    before_rows = (
                        self._runtime_snapshots(connection, update.target)
                        if verification_enabled
                        else []
                    )
                    if logger is not None:
                        logger.info(
                            "DB_UPDATE_ATTEMPT run_id=%s instance=%s job=%s "
                            "status=%s start=%s end=%s",
                            run_id,
                            update.target.instance,
                            update.target.job_name,
                            update.job_status,
                            update.job_start_time,
                            update.job_end_time,
                        )
                    sql, parameters = update_procedure_command(self.settings, update)
                    cursor.execute(sql, *parameters)
                    if verification_enabled:
                        after_rows = self._runtime_snapshots(connection, update.target)
                        verification = _classify_verification(
                            update,
                            before_rows,
                            after_rows,
                            round((perf_counter() - job_started) * 1000, 2),
                        )
                    else:
                        verification = UpdateVerification(
                            target=update.target,
                            result="NOT_VERIFIED",
                            reason="VERIFICATION_DISABLED",
                            before=None,
                            after=None,
                            duration_ms=round(
                                (perf_counter() - job_started) * 1000, 2
                            ),
                        )
                    verifications.append(verification)
                    _log_verification(logger, run_id, update, verification)
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        counts = _verification_counts(verifications)
        return UpdateBatchResult(
            attempted=len(values),
            verified=counts["VERIFIED"],
            already_correct=counts["ALREADY_CORRECT"],
            mismatched=counts["MISMATCH"],
            not_found=counts["NOT_FOUND"],
            duplicate_targets=counts["DUPLICATE_TARGET"],
            duration_ms=round((perf_counter() - operation_started) * 1000, 2),
            verifications=tuple(verifications),
        )

    def refresh_summary(self) -> None:
        """Refresh the database-owned critical batch summary in one transaction."""
        with self._connection() as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(summary_procedure_command(self.settings))
                connection.commit()
            except Exception:
                connection.rollback()
                raise

    def refresh_stream(self) -> None:
        """Refresh database-owned stream status, completion and SLA values."""
        with self._connection() as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(stream_procedure_command(self.settings))
                connection.commit()
            except Exception:
                connection.rollback()
                raise

    def reset_job_times(self) -> None:
        """Reset dashboard job start and end times in one transaction."""
        with self._connection() as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(reset_procedure_command(self.settings))
                connection.commit()
            except Exception:
                connection.rollback()
                raise


def load_mock_targets(path: str | Path) -> list[TargetJob]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, list):
        raise DatabaseError("Mock target file must contain a JSON list")
    targets = [
        TargetJob(
            job_name=str(item.get("job_name", "")).strip(),
            instance=str(item.get("instance_name", "")).strip().upper(),
        )
        for item in payload
        if isinstance(item, dict)
    ]
    if any(not item.job_name or not item.instance for item in targets):
        raise DatabaseError("Every mock target requires job_name and instance_name")
    _validate_unique_targets(targets)
    return targets


def _validate_unique_targets(targets: list[TargetJob]) -> None:
    seen: set[str] = set()
    duplicates: set[str] = set()
    for target in targets:
        key = target.job_name.casefold()
        if key in seen:
            duplicates.add(target.job_name)
        seen.add(key)
    if duplicates:
        raise DatabaseError(
            "The update procedure identifies rows by job_name; duplicate names "
            f"are not allowed: {sorted(duplicates)}"
        )


def _normalized_status(value: str | None) -> str | None:
    return None if value is None else value.strip().upper()


def _normalized_timestamp(value: datetime | str | None) -> str | None:
    return _to_sql_datetime(value)


def _snapshot_matches(update: RuntimeUpdate, snapshot: RuntimeSnapshot) -> bool:
    return (
        _normalized_status(snapshot.job_status)
        == _normalized_status(update.job_status)
        and _normalized_timestamp(snapshot.job_start_time)
        == _normalized_timestamp(update.job_start_time)
        and _normalized_timestamp(snapshot.job_end_time)
        == _normalized_timestamp(update.job_end_time)
    )


def _classify_verification(
    update: RuntimeUpdate,
    before_rows: list[RuntimeSnapshot],
    after_rows: list[RuntimeSnapshot],
    duration_ms: float,
) -> UpdateVerification:
    if not after_rows:
        return UpdateVerification(
            update.target, "NOT_FOUND", "TARGET_ROW_NOT_FOUND", None, None, duration_ms
        )
    if len(after_rows) > 1:
        return UpdateVerification(
            update.target,
            "DUPLICATE_TARGET",
            "MULTIPLE_TARGET_ROWS_FOUND",
            before_rows[0] if before_rows else None,
            after_rows[0],
            duration_ms,
        )
    before = before_rows[0] if len(before_rows) == 1 else None
    after = after_rows[0]
    if _snapshot_matches(update, after):
        result = "ALREADY_CORRECT" if before and _snapshot_matches(update, before) else "VERIFIED"
        reason = "DATABASE_ALREADY_MATCHED_AEWS" if result == "ALREADY_CORRECT" else "DATABASE_MATCHES_AEWS"
        return UpdateVerification(update.target, result, reason, before, after, duration_ms)
    if after.job_eod_date is None:
        reason = "JOB_EOD_DATE_NULL"
    elif before == after:
        reason = "PROCEDURE_COMPLETED_WITHOUT_CHANGING_VALUES"
    else:
        reason = "DATABASE_VALUES_DO_NOT_MATCH_AEWS"
    return UpdateVerification(update.target, "MISMATCH", reason, before, after, duration_ms)


def _verification_counts(
    verifications: list[UpdateVerification],
) -> dict[str, int]:
    results = {
        "VERIFIED": 0,
        "ALREADY_CORRECT": 0,
        "MISMATCH": 0,
        "NOT_FOUND": 0,
        "DUPLICATE_TARGET": 0,
    }
    for verification in verifications:
        if verification.result in results:
            results[verification.result] += 1
    return results


def _log_verification(
    logger: logging.Logger | None,
    run_id: str,
    update: RuntimeUpdate,
    verification: UpdateVerification,
) -> None:
    if logger is None:
        return
    after = verification.after
    log = logger.info if verification.result in {"VERIFIED", "ALREADY_CORRECT", "NOT_VERIFIED"} else logger.error
    log(
        "DB_VERIFY_%s run_id=%s instance=%s job=%s reason=%s "
        "expected_status=%s actual_status=%s expected_start=%s actual_start=%s "
        "expected_end=%s actual_end=%s job_eod_date=%s last_updated=%s duration_ms=%.2f",
        verification.result,
        run_id,
        update.target.instance,
        update.target.job_name,
        verification.reason,
        update.job_status,
        None if after is None else after.job_status,
        update.job_start_time,
        None if after is None else after.job_start_time,
        update.job_end_time,
        None if after is None else after.job_end_time,
        None if after is None else after.job_eod_date,
        None if after is None else after.last_updated_date,
        verification.duration_ms,
    )
