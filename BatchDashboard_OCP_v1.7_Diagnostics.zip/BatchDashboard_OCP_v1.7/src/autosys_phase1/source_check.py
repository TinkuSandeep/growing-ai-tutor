from __future__ import annotations

import argparse
import json
import logging
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from time import perf_counter
from typing import Any
from uuid import uuid4
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

from .aews import AEWSClient, MockAEWSClient, RuntimeSource
from .config import Settings, load_settings
from .database import SQLServerRepository, load_mock_targets
from .models import RuntimeUpdate, TargetJob, UpdateBatchResult
from .transform import latest_runtime_update


@dataclass(frozen=True)
class _ReportData:
    run_id: str
    started: datetime
    completed: datetime
    targets: list[TargetJob]
    results: list[dict[str, Any]]
    failed: int
    write_result: UpdateBatchResult
    write_error: str | None
    api_metrics: dict[str, int]
    phase_durations_ms: dict[str, float]


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Database-driven AutoSys AEWS runtime ingestion"
    )
    parser.add_argument("--settings", default="config/settings.yaml")
    parser.add_argument("--env-file", default=".env")
    parser.add_argument(
        "--write",
        action="store_true",
        help="Call the configured target update procedure after every AEWS job passes",
    )
    parser.add_argument(
        "--mock-targets",
        help="Offline JSON replacement for cp_Get_Critical_Batch_Jobs",
    )
    parser.add_argument(
        "--mock-aews",
        help="Offline AEWS JSON fixture",
    )
    return parser.parse_args()


def _json_default(value: Any):
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(type(value).__name__)


def _configure_logging(log_path: Path | None) -> logging.Logger:
    logger = logging.getLogger("autosys_sp_ingestion")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    if log_path is not None:
        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    return logger


def _job_result(target: TargetJob) -> dict[str, Any]:
    return {
        "job_name": target.job_name,
        "instance_name": target.instance,
        "source": "AEWS",
    }


def _validate_arguments(args: argparse.Namespace) -> None:
    if bool(args.mock_targets) != bool(args.mock_aews):
        raise SystemExit("Offline testing requires both --mock-targets and --mock-aews")
    if args.write and (args.mock_targets or args.mock_aews):
        raise SystemExit("--write cannot be combined with mock data")


def _output_paths(
    settings: Settings, started: datetime
) -> tuple[Path | None, Path | None]:
    if not settings.ingestion.file_output_enabled:
        return None, None

    stamp = started.strftime("%Y%m%d_%H%M%S_%f")
    output_dir = Path(settings.ingestion.output_directory)
    log_dir = Path(settings.ingestion.log_directory)
    output_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    return (
        output_dir / f"autosys_ingestion_{stamp}.json",
        log_dir / f"autosys_ingestion_{stamp}.log",
    )


def _discover_targets(
    args: argparse.Namespace,
    repository: SQLServerRepository,
    settings: Settings,
) -> list[TargetJob]:
    targets = (
        load_mock_targets(args.mock_targets)
        if args.mock_targets
        else repository.load_targets()
    )
    minimum = settings.ingestion.require_minimum_target_count
    if minimum is not None and len(targets) < minimum:
        raise ValueError(
            f"Discovery returned {len(targets)} jobs; minimum required is {minimum}"
        )
    if not targets:
        raise ValueError("No jobs returned")
    return targets


def _create_runtime_source(
    args: argparse.Namespace, settings: Settings
) -> RuntimeSource:
    return (
        MockAEWSClient(args.mock_aews)
        if args.mock_aews
        else AEWSClient(settings.autosys)
    )


def _collect_runtime_updates(
    targets: list[TargetJob],
    source: RuntimeSource,
    settings: Settings,
    logger: logging.Logger,
    run_id: str = "unknown",
) -> tuple[list[dict[str, Any]], list[RuntimeUpdate], int]:
    results: list[dict[str, Any]] = []
    updates: list[RuntimeUpdate] = []
    failed = 0
    for target in targets:
        job_started = perf_counter()
        result = _job_result(target)
        try:
            payload = source.get_job_runs(target)
            update = latest_runtime_update(
                target,
                payload,
                settings.autosys.timezone,
                settings.autosys.store_naive_local_time,
            )
            updates.append(update)
            result.update(
                {
                    "run_number": update.run_number,
                    "job_start_time_et": update.job_start_time,
                    "job_end_time_et": update.job_end_time,
                    "job_status": update.job_status,
                    "aews_duration_ms": round(
                        (perf_counter() - job_started) * 1000, 2
                    ),
                    "result": "PASSED",
                }
            )
            logger.info(
                "AEWS_FETCH_OK run_id=%s instance=%s job=%s status=%s "
                "start=%s end=%s duration_ms=%.2f",
                run_id,
                target.instance,
                target.job_name,
                update.job_status,
                update.job_start_time,
                update.job_end_time,
                result["aews_duration_ms"],
            )
        except Exception as exc:
            failed += 1
            result.update(
                {
                    "result": "FAILED",
                    "error": str(exc),
                    "aews_duration_ms": round(
                        (perf_counter() - job_started) * 1000, 2
                    ),
                }
            )
            logger.error(
                "AEWS_FETCH_FAILED run_id=%s instance=%s job=%s "
                "error=%s duration_ms=%.2f",
                run_id,
                target.instance,
                target.job_name,
                exc,
                result["aews_duration_ms"],
            )
        results.append(result)
    return results, updates, failed


def _write_target_updates(
    write_enabled: bool,
    failed: int,
    updates: list[RuntimeUpdate],
    repository: SQLServerRepository,
    settings: Settings,
    logger: logging.Logger,
    run_id: str = "unknown",
) -> tuple[UpdateBatchResult, str | None]:
    if not write_enabled:
        return UpdateBatchResult.empty(), None
    if failed and settings.ingestion.abort_on_job_error:
        message = "Target write blocked because one or more AEWS jobs failed"
        logger.error("TARGET WRITE FAILED error=%s", message)
        return UpdateBatchResult.empty(), message

    try:
        write_result = repository.apply_updates(
            updates,
            verification_enabled=settings.ingestion.verification_enabled,
            run_id=run_id,
            logger=logger,
        )
        logger.info(
            "DB_WRITE_COMPLETED run_id=%s attempted=%d verified=%d "
            "already_correct=%d mismatched=%d not_found=%d duplicates=%d "
            "duration_ms=%.2f procedure=%s",
            run_id,
            write_result.attempted,
            write_result.verified,
            write_result.already_correct,
            write_result.mismatched,
            write_result.not_found,
            write_result.duplicate_targets,
            write_result.duration_ms,
            settings.database.update_stored_procedure,
        )
        if (
            settings.ingestion.fail_on_verification_mismatch
            and write_result.failures
        ):
            return write_result, (
                "Database verification failed: "
                f"mismatched={write_result.mismatched}, "
                f"not_found={write_result.not_found}, "
                f"duplicates={write_result.duplicate_targets}"
            )
        return write_result, None
    except Exception as exc:
        logger.error("TARGET_WRITE_FAILED run_id=%s error=%s", run_id, exc)
        return UpdateBatchResult.empty(), str(exc)


def _overall_result(write_enabled: bool, failed: int, write_error: str | None) -> str:
    outcomes = {
        (False, False): "DRY_RUN_PASSED",
        (False, True): "DRY_RUN_FAILED",
        (True, False): "INGESTION_PASSED",
        (True, True): "INGESTION_FAILED",
    }
    return outcomes[(write_enabled, bool(failed or write_error))]


def _build_report(
    args: argparse.Namespace,
    settings: Settings,
    data: _ReportData,
) -> dict[str, Any]:
    return {
        "version": "1.7.0",
        "run_id": data.run_id,
        "result": _overall_result(args.write, data.failed, data.write_error),
        "mode": "write" if args.write else "dry_run",
        "job_catalog": (
            "mock" if args.mock_targets else settings.database.discovery_stored_procedure
        ),
        "started_at_et": data.started,
        "completed_at_et": data.completed,
        "requested": len(data.targets),
        "succeeded": len(data.targets) - data.failed,
        "failed": data.failed,
        "database_attempted": data.write_result.attempted,
        "database_verified": data.write_result.verified,
        "database_already_correct": data.write_result.already_correct,
        "database_mismatched": data.write_result.mismatched,
        "database_not_found": data.write_result.not_found,
        "database_duplicate_targets": data.write_result.duplicate_targets,
        # Compatibility fields retained for existing dashboard consumers. The
        # value now represents rows verified against AEWS, not procedure calls.
        "target_database_updated": data.write_result.verified > 0,
        "target_rows_updated": data.write_result.verified,
        "target_write_error": data.write_error,
        **data.phase_durations_ms,
        **data.api_metrics,
        "jobs": data.results,
    }


def _write_report(
    report: dict[str, Any],
    report_path: Path | None,
    log_path: Path | None,
    logger: logging.Logger,
) -> None:
    if report_path is not None:
        report_path.write_text(
            json.dumps(report, indent=2, default=_json_default), encoding="utf-8"
        )
        logger.info("Report written to %s", report_path)
        logger.info("Log written to %s", log_path)


def _print_summary(
    report: dict[str, Any], report_path: Path | None, log_path: Path | None
) -> None:
    report_location = str(report_path) if report_path is not None else None
    log_location = str(log_path) if log_path is not None else None
    print(
        json.dumps(
            {
                "result": report["result"],
                "run_id": report["run_id"],
                "requested": report["requested"],
                "succeeded": report["succeeded"],
                "failed": report["failed"],
                "database_attempted": report["database_attempted"],
                "database_verified": report["database_verified"],
                "database_already_correct": report["database_already_correct"],
                "database_mismatched": report["database_mismatched"],
                "database_not_found": report["database_not_found"],
                "database_duplicate_targets": report[
                    "database_duplicate_targets"
                ],
                "target_write_error": report["target_write_error"],
                "api_request_attempts": report["api_request_attempts"],
                "api_retries": report["api_retries"],
                "api_rate_limit_responses": report["api_rate_limit_responses"],
                "report": report_location,
                "log": log_location,
            },
            indent=2,
        )
    )


def _print_failure(
    result: str, exc: Exception, logger: logging.Logger, run_id: str
) -> int:
    logger.error("%s run_id=%s error=%s", result, run_id, exc)
    print(
        json.dumps(
            {"result": result, "run_id": run_id, "error": str(exc)}, indent=2
        )
    )
    return 1


def _merge_write_verifications(
    results: list[dict[str, Any]], write_result: UpdateBatchResult
) -> None:
    indexed = {
        (str(result["job_name"]).casefold(), str(result["instance_name"]).upper()): result
        for result in results
    }
    for verification in write_result.verifications:
        key = (
            verification.target.job_name.casefold(),
            verification.target.instance.upper(),
        )
        if key in indexed:
            indexed[key].update(verification.as_dict())


def main() -> int:
    args = _arguments()
    load_dotenv(args.env_file, override=False)
    settings = load_settings(args.settings)
    _validate_arguments(args)

    run_id = str(uuid4())
    total_started = perf_counter()
    started = datetime.now(ZoneInfo(settings.autosys.timezone))
    report_path, log_path = _output_paths(settings, started)
    logger = _configure_logging(log_path)
    repository = SQLServerRepository(settings.database)

    logger.info("INGESTION_STARTED run_id=%s mode=%s", run_id, "write" if args.write else "dry_run")
    discovery_started = perf_counter()
    try:
        targets = _discover_targets(args, repository, settings)
    except Exception as exc:
        return _print_failure("DISCOVERY_FAILED", exc, logger, run_id)
    discovery_duration_ms = round((perf_counter() - discovery_started) * 1000, 2)
    logger.info(
        "DISCOVERY_COMPLETED run_id=%s total=%d instances=%s duration_ms=%.2f",
        run_id,
        len(targets),
        dict(Counter(target.instance for target in targets)),
        discovery_duration_ms,
    )

    try:
        source = _create_runtime_source(args, settings)
    except Exception as exc:
        return _print_failure("AEWS_INITIALIZATION_FAILED", exc, logger, run_id)

    logger.info(
        "COLLECTION_STARTED run_id=%s mode=%s targets=%d",
        run_id,
        "collection and target write" if args.write else "dry run",
        len(targets),
    )
    collection_started = perf_counter()
    results, updates, failed = _collect_runtime_updates(
        targets, source, settings, logger, run_id
    )
    collection_duration_ms = round((perf_counter() - collection_started) * 1000, 2)
    write_started = perf_counter()
    write_result, write_error = _write_target_updates(
        args.write, failed, updates, repository, settings, logger, run_id
    )
    write_duration_ms = round((perf_counter() - write_started) * 1000, 2)
    _merge_write_verifications(results, write_result)
    completed = datetime.now(ZoneInfo(settings.autosys.timezone))
    total_duration_ms = round((perf_counter() - total_started) * 1000, 2)
    report = _build_report(
        args,
        settings,
        _ReportData(
            run_id=run_id,
            started=started,
            completed=completed,
            targets=targets,
            results=results,
            failed=failed,
            write_result=write_result,
            write_error=write_error,
            api_metrics=source.metrics(),
            phase_durations_ms={
                "discovery_duration_ms": discovery_duration_ms,
                "collection_duration_ms": collection_duration_ms,
                "database_write_duration_ms": write_duration_ms,
                "total_duration_ms": total_duration_ms,
            },
        ),
    )
    _write_report(report, report_path, log_path, logger)
    _print_summary(report, report_path, log_path)
    exit_code = int(bool(failed or write_error))
    logger.info(
        "INGESTION_COMPLETED run_id=%s result=%s exit_code=%d "
        "requested=%d collected=%d verified=%d mismatched=%d "
        "not_found=%d duration_ms=%.2f",
        run_id,
        report["result"],
        exit_code,
        len(targets),
        len(updates),
        write_result.verified,
        write_result.mismatched,
        write_result.not_found,
        total_duration_ms,
    )
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
