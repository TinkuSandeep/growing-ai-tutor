from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass(frozen=True)
class TargetJob:
    """The only catalog values used by the Python integration layer."""

    job_name: str
    instance: str


@dataclass(frozen=True)
class RuntimeUpdate:
    target: TargetJob
    run_number: int
    job_start_time: datetime | None
    job_end_time: datetime | None
    job_status: str


@dataclass(frozen=True)
class RuntimeSnapshot:
    job_start_time: datetime | str | None
    job_end_time: datetime | str | None
    job_status: str | None
    job_eod_date: datetime | str | None
    last_updated_date: datetime | str | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "job_start_time": self.job_start_time,
            "job_end_time": self.job_end_time,
            "job_status": self.job_status,
            "job_eod_date": self.job_eod_date,
            "last_updated_date": self.last_updated_date,
        }


@dataclass(frozen=True)
class UpdateVerification:
    target: TargetJob
    result: str
    reason: str
    before: RuntimeSnapshot | None
    after: RuntimeSnapshot | None
    duration_ms: float

    def as_dict(self) -> dict[str, Any]:
        return {
            "job_name": self.target.job_name,
            "instance_name": self.target.instance,
            "database_verification": self.result,
            "database_diagnostic_reason": self.reason,
            "database_before": self.before.as_dict() if self.before else None,
            "database_after": self.after.as_dict() if self.after else None,
            "database_duration_ms": self.duration_ms,
        }


@dataclass(frozen=True)
class UpdateBatchResult:
    attempted: int
    verified: int
    already_correct: int
    mismatched: int
    not_found: int
    duplicate_targets: int
    duration_ms: float
    verifications: tuple[UpdateVerification, ...]

    @classmethod
    def empty(cls) -> "UpdateBatchResult":
        return cls(0, 0, 0, 0, 0, 0, 0.0, ())

    @property
    def failures(self) -> int:
        return self.mismatched + self.not_found + self.duplicate_targets
