# Batch Dashboard AutoSys OCP Runtime Ingestion - Version 1.7

This is the OCP-ready release of the working database-driven AutoSys runtime
ingestion solution. It retains the validated discovery, AEWS collection,
timestamp normalization, transactional runtime update and dependent database
summary refresh and critical-batch stream refresh behavior. Version 1.7 adds
application-side diagnostics that detect silent database no-update cases
without changing the existing stored procedures.

## Version 1.7 changes

- Assigns a unique `run_id` to every ingestion execution.
- Logs discovery counts grouped by scheduler instance.
- Logs per-job AEWS status, timestamps and collection duration.
- Reads each target row before and after the unchanged update procedure call.
- Compares AutoSys values with committed SQL runtime values.
- Classifies `VERIFIED`, `ALREADY_CORRECT`, `MISMATCH`, `NOT_FOUND` and
  `DUPLICATE_TARGET` outcomes.
- Identifies `JOB_EOD_DATE_NULL` as a diagnostic reason for silent no-update
  scenarios.
- Returns a nonzero exit code when database verification finds unexpected
  results.
- Reports accurate attempted, verified, mismatched, missing and duplicate
  counters instead of treating procedure calls as updated rows.
- Adds discovery, AEWS collection, database write and total execution timings.
- Preserves per-job before/after evidence in the optional JSON report.

## Version 1.6 foundation

- Renamed application-owned authentication fields to identity/credential
  terminology. CD/Vault mappings must now supply `AUTOSYS_API_CREDENTIAL` and
  `DB_CREDENTIAL`.
- Removed upstream AEWS response content from error messages.
- Consolidated the summary, stream and reset command runners to eliminate
  duplicated implementation.
- Uses the secure SQL identity-validation default
  `trust_server_certificate: false`. The OCP image must trust the SQL Server CA.

## Version 1.5 changes

- Added configurable `dbo.cp_Reset_Job_Times` execution through
  `SQLServerRepository.reset_job_times()`.
- Added `python -m autosys_phase1.reset_job_times` with transactional commit,
  rollback, logging, JSON result and nonzero failure exit code.
- Added repository tests for reset command quoting, commit and rollback.
- Updated the sample AutoSys cadence to every 15 minutes.
- Added a separate daily reset job at 00:05 `America/New_York`.
- Aligned the AEWS CA path with `/mnt/ssl_dir/prdautosys.crt`.

## Version 1.4 changes

- Fixed the OCP `ModuleNotFoundError: No module named 'autosys_phase1'` by
  installing the local `src` package through `requirements.txt`, which is the
  file used by the enterprise Python image build.
- Added `scripts/start_app.sh` as the ingestion container entry point and added
  build-time package import verification to the `Containerfile`.
- Standardized the Python dependency, container RPM, runtime environment and
  tests on Microsoft ODBC Driver 17.
- Replaced the single `SQLSERVER_CONNECTION_STRING` dependency with separate
  Harness/Vault-injected SQL Server environment values.
- Added ODBC-safe escaping for driver, host, database, service identity and
  credential values, including embedded closing braces.
- Added SQL Server port validation and explicit encrypted-connection settings.
- Kept credential retrieval outside Python; Harness injects values into the OCP
  runtime and the application never calls Vault directly.
- Retained Version 1.3 AEWS corporate CA-bundle validation.

## Version 1.3 changes retained

- Added configurable AEWS corporate CA-bundle validation.
- Added fail-closed checks for a missing or unreadable configured certificate.
- Added an OCP read-only certificate-volume mount example.
- Retained all Version 1.2 database procedures, rate-limit safeguards and the
  three-job dependency chain.

## Version 1.2 changes retained

- Renamed the runtime update procedure to
  `dbo.cp_Update_Job_Execution_Status`.
- Added a third dependent job that calls the parameterless
  `dbo.cp_Update_Critical_Batch_Stream` procedure.
- Added configurable request pacing, retry/backoff limits and `Retry-After`
  handling for AEWS rate-limit protection.
- Added API request-attempt, retry and HTTP 429 counts to ingestion output.
- Updated the OCP ConfigMap, runtime image tag, preflight SQL, tests and
  three-job JIL example.

## Quality scan preparation

Install `requirements-dev.txt`, then generate the test and coverage input used
by SonarQube:

```bash
./scripts/run_quality_checks.sh
sonar-scanner
```

Run the approved Checkmarx pipeline against the repository root. Scanner server
addresses and authentication values must remain in the enterprise CI platform.

## AutoSys commands

Runtime ingestion:

```bash
python -m autosys_phase1.source_check --settings /opt/batch-dashboard/config/settings.yaml --write
```

Summary refresh:

```bash
python -m autosys_phase1.summary_refresh --settings /opt/batch-dashboard/config/settings.yaml
```

Stream refresh:

```bash
python -m autosys_phase1.stream_refresh --settings /opt/batch-dashboard/config/settings.yaml
```

Daily job-time reset:

```bash
python -m autosys_phase1.reset_job_times --settings /opt/batch-dashboard/config/settings.yaml
```

The summary job must depend on successful completion of ingestion. The stream
job must depend on successful completion of summary refresh.

## Database contracts

- Discovery: `dbo.cp_Get_Critical_Batch_Jobs`
- Required discovery columns: `job_name`, `scheduler_instance`
- Runtime update: `dbo.cp_Update_Job_Execution_Status`
- Summary refresh: `dbo.cp_Update_Critical_Batch_Summary`
- Stream refresh: `dbo.cp_Update_Critical_Batch_Stream`
- Daily job-time reset: `dbo.cp_Reset_Job_Times`

The stream procedure takes no parameters. Database-owned logic calculates
batch stream status, completion percentage and SLA status from
`cp_critical_batch_summary_ui` and updates `cp_critical_batch_stream_ui`.

## Runtime database verification

The ingestion calls the existing four-parameter runtime update procedure and
then reads `dbo.cp_critical_batch_jobs` using `job_name` and
`scheduler_instance`. The SQL runtime fields must match the values returned by
AEWS. Verification is controlled through:

```yaml
database:
  runtime_table: "dbo.cp_critical_batch_jobs"

ingestion:
  verification_enabled: true
  fail_on_verification_mismatch: true
```

A mismatch, missing target or duplicate target is included in the JSON report
and causes a nonzero process exit when `fail_on_verification_mismatch` is true.
AutoSys can therefore send its normal failure notification instead of treating
a silent no-update as success. Existing compatibility fields remain in the
summary output, but `target_rows_updated` now means rows verified against AEWS,
not the number of stored-procedure calls.

## AEWS rate-limit protection

Collection remains sequential. `request_delay_seconds` controls minimum pacing
between requests. HTTP 429 and transient server responses are retried using the
configured bounded backoff, and an AEWS `Retry-After` header is honored. Keep
the 15-minute schedule under observation as more critical jobs are onboarded.

Job names remain database-driven. Do not hard-code production jobs in Python or
YAML.

See `README_OCP_DEPLOYMENT.md` for deployment and validation instructions.
See `UI_REQUIREMENTS.md` for the separate dashboard presentation changes.

## Package-build verification

The enterprise build must run from the repository root so the final `.` entry
in `requirements.txt` can install `pyproject.toml` and `src/autosys_phase1`.
After deployment, verify the package without printing environment variables:

```bash
python3 -c "import autosys_phase1; print(autosys_phase1.__version__)"
python3 -m autosys_phase1.source_check --help
odbcinst -q -d
```

The driver list must contain `ODBC Driver 17 for SQL Server`.
