# Version 1.7 validation results

Validation date: 2026-10-13

- Python compilation: passed.
- Automated tests: **48 passed**.
- Total measured unit-test coverage: **80%**.
- Sonar rule `python:S3776`: the `source_check.main()` workflow was split into
  focused discovery, collection, write, reporting and output helpers. The main
  function now contains only orchestration and error-boundary handling.
- Sonar rule `python:S107`: report-generation inputs are grouped in an immutable
  `_ReportData` object, reducing `_build_report()` from 10 parameters to 3.
- Offline end-to-end fixture run: **DRY_RUN_PASSED** (2 requested, 2 succeeded).
- Per-execution UUID `run_id` logging: passed.
- Discovery counts by scheduler instance: passed.
- Per-job AEWS timing and timestamp logging: passed.
- Database before/after snapshot model: passed.
- Matching AEWS and database value classification: passed.
- Silent no-update with `job_eod_date = NULL` classification: passed.
- Missing and duplicate database target classification: passed.
- Verification mismatch produces a nonzero ingestion outcome: passed.
- Existing four-parameter update stored-procedure contract remains unchanged.
- Application-owned authentication identifiers use identity/credential terminology.
- AEWS error messages do not include upstream response content.
- Shared procedure runner removes the duplicated summary, stream and reset logic.
- Python package-build tooling is declared in `requirements-dev.txt` for the
  CI `python -m build --wheel` stage.
- Reset procedure configuration and SQL command generation: passed.
- Reset transaction commit and rollback behavior: passed.
- AutoSys API certificate path contract: `/mnt/ssl_dir/prdautosys.crt`.
- SQL Server encryption and certificate identity validation are enabled with
  `trust_server_certificate: false`.
- The AutoSys example schedules ingestion every 15 minutes.
- The independent daily reset calls `dbo.cp_Reset_Job_Times` at 12:05 AM Eastern.

Validation command:

```bash
python3 -m pytest -q
```

Production database writes, AEWS connectivity, certificate-chain validation,
image scanning and AutoSys/OCP agent registration must still be validated in the
approved target environment.
