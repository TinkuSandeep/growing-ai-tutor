from dataclasses import replace

import pytest

from autosys_phase1.config import (
    ConfigurationError,
    load_settings,
    quote_sql_object_name,
)


def test_quotes_three_part_table_name():
    assert quote_sql_object_name("TCOO_TOOLS.dbo.cp_critical_batch_jobs") == (
        "[TCOO_TOOLS].[dbo].[cp_critical_batch_jobs]"
    )


def test_rejects_unsafe_table_name():
    with pytest.raises(ConfigurationError):
        quote_sql_object_name("dbo.jobs; DROP TABLE dbo.jobs")


def test_v14_ocp_contract_uses_scheduler_instance_and_refresh_procedures():
    settings = load_settings("config/settings.yaml")
    assert settings.database.instance_column == "scheduler_instance"
    assert settings.database.summary_stored_procedure == (
        "dbo.cp_Update_Critical_Batch_Summary"
    )
    assert settings.database.update_stored_procedure == (
        "dbo.cp_Update_Job_Execution_Status"
    )
    assert settings.database.stream_stored_procedure == (
        "dbo.cp_Update_Critical_Batch_Stream"
    )
    assert settings.database.driver_env == "DB_DRIVER"
    assert settings.database.host_env == "DB_HOST"
    assert settings.database.port_env == "DB_PORT"
    assert settings.database.database_name_env == "DB_NAME"
    assert settings.database.principal_env == "DB_USER"
    assert settings.database.secret_env == "DB_PASSWORD"
    assert settings.database.encrypt is True
    assert settings.database.trust_server_certificate is False
    assert settings.autosys.request_delay_seconds == 0.2
    assert settings.autosys.max_retries == 3
    assert settings.autosys.honor_retry_after is True
    assert settings.autosys.verify_ssl is True
    assert settings.autosys.ca_bundle_path == (
        "/mnt/certificates/wellsfargo-ca-bundle.pem"
    )
    assert settings.ingestion.file_output_enabled is False


def test_tls_verification_returns_configured_ca_bundle(tmp_path):
    settings = load_settings("config/settings.yaml")
    ca_bundle = tmp_path / "corporate-ca.pem"
    ca_bundle.write_text("test certificate bundle", encoding="utf-8")

    autosys = replace(settings.autosys, ca_bundle_path=str(ca_bundle))

    assert autosys.tls_verification() == str(ca_bundle)


def test_tls_verification_fails_closed_for_missing_ca_bundle(tmp_path):
    settings = load_settings("config/settings.yaml")
    missing = tmp_path / "missing-ca.pem"
    autosys = replace(settings.autosys, ca_bundle_path=str(missing))

    with pytest.raises(ConfigurationError, match="CA bundle was not found"):
        autosys.tls_verification()


def test_tls_verification_uses_default_trust_store_when_path_is_null():
    settings = load_settings("config/settings.yaml")
    autosys = replace(settings.autosys, ca_bundle_path=None, verify_ssl=True)

    assert autosys.tls_verification() is True
