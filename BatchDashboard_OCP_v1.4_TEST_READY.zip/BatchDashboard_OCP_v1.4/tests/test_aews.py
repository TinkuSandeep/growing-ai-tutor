from dataclasses import replace

import requests

from autosys_phase1.aews import AEWSClient
from autosys_phase1.config import load_settings
from autosys_phase1.models import TargetJob


def test_job_request_uses_configured_ca_bundle(tmp_path, monkeypatch):
    monkeypatch.setenv("AUTOSYS_API_USER", "test-principal")
    monkeypatch.setenv("AUTOSYS_API_PASSWORD", "test-secret")
    settings = load_settings("config/settings.yaml")
    ca_bundle = tmp_path / "corporate-ca.pem"
    ca_bundle.write_text("test certificate bundle", encoding="utf-8")
    autosys = replace(settings.autosys, ca_bundle_path=str(ca_bundle))
    client = AEWSClient(autosys)
    captured = {}

    def fake_get(url, **kwargs):
        captured["url"] = url
        captured.update(kwargs)
        response = requests.Response()
        response.status_code = 200
        response._content = b"{}"
        response.headers["Content-Type"] = "application/json"
        return response

    monkeypatch.setattr(client.session, "get", fake_get)

    client.get_job_runs(TargetJob(job_name="TEST_JOB", instance="PB3"))

    assert captured["verify"] == str(ca_bundle)
    assert captured["url"].startswith("https://pb3-autosyswebapi")
