"""OCP-ready AutoSys runtime ingestion application."""

__version__ = "1.4.0"
