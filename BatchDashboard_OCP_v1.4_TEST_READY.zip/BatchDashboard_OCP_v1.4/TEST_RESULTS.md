# Version 1.4 validation results

Validation date: 2026-09-25

- Python compilation: passed.
- Automated tests: 23 passed.
- Runtime-ingestion module help command: passed.
- Summary-refresh module help command: passed.
- Stream-refresh module help command: passed.
- OCP YAML parsing: passed for settings, ConfigMap, secret example and runtime fragment.
- Offline database-driven discovery and AEWS dry run: passed for two jobs across PB3 and PC3.
- Stdout-only mode: passed; no report or log file was required.
- Dry-run return code: zero.
- Renamed runtime-update procedure contract: passed.
- Parameterless stream-refresh procedure contract: passed.
- Sequential AEWS pacing and bounded retry configuration: passed.
- API attempt/retry/rate-limit metrics in dry-run output: passed.
- Configured AEWS CA-bundle path propagation to Requests: passed.
- Missing CA-bundle fail-closed behavior: passed.
- Default container trust-store fallback when the CA path is null: passed.
- OCP read-only corporate CA volume-mount example: included.
- Separate Vault-injected SQL Server environment-value mapping: passed.
- ODBC connection-string construction and special-character escaping: passed.
- Invalid SQL Server port fail-closed behavior: passed.
- Encrypted SQL defaults (`Encrypt=yes`, `TrustServerCertificate=no`): passed.

Production database writes, both database refresh procedures, AEWS connectivity,
corporate certificate-chain validation, image scanning and AutoSys/OCP agent
registration must be validated in the approved target environment.
