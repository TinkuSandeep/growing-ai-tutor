# Batch Dashboard OCP deployment - Version 1.5

## Production execution model

Version 1.5 does not require Windows batch files. AutoSys directly invokes the
installed Python modules inside the approved OCP runtime.

Job 1:

```bash
python -m autosys_phase1.source_check \
  --settings /opt/batch-dashboard/config/settings.yaml \
  --write
```

Job 2:

```bash
python -m autosys_phase1.summary_refresh \
  --settings /opt/batch-dashboard/config/settings.yaml
```

Job 3:

```bash
python -m autosys_phase1.stream_refresh \
  --settings /opt/batch-dashboard/config/settings.yaml
```

Independent daily reset job:

```bash
python -m autosys_phase1.reset_job_times \
  --settings /opt/batch-dashboard/config/settings.yaml
```

Job 2 must have a success dependency on Job 1. Job 3 must have a success
dependency on Job 2. All modules return zero on success and one on failure,
allowing AutoSys to set SU or FA correctly.

The reset job is independent from the three-job ingestion chain and is
scheduled daily at 00:05 `America/New_York`. The scheduling team must prevent
it from overlapping an active ingestion execution.

## OCP prerequisites

- Python 3.10 or later.
- Microsoft ODBC Driver 17 and unixODBC in the approved image.
- Internal CA certificates for AEWS and SQL Server TLS.
- Network routes from the namespace to all approved AEWS instances and the SQL
  Server target.
- An approved AutoSys service identity with read-only AEWS access.
- An approved SQL Server service identity with EXECUTE permission on the five
  configured stored procedures.
- The AutoSys System Agent, or another approved mechanism that waits for module
  completion and propagates its return code.

## Configuration and secrets

Apply `ocp/configmap.yaml` after validating the environment-specific values.
Create `batch-dashboard-secrets` through the approved secret-management process.
Never apply `ocp/secret.example.yaml` with placeholder or real values stored in
Git.

Required variables:

- `AUTOSYS_API_USER`
- `AUTOSYS_API_PASSWORD`
- `DB_DRIVER`
- `DB_HOST`
- `DB_PORT`
- `DB_NAME`
- `DB_USER`
- `DB_PASSWORD`

`DB_HOST`, `DB_USER` and `DB_PASSWORD` must be injected through the approved
Harness/Vault secret process. `DB_DRIVER`, `DB_PORT` and `DB_NAME` are non-secret
environment settings and may be supplied by the deployment ConfigMap or
workload definition. The application assembles the ODBC connection string in
memory and does not call Vault directly.

The packaged environment setting is `Encrypt=yes` and
`TrustServerCertificate=yes`, matching the validated v1.4 deployment. Security
approval is required before retaining this setting in production; the preferred
long-term configuration is a trusted SQL Server certificate chain with
`TrustServerCertificate=no`.

The AEWS corporate CA bundle is not a credential, but it must be supplied by an
approved OCP/Harness certificate Secret or ConfigMap and mounted read-only. The
default application configuration expects it at:

```text
/mnt/ssl_dir/prdautosys.crt
```

`autosys.ca_bundle_path` in `config/settings.yaml` must exactly match the
container mount path. When a path is configured, the application fails closed
if the file is missing or unreadable. If the corporate CA is already installed
in the container's operating-system trust store, set `ca_bundle_path: null` and
retain `verify_ssl: true`.

Do not set `verify_ssl: false` in production.

No `.env` file is required in OCP. The existing dotenv call is retained only
for local testing and does not override injected variables.

## Logging

`file_output_enabled` is false by default. Logs and final JSON results go to
stdout/stderr for collection by OCP and Splunk. Set it to true only when the
configured output and log directories are backed by persistent storage.

## Deployment validation

1. Build and scan the image from `Containerfile`.
2. Confirm `python -m autosys_phase1.source_check --help` succeeds in the image.
3. Confirm all required environment variables are present without printing
   secret values.
4. Confirm the configured CA bundle exists and is readable inside the pod.
5. Run Job 1 without `--write` as a dry run and confirm no TLS warning occurs.
6. Compare the returned job count, start time, end time and status with AutoSys.
7. Confirm a SQL connection can be established with encrypted certificate
   validation and without `TrustServerCertificate=yes`.
8. Run Job 1 with `--write` in an approved test window.
9. Validate the runtime detail table.
10. Run Job 2 and validate the summary table.
11. Run Job 3 and validate `cp_critical_batch_stream_ui`.
12. Run the reset module in an approved test window and verify that the start
    and end times are set to NULL as defined by the stored procedure.
13. Import the reviewed JIL and confirm the ingestion order is Job 1, Job 2,
    then Job 3, with the daily reset maintained as a separate schedule.

## Fifteen-minute schedule and capacity monitoring

All onboarded jobs are critical, so the sample JIL uses the 15-minute
ingestion schedule. Collection is sequential and paced to reduce request bursts.
Track total runtime, discovered jobs, API request attempts, retries, HTTP 429
responses and database refresh duration. Confirm the official AEWS rate limit
before materially increasing job volume. Review capacity at approximately 50,
100 and 250 jobs. Do not allow a new chain to overlap a prior execution.

The sample JIL raises a maximum-runtime alarm before the next 15-minute start.
The production scheduling team must validate its approved no-overlap behavior.

## Important integration rule

Do not use a fire-and-forget `oc create job` command from AutoSys. If the
AutoSys agent is outside OCP, the approved launcher must wait for the OCP Job,
collect its termination status and return a nonzero code to AutoSys when the
container fails.
