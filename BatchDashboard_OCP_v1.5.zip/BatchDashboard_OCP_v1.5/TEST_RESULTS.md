# Version 1.5 validation results

Validation date: 2026-10-01

- Python compilation: passed.
- Automated tests: **26 passed**.
- Reset procedure configuration and SQL command generation: passed.
- Reset transaction commit and rollback behavior: passed.
- AutoSys API certificate path contract: `/mnt/ssl_dir/prdautosys.crt`.
- SQL Server encryption remains enabled with `trust_server_certificate: true`,
  matching the validated OCP deployment configuration.
- The AutoSys example schedules ingestion every 15 minutes.
- The independent daily reset calls `dbo.cp_Reset_Job_Times` at 12:05 AM Eastern.

Validation command:

```bash
python3 -m pytest -q
```

Production database writes, AEWS connectivity, certificate-chain validation,
image scanning and AutoSys/OCP agent registration must still be validated in the
approved target environment.
