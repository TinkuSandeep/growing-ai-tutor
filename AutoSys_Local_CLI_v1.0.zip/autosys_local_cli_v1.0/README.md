# AutoSys Local CLI v1.0

This utility provides local, non-UI access to approved AutoSys AEWS functions:

- AEWS connectivity check
- Current job details and status
- Detailed run information
- JIL extraction
- Application-wide job inventory to JSON and CSV
- Optional application-wide JIL export
- Safety-controlled force start, hold, ice, off-hold, and off-ice events

It does **not** modify JIL definitions. Control events require the permissions granted to your AEWS identity in EEM.

## 1. Setup

```powershell
cd autosys_local_cli_v1.0
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` locally:

```text
AUTOSYS_API_USER=your_id
AUTOSYS_API_CREDENTIAL=your_credential
```

Do not commit `.env`. Confirm `config/settings.yaml`, the corporate CA certificate, and allowed instances.

You can run directly without installing the package:

```powershell
$env:PYTHONPATH="src"
python -m autosys_local.cli --help
```

On Windows, `run_autosys.bat` provides the same entry point after the virtual
environment has been created:

```powershell
.\run_autosys.bat --instance PC3 health
.\run_autosys.bat --instance PC3 job --job "MY.JOB.NAME"
```

Alternatively install it:

```powershell
pip install -e .
autosys-local --help
```

## 2. Read-only commands

Health check:

```powershell
autosys-local --instance PC3 health
```

Current job details/status:

```powershell
autosys-local --instance PC3 job --job "MY.JOB.NAME"
```

Run information:

```powershell
autosys-local --instance PC3 runs --job "MY.JOB.NAME"
```

Display or save JIL:

```powershell
autosys-local --instance PC3 jil --job "MY.JOB.NAME"
autosys-local --instance PC3 jil --job "MY.JOB.NAME" --output output\MY_JOB.jil
```

Export all jobs/statuses for an application:

```powershell
autosys-local --instance PC3 application --application "ODIN" --output-dir output
```

Also extract the JIL for every returned job:

```powershell
autosys-local --instance PC3 application --application "ODIN" --include-jil --output-dir output
```

The application command creates JSON and CSV inventory files. `--include-jil` creates a combined `.jil` file and reports any job-specific extraction errors.

## 3. Control events

Every event is a preview by default:

```powershell
autosys-local --instance PC3 event --action hold --job "MY.JOB.NAME" --comment "CHG123456 validation"
```

The preview does not change AutoSys. To submit it, add `--execute` and confirm the exact job name:

```powershell
autosys-local --instance PC3 event --action hold --job "MY.JOB.NAME" --comment "CHG123456 validation" --execute --confirm "MY.JOB.NAME"
```

Supported actions:

```text
force-start
hold
ice
off-hold
off-ice
```

Examples:

```powershell
autosys-local --instance PC3 event --action force-start --job "MY.JOB.NAME" --comment "INC123456 approved recovery" --execute --confirm "MY.JOB.NAME"
autosys-local --instance PC3 event --action off-hold --job "MY.JOB.NAME" --comment "CHG123456 maintenance complete" --execute --confirm "MY.JOB.NAME"
```

Each event reads the job before submission, submits one event, reads it again, and appends a credential-free audit record to `output/autosys_actions.jsonl`.

## 4. Operational safeguards

- Use a non-production instance for initial validation.
- Use an AEWS identity with least-privilege EEM permissions.
- Keep production and non-production configuration separate.
- Include an approved incident/change number in `--comment`.
- The utility intentionally permits only one job event per command.
- A job generally cannot be put on hold/ice while it is running.
- Force-start bypasses normal starting conditions; confirm the impact before execution.
- HTTP 401/403 indicates authentication or EEM authorization problems.
- Verify available endpoints in your environment at `https://<AEWS-host>:9443/AEWS/api`.

## 5. Tests

```powershell
pip install pytest
pytest
```
