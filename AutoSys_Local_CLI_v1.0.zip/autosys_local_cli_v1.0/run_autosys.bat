@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Run: py -m venv .venv
  exit /b 1
)
set "PYTHONPATH=%SCRIPT_DIR%src"
".venv\Scripts\python.exe" -m autosys_local.cli %*
exit /b %ERRORLEVEL%
