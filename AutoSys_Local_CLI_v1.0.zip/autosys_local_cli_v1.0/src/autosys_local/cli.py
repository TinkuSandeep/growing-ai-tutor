from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from .client import AutoSysClient, AutoSysError, Settings, audit, extract_jobs


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="autosys-local",
        description="Local AutoSys AEWS inventory and safety-controlled event utility",
    )
    parser.add_argument("--settings", default="config/settings.yaml")
    parser.add_argument("--env-file", default=".env")
    parser.add_argument("--instance", required=True, help="For example PB3, PC3, or PG3")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("health", help="Verify AEWS connectivity")

    for name, help_text in (
        ("job", "Get current job details and status"),
        ("runs", "Get detailed job run information"),
        ("jil", "Extract a job's JIL definition"),
    ):
        item = sub.add_parser(name, help=help_text)
        item.add_argument("--job", required=True)
        if name == "jil":
            item.add_argument("--output", help="Optional output .jil file")

    app = sub.add_parser("application", help="List/export all jobs for an AutoSys application")
    app.add_argument("--application", required=True)
    app.add_argument("--output-dir", default="output")
    app.add_argument("--include-jil", action="store_true")

    event = sub.add_parser("event", help="Preview or execute one controlled job event")
    event.add_argument(
        "--action",
        required=True,
        choices=sorted(AutoSysClient.EVENT_PATHS),
    )
    event.add_argument("--job", required=True)
    event.add_argument("--comment", required=True, help="Change/incident and reason")
    event.add_argument("--execute", action="store_true", help="Actually submit the event")
    event.add_argument(
        "--confirm",
        help="Required with --execute; must exactly match --job",
    )
    return parser


def _print(value: Any) -> None:
    print(json.dumps(value, indent=2, default=str, sort_keys=True))


def _safe_name(value: str) -> str:
    return "".join(char if char.isalnum() or char in "._-" else "_" for char in value)


def _application_export(
    client: AutoSysClient,
    application: str,
    output_dir: str,
    include_jil: bool,
) -> dict[str, Any]:
    payload = client.application_jobs(application)
    jobs = extract_jobs(payload)
    directory = Path(output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    stem = f"{client.instance}_{_safe_name(application)}"
    json_path = directory / f"{stem}_jobs.json"
    csv_path = directory / f"{stem}_jobs.csv"
    json_path.write_text(json.dumps(jobs, indent=2, default=str), encoding="utf-8")
    columns = sorted({str(key) for job in jobs for key in job})
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(jobs)

    jil_path: Path | None = None
    jil_errors: list[dict[str, str]] = []
    if include_jil:
        jil_path = directory / f"{stem}_definitions.jil"
        definitions: list[str] = []
        for job in jobs:
            name = str(job.get("name") or job.get("jobName") or "")
            try:
                definitions.append(client.jil(name).rstrip())
            except AutoSysError as exc:
                jil_errors.append({"job": name, "error": str(exc)})
        jil_path.write_text("\n\n".join(definitions) + "\n", encoding="utf-8")

    return {
        "instance": client.instance,
        "application": application,
        "job_count": len(jobs),
        "json": str(json_path),
        "csv": str(csv_path),
        "jil": str(jil_path) if jil_path else None,
        "jil_error_count": len(jil_errors),
        "jil_errors": jil_errors,
    }


def _event(client: AutoSysClient, settings: Settings, args: argparse.Namespace) -> int:
    preview = {
        "mode": "EXECUTE" if args.execute else "PREVIEW",
        "instance": client.instance,
        "action": args.action,
        "job": args.job,
        "comment": args.comment,
    }
    if not args.execute:
        preview["message"] = "No AutoSys change was submitted. Add --execute and --confirm with the exact job name."
        _print(preview)
        audit(settings, {**preview, "result": "NOT_SUBMITTED"})
        return 0
    if args.confirm != args.job:
        raise AutoSysError("--confirm must exactly match --job when --execute is used")

    before = client.job(args.job)
    response = client.event(args.action, args.job, args.comment)
    after = client.job(args.job)
    result = {**preview, "before": before, "response": response, "after": after}
    _print(result)
    audit(settings, {**preview, "result": "SUBMITTED", "response": response})
    return 0


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    load_dotenv(args.env_file, override=False)
    try:
        settings = Settings.load(args.settings)
        client = AutoSysClient(settings, args.instance)
        if args.command == "health":
            _print(client.health())
        elif args.command == "job":
            _print(client.job(args.job))
        elif args.command == "runs":
            _print(client.runs(args.job))
        elif args.command == "jil":
            value = client.jil(args.job)
            if args.output:
                Path(args.output).write_text(value, encoding="utf-8")
                _print({"job": args.job, "output": args.output})
            else:
                print(value)
        elif args.command == "application":
            _print(
                _application_export(
                    client,
                    args.application,
                    args.output_dir,
                    args.include_jil,
                )
            )
        elif args.command == "event":
            return _event(client, settings, args)
        return 0
    except (AutoSysError, OSError, ValueError, KeyError) as exc:
        print(json.dumps({"result": "FAILED", "error": str(exc)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
