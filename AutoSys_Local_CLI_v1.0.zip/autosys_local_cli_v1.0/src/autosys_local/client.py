from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote

import requests
import yaml
from requests.adapters import HTTPAdapter
from requests.auth import HTTPBasicAuth
from urllib3.util.retry import Retry


class AutoSysError(RuntimeError):
    """User-facing AutoSys or configuration failure."""


@dataclass(frozen=True)
class Settings:
    base_url_template: str
    allowed_instances: tuple[str, ...]
    verify_ssl: bool
    ca_bundle_path: str | None
    timeout_seconds: int
    request_delay_seconds: float
    max_retries: int
    retry_backoff_seconds: float
    api_version: int
    identity_env: str
    credential_env: str
    audit_log: str
    max_application_results: int

    @classmethod
    def load(cls, path: str | Path) -> "Settings":
        with Path(path).open("r", encoding="utf-8") as handle:
            root = yaml.safe_load(handle) or {}
        raw = root.get("autosys", {})
        instances = tuple(str(value).upper() for value in raw.get("allowed_instances", []))
        if not instances:
            raise AutoSysError("autosys.allowed_instances must contain at least one instance")
        return cls(
            base_url_template=str(raw["base_url_template"]),
            allowed_instances=instances,
            verify_ssl=bool(raw.get("verify_ssl", True)),
            ca_bundle_path=str(raw["ca_bundle_path"]) if raw.get("ca_bundle_path") else None,
            timeout_seconds=int(raw.get("timeout_seconds", 120)),
            request_delay_seconds=float(raw.get("request_delay_seconds", 0.2)),
            max_retries=int(raw.get("max_retries", 3)),
            retry_backoff_seconds=float(raw.get("retry_backoff_seconds", 1.0)),
            api_version=int(raw.get("api_version", 3)),
            identity_env=str(raw.get("api_identity_env", "AUTOSYS_API_USER")),
            credential_env=str(raw.get("api_credential_env", "AUTOSYS_API_CREDENTIAL")),
            audit_log=str(raw.get("audit_log", "output/autosys_actions.jsonl")),
            max_application_results=int(raw.get("max_application_results", 2000)),
        )

    def validate_instance(self, instance: str) -> str:
        normalized = instance.upper()
        if normalized not in self.allowed_instances:
            raise AutoSysError(
                f"Instance {normalized!r} is not allowed; choose from {', '.join(self.allowed_instances)}"
            )
        return normalized

    def tls_verification(self) -> bool | str:
        if not self.verify_ssl:
            return False
        if not self.ca_bundle_path:
            return True
        path = Path(self.ca_bundle_path)
        if not path.is_file():
            raise AutoSysError(f"CA bundle does not exist: {path}")
        return str(path)


class AutoSysClient:
    EVENT_PATHS = {
        "force-start": "force-start-job",
        "hold": "hold-job",
        "ice": "ice-job",
        "off-hold": "off-hold-job",
        "off-ice": "off-ice-job",
    }

    def __init__(self, settings: Settings, instance: str):
        self.settings = settings
        self.instance = settings.validate_instance(instance)
        identity = os.getenv(settings.identity_env, "").strip()
        credential = os.getenv(settings.credential_env, "").strip()
        if not identity or not credential:
            raise AutoSysError(
                f"Set {settings.identity_env} and {settings.credential_env} in the environment or .env"
            )
        self.base_url = settings.base_url_template.format(
            instance=self.instance.lower(), INSTANCE=self.instance
        ).rstrip("/")
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(identity, credential)
        self.session.headers.update({"Accept": "application/json"})
        retry = Retry(
            total=settings.max_retries,
            connect=settings.max_retries,
            read=settings.max_retries,
            backoff_factor=settings.retry_backoff_seconds,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET"}),
            raise_on_status=False,
            respect_retry_after_header=True,
        )
        self.session.mount("https://", HTTPAdapter(max_retries=retry))
        self._last_request: float | None = None

    def _pace(self) -> None:
        if self._last_request is not None:
            remaining = self.settings.request_delay_seconds - (time.monotonic() - self._last_request)
            if remaining > 0:
                time.sleep(remaining)
        self._last_request = time.monotonic()

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        payload: dict[str, Any] | None = None,
        accept_json: bool = True,
    ) -> Any:
        self._pace()
        try:
            response = self.session.request(
                method,
                f"{self.base_url}/{path.lstrip('/')}",
                params=params,
                json=payload,
                timeout=self.settings.timeout_seconds,
                verify=self.settings.tls_verification(),
            )
        except requests.RequestException as exc:
            raise AutoSysError(f"AEWS request failed: {exc}") from exc
        if not 200 <= response.status_code < 300:
            detail = response.text.strip().replace("\n", " ")[:500]
            hint = " Verify EEM permissions." if response.status_code in (401, 403) else ""
            raise AutoSysError(
                f"AEWS HTTP {response.status_code} for {method} {path}: {detail or 'no response body'}.{hint}"
            )
        if not response.content:
            return {"http_status": response.status_code}
        if accept_json:
            try:
                return response.json()
            except ValueError:
                return {"http_status": response.status_code, "response": response.text}
        return response.text

    def health(self) -> Any:
        return self._request("GET", "job", params={"count": 1, "version": self.settings.api_version})

    def job(self, job_name: str) -> Any:
        return self._request(
            "GET",
            f"job/{quote(job_name, safe='')}",
            params={"version": self.settings.api_version},
        )

    def runs(self, job_name: str) -> Any:
        return self._request(
            "GET",
            f"job-run-info/{quote(job_name, safe='')}",
            params={"version": self.settings.api_version, "verbose": 1},
        )

    def jil(self, job_name: str) -> str:
        value = self._request(
            "GET",
            "jil/job",
            params={"name": job_name, "timeout": self.settings.timeout_seconds},
            accept_json=False,
        )
        return str(value)

    def application_jobs(self, application: str) -> Any:
        return self._request(
            "GET",
            "job",
            params={
                "filter": f"application=={application}",
                "count": self.settings.max_application_results,
                "version": self.settings.api_version,
            },
        )

    def event(self, action: str, job_name: str, comment: str) -> Any:
        try:
            endpoint = self.EVENT_PATHS[action]
        except KeyError as exc:
            raise AutoSysError(f"Unsupported action: {action}") from exc
        return self._request(
            "POST",
            f"event/{endpoint}",
            payload={"jobName": job_name, "comment": comment},
        )


def extract_jobs(payload: Any) -> list[dict[str, Any]]:
    """Find job-shaped mappings across common AEWS list response wrappers."""
    output: list[dict[str, Any]] = []

    def visit(value: Any) -> None:
        if isinstance(value, list):
            for item in value:
                visit(item)
        elif isinstance(value, dict):
            keys = {str(key).lower() for key in value}
            if "name" in keys and ("status" in keys or "jobtype" in keys or "job_type" in keys):
                output.append(value)
                return
            for nested in value.values():
                visit(nested)

    visit(payload)
    unique: dict[str, dict[str, Any]] = {}
    for item in output:
        name = str(item.get("name") or item.get("jobName") or "")
        if name:
            unique[name] = item
    return [unique[name] for name in sorted(unique, key=str.casefold)]


def audit(settings: Settings, record: dict[str, Any]) -> None:
    path = Path(settings.audit_log)
    path.parent.mkdir(parents=True, exist_ok=True)
    value = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        **record,
    }
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, default=str, sort_keys=True) + "\n")
