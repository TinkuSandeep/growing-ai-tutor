"""AutoSys local CLI."""

__version__ = "1.0.0"
