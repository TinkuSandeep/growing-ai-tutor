from __future__ import annotations

import json

import pytest

from autosys_local.client import AutoSysClient, AutoSysError, Settings, extract_jobs
from autosys_local.cli import main


def settings(tmp_path) -> Settings:
    return Settings(
        base_url_template="https://{instance}.example/AEWS",
        allowed_instances=("PC3", "PB3"),
        verify_ssl=True,
        ca_bundle_path=None,
        timeout_seconds=30,
        request_delay_seconds=0,
        max_retries=0,
        retry_backoff_seconds=0,
        api_version=3,
        identity_env="AUTOSYS_API_USER",
        credential_env="AUTOSYS_API_CREDENTIAL",
        audit_log=str(tmp_path / "audit.jsonl"),
        max_application_results=100,
    )


def test_extract_jobs_from_embedded_payload():
    payload = {"_embedded": {"jobs": [{"name": "B", "jobType": "CMD", "status": "SU"}, {"name": "A", "jobType": "BOX", "status": "RU"}]}}
    assert [job["name"] for job in extract_jobs(payload)] == ["A", "B"]


def test_rejects_unknown_instance(tmp_path, monkeypatch):
    monkeypatch.setenv("AUTOSYS_API_USER", "user")
    monkeypatch.setenv("AUTOSYS_API_CREDENTIAL", "value")
    with pytest.raises(AutoSysError, match="not allowed"):
        AutoSysClient(settings(tmp_path), "DB3")


def test_event_preview_does_not_submit(tmp_path, monkeypatch, capsys):
    config = tmp_path / "settings.yaml"
    config.write_text(
        "autosys:\n"
        "  base_url_template: 'https://{instance}.example/AEWS'\n"
        "  allowed_instances: [PC3]\n"
        f"  audit_log: '{tmp_path / 'audit.jsonl'}'\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("AUTOSYS_API_USER", "user")
    monkeypatch.setenv("AUTOSYS_API_CREDENTIAL", "value")
    result = main([
        "--settings", str(config), "--instance", "PC3", "event",
        "--action", "hold", "--job", "MY_JOB", "--comment", "CHG123 test",
    ])
    assert result == 0
    assert "NOT_SUBMITTED" in (tmp_path / "audit.jsonl").read_text(encoding="utf-8")
    assert '"mode": "PREVIEW"' in capsys.readouterr().out


def test_execute_requires_exact_confirmation(tmp_path, monkeypatch, capsys):
    config = tmp_path / "settings.yaml"
    config.write_text(
        "autosys:\n"
        "  base_url_template: 'https://{instance}.example/AEWS'\n"
        "  allowed_instances: [PC3]\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("AUTOSYS_API_USER", "user")
    monkeypatch.setenv("AUTOSYS_API_CREDENTIAL", "value")
    result = main([
        "--settings", str(config), "--instance", "PC3", "event",
        "--action", "ice", "--job", "MY_JOB", "--comment", "CHG123 test",
        "--execute", "--confirm", "OTHER_JOB",
    ])
    assert result == 1
    assert "exactly match" in capsys.readouterr().err
