from __future__ import annotations

import json

from autosys_local.client import AutoSysClient, Settings


class Response:
    def __init__(self, status_code=200, payload=None, text=""):
        self.status_code = status_code
        self._payload = payload
        self.text = text or (json.dumps(payload) if payload is not None else "")
        self.content = self.text.encode()

    def json(self):
        return self._payload


def settings(tmp_path) -> Settings:
    return Settings(
        base_url_template="https://{instance}.example/AEWS",
        allowed_instances=("PC3",),
        verify_ssl=True,
        ca_bundle_path=None,
        timeout_seconds=30,
        request_delay_seconds=0,
        max_retries=2,
        retry_backoff_seconds=0,
        api_version=3,
        identity_env="AUTOSYS_API_USER",
        credential_env="AUTOSYS_API_CREDENTIAL",
        audit_log=str(tmp_path / "audit.jsonl"),
        max_application_results=500,
    )


def client(tmp_path, monkeypatch) -> AutoSysClient:
    monkeypatch.setenv("AUTOSYS_API_USER", "user")
    monkeypatch.setenv("AUTOSYS_API_CREDENTIAL", "value")
    return AutoSysClient(settings(tmp_path), "pc3")


def test_job_run_info_uses_verbose_endpoint(tmp_path, monkeypatch):
    instance = client(tmp_path, monkeypatch)
    captured = {}

    def request(method, url, **kwargs):
        captured.update(method=method, url=url, kwargs=kwargs)
        return Response(payload={"status": "SU"})

    instance.session.request = request
    assert instance.runs("A B") == {"status": "SU"}
    assert captured["method"] == "GET"
    assert captured["url"].endswith("/job-run-info/A%20B")
    assert captured["kwargs"]["params"]["verbose"] == 1


def test_application_filter_and_count(tmp_path, monkeypatch):
    instance = client(tmp_path, monkeypatch)
    captured = {}

    def request(method, url, **kwargs):
        captured.update(method=method, url=url, kwargs=kwargs)
        return Response(payload={"jobs": []})

    instance.session.request = request
    instance.application_jobs("ODIN")
    assert captured["kwargs"]["params"]["filter"] == "application==ODIN"
    assert captured["kwargs"]["params"]["count"] == 500


def test_jil_extraction_uses_jil_job_endpoint(tmp_path, monkeypatch):
    instance = client(tmp_path, monkeypatch)
    captured = {}

    def request(method, url, **kwargs):
        captured.update(method=method, url=url, kwargs=kwargs)
        return Response(text="insert_job: TEST job_type: CMD")

    instance.session.request = request
    assert "insert_job" in instance.jil("TEST")
    assert captured["url"].endswith("/jil/job")
    assert captured["kwargs"]["params"]["name"] == "TEST"


def test_event_posts_expected_payload(tmp_path, monkeypatch):
    instance = client(tmp_path, monkeypatch)
    captured = {}

    def request(method, url, **kwargs):
        captured.update(method=method, url=url, kwargs=kwargs)
        return Response(status_code=201, payload={"response": "accepted"})

    instance.session.request = request
    value = instance.event("force-start", "TEST", "INC123 recovery")
    assert value == {"response": "accepted"}
    assert captured["method"] == "POST"
    assert captured["url"].endswith("/event/force-start-job")
    assert captured["kwargs"]["json"] == {
        "jobName": "TEST",
        "comment": "INC123 recovery",
    }
