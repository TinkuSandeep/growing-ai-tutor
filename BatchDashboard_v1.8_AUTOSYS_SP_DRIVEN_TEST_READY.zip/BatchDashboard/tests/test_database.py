from contextlib import contextmanager
from datetime import datetime

import pytest

from autosys_phase1.config import DatabaseSettings
from autosys_phase1.database import (
    SQLServerRepository,
    load_mock_targets,
    update_procedure_command,
)
from autosys_phase1.errors import DatabaseError
from autosys_phase1.models import RuntimeUpdate, TargetJob


SETTINGS = DatabaseSettings(
    connection_string_env="SQLSERVER_CONNECTION_STRING",
    discovery_stored_procedure="dbo.cp_Get_Critical_Batch_Jobs",
    update_stored_procedure="dbo.cp_UpdateJobExecutionStatus",
    job_name_column="job_name",
    instance_column="instance_name",
)


class FakeCursor:
    description = [("process_name",), ("job_name",), ("instance_name",), ("sla",)]

    def __init__(self, rows):
        self.rows = rows
        self.sql = None

    def execute(self, sql, *parameters):
        self.sql = sql
        return self

    def fetchall(self):
        return self.rows


class FakeConnection:
    def __init__(self, rows):
        self._cursor = FakeCursor(rows)

    def cursor(self):
        return self._cursor


class FakeRepository(SQLServerRepository):
    def __init__(self, rows):
        super().__init__(SETTINGS)
        self.connection = FakeConnection(rows)

    @contextmanager
    def _connection(self):
        yield self.connection


def test_discovery_uses_only_job_and_instance_columns():
    repository = FakeRepository(
        [("ignored process", "CREEP_CTR_DAILY_LOAD", "pb3", "ignored SLA")]
    )
    assert repository.load_targets() == [
        TargetJob(job_name="CREEP_CTR_DAILY_LOAD", instance="PB3")
    ]
    assert "cp_Get_Critical_Batch_Jobs" in repository.connection._cursor.sql


def test_duplicate_job_names_are_rejected():
    repository = FakeRepository(
        [("A", "SAME_JOB", "PB3", None), ("B", "SAME_JOB", "PC3", None)]
    )
    with pytest.raises(DatabaseError, match="duplicate names"):
        repository.load_targets()


def test_update_call_has_only_four_runtime_parameters():
    update = RuntimeUpdate(
        target=TargetJob("CREEP_CTR_DAILY_LOAD", "PB3"),
        run_number=10,
        job_start_time=datetime(2026, 9, 22, 6, 0),
        job_end_time=None,
        job_status="RU",
    )
    sql, parameters = update_procedure_command(SETTINGS, update)
    assert "cp_UpdateJobExecutionStatus" in sql
    assert "average" not in sql.casefold()
    assert parameters == (
        "CREEP_CTR_DAILY_LOAD",
        "2026-09-22 06:00:00",
        None,
        "RU",
    )
