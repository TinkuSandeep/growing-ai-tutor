from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .errors import ConfigurationError


_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise ConfigurationError(f"Required environment variable is not set: {name}")
    return value


def quote_sql_object_name(value: str) -> str:
    """Safely quote a two- or three-part SQL Server object name."""
    parts = value.split(".")
    if len(parts) not in (2, 3) or any(not _IDENTIFIER.fullmatch(part) for part in parts):
        raise ConfigurationError(f"Unsafe SQL Server object name: {value!r}")
    return ".".join(f"[{part}]" for part in parts)


@dataclass(frozen=True)
class AutoSysSettings:
    base_url_template: str
    verify_ssl: bool
    timeout_seconds: int
    api_version: int
    timezone: str
    store_naive_local_time: bool
    api_principal_env: str = "AUTOSYS_API_USER"
    api_secret_env: str = "AUTOSYS_API_PASSWORD"

    def credentials(self) -> tuple[str, str]:
        return _required_env(self.api_principal_env), _required_env(self.api_secret_env)


@dataclass(frozen=True)
class DatabaseSettings:
    connection_string_env: str
    discovery_stored_procedure: str
    update_stored_procedure: str
    job_name_column: str
    instance_column: str

    @property
    def quoted_discovery_stored_procedure(self) -> str:
        return quote_sql_object_name(self.discovery_stored_procedure)

    @property
    def quoted_update_stored_procedure(self) -> str:
        return quote_sql_object_name(self.update_stored_procedure)

    def connection_string(self) -> str:
        return _required_env(self.connection_string_env)


@dataclass(frozen=True)
class IngestionSettings:
    output_directory: str
    log_directory: str
    abort_on_job_error: bool
    require_minimum_target_count: int | None


@dataclass(frozen=True)
class Settings:
    autosys: AutoSysSettings
    database: DatabaseSettings
    ingestion: IngestionSettings


def _load_yaml(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle) or {}
    if not isinstance(value, dict):
        raise ConfigurationError("Configuration root must be a YAML mapping")
    return value


def load_settings(path: str | Path) -> Settings:
    raw = _load_yaml(path)
    a = raw.get("autosys", {})
    d = raw.get("database", {})
    i = raw.get("ingestion", {})

    autosys = AutoSysSettings(
        base_url_template=str(
            a.get(
                "base_url_template",
                "https://{instance}-autosyswebapi.wellsfargo.com/AEWS",
            )
        ),
        verify_ssl=bool(a.get("verify_ssl", True)),
        timeout_seconds=int(a.get("timeout_seconds", 120)),
        api_version=int(a.get("api_version", 3)),
        timezone=str(a.get("timezone", "America/New_York")),
        store_naive_local_time=bool(a.get("store_naive_local_time", True)),
        api_principal_env=str(a.get("api_principal_env", "AUTOSYS_API_USER")),
        api_secret_env=str(a.get("api_secret_env", "AUTOSYS_API_PASSWORD")),
    )

    database = DatabaseSettings(
        connection_string_env=str(
            d.get("connection_string_env", "SQLSERVER_CONNECTION_STRING")
        ),
        discovery_stored_procedure=str(
            d.get("discovery_stored_procedure", "dbo.cp_Get_Critical_Batch_Jobs")
        ),
        update_stored_procedure=str(
            d.get("update_stored_procedure", "dbo.cp_UpdateJobExecutionStatus")
        ),
        job_name_column=str(d.get("job_name_column", "job_name")),
        instance_column=str(d.get("instance_column", "instance_name")),
    )
    database.quoted_discovery_stored_procedure
    database.quoted_update_stored_procedure
    for column in (database.job_name_column, database.instance_column):
        if not _IDENTIFIER.fullmatch(column):
            raise ConfigurationError(f"Unsafe stored procedure output column: {column!r}")

    minimum = i.get("require_minimum_target_count")
    ingestion = IngestionSettings(
        output_directory=str(i.get("output_directory", "output")),
        log_directory=str(i.get("log_directory", "logs")),
        abort_on_job_error=bool(i.get("abort_on_job_error", True)),
        require_minimum_target_count=int(minimum) if minimum is not None else None,
    )
    return Settings(autosys=autosys, database=database, ingestion=ingestion)
