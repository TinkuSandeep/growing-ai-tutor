Batch Dashboard v1.8 - Production Deployment
============================================

1. Confirm database objects
   - dbo.cp_Get_Critical_Batch_Jobs exists.
   - It returns job_name and instance_name for AutoSys jobs only.
   - RTO and SAPBI activity-table jobs have been removed from the POC catalog.
   - dbo.cp_UpdateJobExecutionStatus accepts:
       @job_name, @job_start_time, @job_end_time, @job_status

2. Configure access
   - AEWS service identity: read access to every returned AutoSys instance.
   - Database service identity: EXECUTE on both approved procedures.
   - Do not grant source-table or target-table access when procedure execution is sufficient.

3. Install
   python -m venv venv
   venv\Scripts\python.exe -m pip install -r requirements-sqlserver.txt
   copy .env.example .env

4. Validate
   scripts\run_mock.bat
   scripts\run_prod_dry_run.bat

5. Controlled write
   scripts\run_prod_write.bat

6. Verify
   - All discovered jobs show PASSED.
   - target_rows_updated equals requested.
   - Dashboard start, end and status values match AEWS.
   - Logs and JSON reports were generated.

7. Schedule
   Configure AutoSys to call scripts\run_prod_write.bat every five minutes.
   Capture return code and standard output.
