# Batch Dashboard AutoSys Runtime Ingestion v1.8

This release is **AutoSys-only** and **stored-procedure driven**.

## What changed

- Removed SAPBI, RTO activity-table and SQL_ACTIVITY source code.
- Removed `source_jobs.yaml`; production job names are not stored in code or YAML.
- Removed Python calculations for averages, SLA and baseline runs.
- Added dynamic job discovery through `dbo.cp_Get_Critical_Batch_Jobs`.
- Python uses only `job_name` and `instance_name` from that result set.
- Added multi-instance AEWS routing from the returned instance value.
- Restored the four-parameter `dbo.cp_UpdateJobExecutionStatus` call.
- Added CREEP CTR/MIL offline examples; no production job name is hard-coded.

## Production flow

1. Connect to the Batch Dashboard database using `SQLSERVER_CONNECTION_STRING`.
2. Execute `dbo.cp_Get_Critical_Batch_Jobs`.
3. Read only `job_name` and `instance_name` from every returned row.
4. Build the AEWS URL from each instance, such as PB3 or PC3.
5. Retrieve the latest AutoSys run in JSON format.
6. Normalize start time, end time and status to the dashboard contract.
7. In write mode, call `dbo.cp_UpdateJobExecutionStatus` once per job.
8. Commit all updates together; roll back the complete cycle on a write failure.
9. Write a JSON report under `output` and a text log under `logs`.

The Python layer contains no SLA, average-time or dashboard business logic. Those
rules belong to the database/dashboard layer.

## Required discovery procedure columns

`dbo.cp_Get_Critical_Batch_Jobs` must return:

- `job_name`: exact AutoSys job name.
- `instance_name`: AutoSys instance such as PB3, PC3, PG3, PA3, DB3, DC3, UB3 or UC3.

Other returned columns are ignored. If the DBA uses a different column name,
change only `job_name_column` or `instance_column` in `config/settings.yaml`.

## First-time setup

```bat
python -m venv venv
venv\Scripts\python.exe -m pip install -r requirements-sqlserver.txt
copy .env.example .env
```

Populate `.env` using the approved service identities. Never commit `.env`.

## Test order

```bat
scripts\run_mock.bat
scripts\run_prod_dry_run.bat
scripts\run_prod_write.bat
```

- `run_mock.bat`: no network or database access and no write.
- `run_prod_dry_run.bat`: calls the discovery procedure and AEWS, but does not update the dashboard.
- `run_prod_write.bat`: performs discovery, AEWS collection and the target procedure calls.

To test one AutoSys job directly:

```bat
scripts\test_aews_job.bat PB3 EXACT_AUTOSYS_JOB_NAME
```

## Production safety

- Mock data cannot be used with `--write`.
- Zero discovery rows fail the execution.
- Duplicate job names fail before any AEWS call because the update procedure identifies rows by name.
- By default, one AEWS failure blocks the complete target write.
- All target updates use bound SQL parameters and a single database transaction.
