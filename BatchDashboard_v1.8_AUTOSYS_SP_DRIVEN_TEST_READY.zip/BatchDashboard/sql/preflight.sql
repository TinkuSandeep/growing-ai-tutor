-- Run using the same database identity configured for the application.

EXEC dbo.cp_Get_Critical_Batch_Jobs;

-- Confirm the result contains exact column names:
--   job_name
--   instance_name
-- and contains AutoSys jobs only.

SELECT
    OBJECT_ID(N'dbo.cp_Get_Critical_Batch_Jobs', N'P') AS discovery_procedure_id,
    OBJECT_ID(N'dbo.cp_UpdateJobExecutionStatus', N'P') AS update_procedure_id;

SELECT
    HAS_PERMS_BY_NAME(N'dbo.cp_Get_Critical_Batch_Jobs', N'OBJECT', N'EXECUTE')
        AS can_execute_discovery,
    HAS_PERMS_BY_NAME(N'dbo.cp_UpdateJobExecutionStatus', N'OBJECT', N'EXECUTE')
        AS can_execute_update;
