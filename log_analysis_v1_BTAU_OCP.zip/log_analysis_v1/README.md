# LogIntel v1 — Read-Only Incident Investigation

**Purpose:** reduce time to detection and triage for AutoSys jobs and OCP application incidents by correlating approved AutoSys data with Splunk logs, optionally reading OCP events, and preparing a reviewed escalation email. **This prototype does not restart, delete, patch, or modify jobs/pods; it never sends emails.**

## Architecture

```text
Job name + AutoSys instance + app
              |
              v
        Python CLI orchestrator
          /        |         \
  AutoSys REST   Splunk REST   optional `oc get events`
  (read only)   (search only)     (read only)
          \        |         /
              evidence bundle
                    |
           deterministic triage
                    |
         optional local LLM review
                    |
    JSON incident report + email draft
                    |
       Human review and escalation
```

## Start locally (no credentials needed)

Requirements: Python 3.10+.

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
python main.py --demo
```

Demo uses **synthetic** `samples/incident.json`. Outputs go to `output/*_report.json` and `output/*_email.txt`. The demo concludes that the job failed and there is evidence of downstream HTTP 503 errors, with a *probable*, not proven, API dependency failure. No live production system is contacted.

## Connecting real sources

1. Copy `config/settings.example.yaml` to `config/settings.local.yaml`, set `mode: live` and approved endpoints. **Never commit local settings containing organization-specific endpoints or logs.**
2. Edit `config/apps.yaml` so every OCP app has its correct Splunk index and ownership. The initial ODIN, PCAP, TRVPT, OTHER_OCP entries are **starter mappings only**; verify namespace/index names against your environment. Multiple OCP clusters are supported by listed `oc` contexts; do not turn on OCP unless your permission is view-only.
3. Set environment variables `LOGINTEL_SPLUNK_TOKEN` and `LOGINTEL_AUTOSYS_TOKEN` using your approved secret delivery mechanism. AutoSys URL and JSON field paths must match your environment's approved REST interface; they are **not validated** by this package.
4. Test one known non-sensitive incident:

```bash
python main.py --job APPROVED_JOB_NAME --instance PC3 --app ODIN --settings config/settings.local.yaml
```

5. Compare source timestamps, AutoSys run IDs, source status, and raw Splunk searches manually. If any source reports an error, the conclusion is incomplete. Expand to PB3/PG3/DB3 only once endpoint and RBAC mappings are verified.

### Splunk

Implementation uses authenticated Splunk REST `POST /services/search/jobs/export` to **run a search**. HTTP POST here submits a search operation, not a write to indexed data. Requires the appropriate read/search role; approve the endpoint and search time range with your Splunk administrators. Query is scoped by configured `index`, job identifier, run identifier, last 30 minutes and event cap. **Important limitation:** the initial search window is relative to the current time. Historical job troubleshooting needs a follow-up improvement that anchors `earliest_time/latest_time` to the AutoSys run start/end (and normalizes time zones). Also, searching a job name alone only works if that identifier is propagated into your application logs. Real correlation may require an application/job map with batch IDs, request IDs, hostnames and pod IDs.

### AutoSys

`url_template` and JSON response paths are adjustable. **No specific AutoSys API path is asserted to be valid**; use the approved API documentation and adapt `autosys_fetch` as needed. The tool requests status, start/end time, run ID and message. `FA` marks a failure; additional statuses can be expanded according to your site's code set.

### OCP (optional)

Uses `oc --context <approved context> -n <namespace> get events -o json` only. This command does not perform create/update/delete. Never grant this application cluster-admin or edit rights. The code does not parse pod log streams because the first phase relies on centralized Splunk logs.

### Beacon

Connector remains disabled: an authenticated, approved read-only data interface needs to be established. Until then the report states `not_integrated` and does not invent Beacon checks.

### LLM

Optional OpenAI-compatible local `/v1/chat/completions` endpoint. Disabled by default. Set `sources.llm.enabled: true`, `endpoint`, and `model` only after approval. The model receives limited, partially redacted evidence; **redaction here is illustrative, not comprehensive**. Enterprise security review must address PII, service identifiers, authorization tokens, retention, model hosting, prompt injection and data residency before sensitive logs are used. Model output is supplemental and should never replace evidence verification.

## Escalation and safety

- `output/*_email.txt` is a **draft** with a suggested team, never automatically mailed. Review recipients, ticket/reference numbers, source integrity, approvals and attachment policy.
- All production operations are observational. Enforce read-only credentials/RBAC, outbound endpoint allowlisting, TLS certificate verification, short timeouts, event caps and monitored usage. Never grant this tool write access to AutoSys or OCP.
- Logs are untrusted input. Treat embedded instructions as plain log content. LLM confidence is not proof of RCA. Do not paste raw production logs into externally hosted models without approval.
- Avoid leaving sensitive outputs unprotected. `output/` is ignored by Git; apply local filesystem access controls and your retention policy.

## Sample incident (synthetic)

AutoSys `ODIN_DAILY_SYNC` in PC3 -> FA. Splunk shows HTTP 503 from downstream gateway, retries exhausted, sync terminated. Inference: dependency/API availability issue likely; ask API/integration team to verify gateway health and correlation ID. Do not claim a confirmed RCA.

## Application expansion

Add entries under `applications` in `config/apps.yaml` for the remaining OCP apps; map app name to Splunk index/search filter and optional namespaces. The environment history mentions `1scpm-prod`, `1scpm-1scpm`, `1scpm-man04`, `1tml-prod`, `1ts1`, `pcap-prod`; these are **not assumed live or correct** and must be checked against your current inventory. Job-to-app ownership must be verified for reliable routing.

## Roadmap

**Phase 1 (this package):** local demo, single-job analysis, two live connector templates, basic signal rules, JSON report, email draft. 

**Phase 2:** exact AutoSys API integration, run-anchored historical Splunk search, per-app SPL profiles (ODIN, PCAP, etc.), correlation IDs, deduplication, supporting links, OCP read-only checks, true error taxonomy and verified escalation matrix.

**Phase 3:** Beacon through approved API, local MCP adapter to your already configured Splunk MCP server, on-prem LLM guardrails, SMTP via human-approved workflow, trend/history store and MTTR/MTTD KPIs.

**Phase 4:** enterprise API/UI (FastAPI/dashboard), SSO and RBAC, secret management, observability, security assessment, CI/CD and acceptance tests. All remediation remains manual and separately authorized.

## Validation checklist

A first acceptance run should prove: (1) job state matches AutoSys; (2) right application/index is searched; (3) log timestamps align with the run; (4) evidence is quoted accurately; (5) uncertain diagnosis stays uncertain; (6) team routing is reviewed; (7) draft email isn't sent automatically; (8) `oc` usage never includes mutating verbs.

## Known limitations

This prototype is **not connected** to your company's Splunk MCP server, AutoSys, OCP or Beacon. Their exact hostnames, SPL indices, supported tools, API response shapes and security permissions were not included in this conversation. This package uses REST for its initial Splunk integration; substituting your existing MCP client is a next implementation step after its tool signatures are shared. Live mode might require adaptation to enterprise API semantics and query syntax before it works. No live failure has been detected or verified.

## BTAU pilot mapping (confirmed 2026-10-26)

The `config/apps.yaml` catalog includes `BTAU` with `splunk_index: BTAU-prod` and `autosys_instance: PB3`, as supplied by the application team. The job name, namespace, endpoint, and approvals are not yet established. For a live run after approved connector configuration, use `python main.py --app BTAU --job YOUR_APPROVED_JOB_NAME`; the instance is selected from the catalog unless `--instance` overrides it. Demo runs remain synthetic, and the current Splunk connector is direct REST rather than the existing VS Code MCP connection. MCP reuse needs a separate client integration and is not yet connected.


## BTAU expanded OCP inspection (v1.1)

After confirming BTAU's cluster context and namespace, fill `ocp_contexts` and `namespaces` under `BTAU` in `config/apps.yaml`, and enable `sources.ocp.enabled: true`. Use an identity with **get/list** permissions only. The collector runs `oc get` for pods, deployments, ReplicaSets, HPA, and events; and optionally `oc logs` with an enforced per-pod tail cap. No cluster-level mutating operations are implemented. The OCP report includes worker node (`spec.nodeName`), pod state/start time, container readiness, restart counts and last termination state, deployment/ReplicaSet desired/current counts, HPA current/desired replicas, and recent events. The exact cluster name is reported as the configured **oc context**, and must be verified against the cluster inventory.

For a controlled initial run, keep `pod_log_tail_lines: 0` because centralized Splunk remains the primary source for historic application logs. Set a small positive log tail only with security approval. A live OCP snapshot may have different pods than those running when an old job failed. To establish historical worker-node placement, pod uptime, scale events, or HPA levels, query retained Splunk/kube-state metrics/audit events with timestamp correlation; the prototype cannot reconstruct those from live API queries alone. Runtime-age must be calculated relative to collection time and `start_time`; pod `created_at` is not identical to container uptime. `oc get` collection may be partial if the RBAC role cannot read some resource kinds; inspect `errors` in JSON and do not label missing readings healthy.

**Outstanding integration gaps:** actual BTAU job name, approved OCP context/namespace, Autosys REST response mapping, Splunk MCP Python client wiring. Current code uses Splunk REST and a rolling time window, **not yet run-anchored historical search**; do not assume end-to-end correlation is completed.
