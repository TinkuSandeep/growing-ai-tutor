"""Read-only cross-source incident investigator."""
