#!/usr/bin/env python3
"""Local, read-only incident investigator. Run `python main.py --demo`."""
import argparse, json, sys
from datetime import datetime, timezone
from pathlib import Path
from logintel.core import load_yaml, autosys_fetch, splunk_fetch, ocp_fetch, analyze, llm_enrich, draft_email, SAFE_JOB

ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser(description='Read-only incident investigator')
    parser.add_argument('--demo', action='store_true', help='Run with bundled synthetic data')
    parser.add_argument('--job', help='AutoSys job name')
    parser.add_argument('--instance', default=None, help='Override configured AutoSys instance')
    parser.add_argument('--app', default='BTAU')
    parser.add_argument('--settings', default=str(ROOT/'config/settings.example.yaml'))
    parser.add_argument('--apps', default=str(ROOT/'config/apps.yaml'))
    args=parser.parse_args()
    if not args.demo and (not args.job or not SAFE_JOB.fullmatch(args.job)):
        parser.error('Live mode requires a valid --job')
    if args.demo:
        data=json.loads((ROOT/'samples/incident.json').read_text(encoding='utf-8'))
        data['source_status']={'autosys':'synthetic_demo', 'splunk':'synthetic_demo', 'ocp':'not_collected', 'beacon':'not_integrated'}
        llm_cfg={'enabled':False}
    else:
        cfg=load_yaml(args.settings)
        if cfg.get('mode') != 'live':
            parser.error('Set mode: live in settings YAML before using real connectors')
        catalog=load_yaml(args.apps)['applications']
        if args.app not in catalog: parser.error('App missing from apps YAML')
        app=catalog[args.app]
        instance=args.instance or app.get('autosys_instance')
        if not instance: parser.error('Specify --instance or configure autosys_instance for the app')
        data={'job':args.job, 'instance':instance, 'application':args.app,
              'autosys':{}, 'splunk':[], 'ocp':{}, 'source_status':{}}
        sources=cfg['sources']
        if sources['autosys'].get('enabled'):
            try:
                data['autosys']=autosys_fetch(args.job, instance, sources['autosys'])
                data['source_status']['autosys']='collected'
            except Exception as e: data['source_status']['autosys']='error: '+str(e)[:180]
        if sources['splunk'].get('enabled'):
            try:
                data['splunk']=splunk_fetch(args.job, data['autosys'].get('run_id'), app,
                    sources['splunk'], cfg.get('window_minutes', 30), cfg.get('max_events',100))
                data['source_status']['splunk']='collected'
            except Exception as e: data['source_status']['splunk']='error: '+str(e)[:180]
        try:
            data['ocp']=ocp_fetch(app, sources.get('ocp',{}))
            data['source_status']['ocp']=data['ocp']['status']
        except Exception as e: data['source_status']['ocp']='error: '+str(e)[:180]
        data['source_status']['beacon']='not_integrated'
        llm_cfg=sources.get('llm',{})
    summary=analyze(data)
    try:
        extra=llm_enrich(summary, data, llm_cfg)
        if extra: summary['llm_assessment']=extra
    except Exception as e: summary['llm_status']='unavailable: '+str(e)[:180]
    output=ROOT/'output'; output.mkdir(exist_ok=True)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    name=''.join(c if c.isalnum() or c in '-_' else '_' for c in data['job'])
    stem=f'{stamp}_{name}'
    report=output/(stem+'_report.json'); mail=output/(stem+'_email.txt')
    report.write_text(json.dumps(summary, indent=2), encoding='utf-8')
    mail.write_text(draft_email(summary), encoding='utf-8')
    print(json.dumps({k:summary[k] for k in ('job','job_status','probable_cause','confidence','suggested_team','source_status')}, indent=2))
    print(f'\nReport: {report}\nDraft email (NOT sent): {mail}')
    if not args.demo and not data['source_status'].get('autosys')=='collected' and not data['source_status'].get('splunk')=='collected':
        print('WARNING: Neither primary source was collected; do not treat result as RCA.', file=sys.stderr)
        return 2
    return 0

if __name__=='__main__': sys.exit(main())
