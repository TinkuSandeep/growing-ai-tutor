# BatchDashboard Source Validation v1.5

Version 1.5 reads SAPBI execution details from the approved application table:

```text
CPG_Mart.dbo.DATA_MGMNT_JOBS_ACTVTY
```

It does not query `msdb`, `sysjobactivity`, `syssessions`, or SQL Agent history
procedures. Only a parameterized read-only `SELECT` is issued against the table
configured under `sql_activity.table` in `config/source_jobs.yaml`.

## SAPBI mapping

| Batch Dashboard field | CPG_Mart source |
|---|---|
| `job_start_time` | `LAST_RUN_DATETIME` |
| `job_end_time` | `LAST_RUN_DATETIME + LAST_RUN_DURATION` |
| `job_status` | normalized `RUN_STATUS` |

`LAST_RUN_DURATION` is parsed as `HH:MM:SS`. `Succeeded`, `Failed`, `Running`,
`Executing`, `Cancelled`, and `Retry` are mapped to the two-character dashboard
status values. A running execution has a null end time. Unknown values fail
validation instead of being written incorrectly.

## Configure

Copy `.env.example` to `.env` and set the local values. The SAPBI connection
must open the `CPG_Mart` database:

```text
SAPBI_SQL_CONNECTION_STRING=DRIVER={ODBC Driver 17 for SQL Server};SERVER=<server\instance>;DATABASE=CPG_Mart;Trusted_Connection=yes;TrustServerCertificate=yes;
```

Do not put credentials in YAML, Python, batch files, or source control.

## Test

From the `BatchDashboard` directory:

```bat
scripts\test_sapbi_prod.bat
```

Then test both sources:

```bat
scripts\test_all_sources.bat
```

Offline test:

```bat
scripts\test_all_sources_mock.bat
```

Every run creates a JSON report under `output` and a log under `logs`. These
source tests do not connect to or update the Batch Dashboard target table.

## Configured SAPBI jobs

- `CPG_SPC_OCC_S_EMP_HR_BADGE_EVENTS_ODIN`
- `CPG_Splunk_SEP_Data_CLOUDAPI`
- `CPG_GP_VPN_DAILY_DATALOAD_CLOUDAPI`
- `CPG_DAILY_STATUS_ON_RTO`

The names live in `config/source_jobs.yaml`; they are not hard-coded in Python.
