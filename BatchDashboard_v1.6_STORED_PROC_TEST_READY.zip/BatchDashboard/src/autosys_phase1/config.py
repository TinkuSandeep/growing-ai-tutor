from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .errors import ConfigurationError


_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise ConfigurationError(f"Required environment variable is not set: {name}")
    return value


def quote_sql_object_name(value: str) -> str:
    """Safely quote a two- or three-part SQL Server object name."""
    parts = value.split(".")
    if len(parts) not in (2, 3) or any(not _IDENTIFIER.fullmatch(part) for part in parts):
        raise ConfigurationError(f"Unsafe SQL Server object name: {value!r}")
    return ".".join(f"[{part}]" for part in parts)


@dataclass(frozen=True)
class AutoSysSettings:
    base_url_template: str
    default_instance: str
    verify_ssl: bool
    timeout_seconds: int
    api_version: int
    workers: int
    timezone: str
    store_naive_local_time: bool
    app_instance_overrides: dict[str, str] = field(default_factory=dict)
    job_instance_overrides: dict[str, str] = field(default_factory=dict)
    api_principal_env: str = "AUTOSYS_API_USER"
    api_secret_env: str = "AUTOSYS_API_PASSWORD"

    def instance_for(self, app_id: str, job_name: str) -> str:
        return (
            self.job_instance_overrides.get(job_name)
            or self.app_instance_overrides.get(app_id)
            or self.default_instance
        ).upper()

    def credentials(self) -> tuple[str, str]:
        return _required_env(self.api_principal_env), _required_env(self.api_secret_env)


@dataclass(frozen=True)
class DatabaseSettings:
    connection_string_env: str
    table: str
    scheduler_value: str
    write_mode: str
    stored_procedure: str | None
    updated_by: str
    update_audit_columns: bool

    @property
    def quoted_table(self) -> str:
        return quote_sql_object_name(self.table)

    @property
    def quoted_stored_procedure(self) -> str | None:
        return quote_sql_object_name(self.stored_procedure) if self.stored_procedure else None

    def connection_string(self) -> str:
        return _required_env(self.connection_string_env)


@dataclass(frozen=True)
class IngestionSettings:
    dry_run: bool
    abort_on_job_error: bool
    require_exact_target_count: int | None
    output_directory: str


@dataclass(frozen=True)
class Settings:
    autosys: AutoSysSettings
    database: DatabaseSettings
    ingestion: IngestionSettings


def _load_yaml(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle) or {}
    if not isinstance(value, dict):
        raise ConfigurationError("Configuration root must be a YAML mapping")
    return value


def load_settings(path: str | Path) -> Settings:
    raw = _load_yaml(path)
    a = raw.get("autosys", {})
    d = raw.get("database", {})
    i = raw.get("ingestion", {})

    autosys = AutoSysSettings(
        base_url_template=str(a.get("base_url_template", "https://{instance}-autosyswebapi.wellsfargo.com/AEWS")),
        default_instance=str(a.get("default_instance", "PB3")).upper(),
        verify_ssl=bool(a.get("verify_ssl", True)),
        timeout_seconds=int(a.get("timeout_seconds", 120)),
        api_version=int(a.get("api_version", 3)),
        workers=max(1, int(a.get("workers", 5))),
        timezone=str(a.get("timezone", "America/New_York")),
        store_naive_local_time=bool(a.get("store_naive_local_time", True)),
        app_instance_overrides={str(k): str(v).upper() for k, v in (a.get("app_instance_overrides") or {}).items()},
        job_instance_overrides={str(k): str(v).upper() for k, v in (a.get("job_instance_overrides") or {}).items()},
        api_principal_env=str(a.get("api_principal_env", "AUTOSYS_API_USER")),
        api_secret_env=str(a.get("api_secret_env", "AUTOSYS_API_PASSWORD")),
    )

    write_mode = str(d.get("write_mode", "direct")).lower()
    stored_procedure = d.get("stored_procedure")
    if write_mode not in {"direct", "stored_procedure"}:
        raise ConfigurationError("database.write_mode must be direct or stored_procedure")
    if write_mode == "stored_procedure" and not stored_procedure:
        raise ConfigurationError("database.stored_procedure is required for stored_procedure mode")

    database = DatabaseSettings(
        connection_string_env=str(d.get("connection_string_env", "SQLSERVER_CONNECTION_STRING")),
        table=str(d.get("table", "TCOO_TOOLS.dbo.cp_critical_batch_jobs")),
        scheduler_value=str(d.get("scheduler_value", "AUTOSYS")),
        write_mode=write_mode,
        stored_procedure=str(stored_procedure) if stored_procedure else None,
        updated_by=str(d.get("updated_by", "autosys_phase1_ingestion")),
        update_audit_columns=bool(d.get("update_audit_columns", True)),
    )
    # Validate configured identifiers during startup.
    database.quoted_table
    database.quoted_stored_procedure

    expected = i.get("require_exact_target_count")
    ingestion = IngestionSettings(
        dry_run=bool(i.get("dry_run", True)),
        abort_on_job_error=bool(i.get("abort_on_job_error", True)),
        require_exact_target_count=int(expected) if expected is not None else None,
        output_directory=str(i.get("output_directory", "output")),
    )
    return Settings(autosys=autosys, database=database, ingestion=ingestion)

