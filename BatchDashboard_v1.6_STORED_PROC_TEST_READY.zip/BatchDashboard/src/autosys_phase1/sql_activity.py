from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from .errors import DatabaseError, DataValidationError
from .source_config import SQLActivitySourceSettings


STATUS_MAP = {
    "succeeded": "SU",
    "success": "SU",
    "su": "SU",
    "failed": "FA",
    "failure": "FA",
    "fa": "FA",
    "running": "RU",
    "executing": "RU",
    "in progress": "RU",
    "ru": "RU",
    "cancelled": "CA",
    "canceled": "CA",
    "ca": "CA",
    "retry": "RE",
    "re": "RE",
}


@dataclass(frozen=True)
class SQLActivityRun:
    execution_id: int
    job_start_time: datetime | None
    job_end_time: datetime | None
    job_status: str


def duration_text_to_seconds(value: Any) -> int:
    """Convert the CPG_Mart LAST_RUN_DURATION value (HH:MM:SS)."""
    text = str(value or "").strip()
    match = re.fullmatch(r"(\d+):(\d{2}):(\d{2})", text)
    if not match:
        raise DataValidationError(f"Invalid LAST_RUN_DURATION: {value!r}")
    hours, minutes, seconds = (int(part) for part in match.groups())
    if minutes > 59 or seconds > 59:
        raise DataValidationError(f"Invalid LAST_RUN_DURATION: {value!r}")
    return hours * 3600 + minutes * 60 + seconds


def normalize_activity_status(value: Any) -> str:
    key = " ".join(str(value or "").strip().lower().split())
    try:
        return STATUS_MAP[key]
    except KeyError as exc:
        raise DataValidationError(f"Unsupported RUN_STATUS: {value!r}") from exc


def _quoted_table(value: str) -> str:
    parts = value.strip().split(".")
    if len(parts) not in {2, 3} or any(
        not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", part) for part in parts
    ):
        raise DataValidationError(
            "sql_activity.table must be a two- or three-part SQL identifier"
        )
    return ".".join(f"[{part}]" for part in parts)


def _convert_time(
    value: datetime | None,
    source_timezone: str,
    output_timezone: str,
    naive: bool,
) -> datetime | None:
    if value is None:
        return None
    source_zone = ZoneInfo(source_timezone)
    output_zone = ZoneInfo(output_timezone)
    aware = value.replace(tzinfo=source_zone) if value.tzinfo is None else value
    converted = aware.astimezone(output_zone)
    return converted.replace(tzinfo=None) if naive else converted


class SQLActivityClient:
    """Read the latest SAPBI job activity row from the approved CPG_Mart table."""

    def __init__(self, settings: SQLActivitySourceSettings):
        self.settings = settings
        self.table = _quoted_table(settings.table)

    def _connect(self):
        try:
            import pyodbc
        except ImportError as exc:
            raise DatabaseError(
                "pyodbc is required for SAPBI activity checks; "
                "install requirements-sqlserver.txt"
            ) from exc
        try:
            return pyodbc.connect(
                self.settings.connection_string(), autocommit=True, timeout=30
            )
        except Exception as exc:
            raise DatabaseError(f"SAPBI activity database connection failed: {exc}") from exc

    def get_latest_run(self, job_name: str) -> SQLActivityRun:
        query = f"""
            SELECT TOP (1)
                Time_ID,
                JOB_NAME,
                LAST_RUN_DATETIME,
                LAST_RUN_DURATION,
                RUN_STATUS
            FROM {self.table}
            WHERE JOB_NAME = ?
            ORDER BY Time_ID DESC, LAST_RUN_DATETIME DESC
        """
        connection = self._connect()
        try:
            cursor = connection.cursor()
            row = cursor.execute(query, job_name).fetchone()
            if not row:
                raise DataValidationError(
                    f"SAPBI activity table has no row for job: {job_name}"
                )
            start_raw = row[2]
            if not isinstance(start_raw, datetime):
                raise DataValidationError(
                    f"Invalid LAST_RUN_DATETIME for {job_name}: {start_raw!r}"
                )
            status = normalize_activity_status(row[4])
            end_raw = None
            if status != "RU":
                end_raw = start_raw + timedelta(
                    seconds=duration_text_to_seconds(row[3])
                )
            start = _convert_time(
                start_raw,
                self.settings.server_timezone,
                self.settings.output_timezone,
                self.settings.store_naive_local_time,
            )
            end = _convert_time(
                end_raw,
                self.settings.server_timezone,
                self.settings.output_timezone,
                self.settings.store_naive_local_time,
            )
            execution_id = int(start_raw.strftime("%Y%m%d%H%M%S"))
            return SQLActivityRun(execution_id, start, end, status)
        except (DatabaseError, DataValidationError):
            raise
        except Exception as exc:
            raise DatabaseError(
                f"SAPBI activity query failed for {job_name}: {exc}"
            ) from exc
        finally:
            connection.close()


class MockSQLActivityClient:
    def __init__(self, fixture_path: str | Path):
        with Path(fixture_path).open("r", encoding="utf-8") as handle:
            self.payload = json.load(handle)

    def get_latest_run(self, job_name: str) -> SQLActivityRun:
        if job_name not in self.payload:
            raise DataValidationError(
                f"Mock SAPBI activity fixture has no entry for {job_name}"
            )
        row = self.payload[job_name]
        start = (
            datetime.fromisoformat(row["job_start_time"])
            if row.get("job_start_time")
            else None
        )
        end = (
            datetime.fromisoformat(row["job_end_time"])
            if row.get("job_end_time")
            else None
        )
        return SQLActivityRun(
            execution_id=int(row.get("execution_id", -1)),
            job_start_time=start,
            job_end_time=end,
            job_status=str(row["job_status"]),
        )
