from __future__ import annotations

from contextlib import contextmanager
from typing import Iterable, Iterator, Protocol

from .config import AutoSysSettings, DatabaseSettings
from .errors import DatabaseError
from .models import RuntimeUpdate, TargetJob


def stored_procedure_command(
    settings: DatabaseSettings, update: RuntimeUpdate
) -> tuple[str, tuple[object, ...]]:
    """Build the approved four-parameter Batch Dashboard procedure call."""
    procedure = settings.quoted_stored_procedure
    if not procedure:
        raise DatabaseError("Stored procedure is not configured")
    sql = f"""
        EXEC {procedure}
            @job_name = ?,
            @job_start_time = ?,
            @job_end_time = ?,
            @job_status = ?
    """
    parameters: tuple[object, ...] = (
        update.target.job_name,
        update.job_start_time,
        update.job_end_time,
        update.job_status,
    )
    return sql, parameters


class RuntimeRepository(Protocol):
    def load_targets(self, autosys: AutoSysSettings) -> list[TargetJob]: ...
    def apply_updates(self, updates: Iterable[RuntimeUpdate]) -> int: ...


class SQLServerRepository:
    def __init__(self, settings: DatabaseSettings):
        self.settings = settings

    @contextmanager
    def _connection(self) -> Iterator[object]:
        try:
            import pyodbc
        except ImportError as exc:
            raise DatabaseError(
                "pyodbc is required for SQL Server mode; install requirements-sqlserver.txt"
            ) from exc
        try:
            connection = pyodbc.connect(self.settings.connection_string(), autocommit=False)
            yield connection
        except Exception as exc:
            raise DatabaseError(f"SQL Server operation failed: {exc}") from exc
        finally:
            if "connection" in locals():
                connection.close()

    def load_targets(self, autosys: AutoSysSettings) -> list[TargetJob]:
        sql = f"""
            SELECT app_id, batch_stream_name, job_name
            FROM {self.settings.quoted_table}
            WHERE scheduler = ?
            ORDER BY batch_stream_name, job_sequence, job_name
        """
        with self._connection() as connection:
            cursor = connection.cursor()
            rows = cursor.execute(sql, self.settings.scheduler_value).fetchall()
        return [
            TargetJob(
                app_id=str(row[0]).strip(),
                batch_stream_name=str(row[1]).strip(),
                job_name=str(row[2]).strip(),
                instance=autosys.instance_for(str(row[0]).strip(), str(row[2]).strip()),
            )
            for row in rows
        ]

    def apply_updates(self, updates: Iterable[RuntimeUpdate]) -> int:
        values = list(updates)
        if not values:
            return 0
        with self._connection() as connection:
            cursor = connection.cursor()
            try:
                for update in values:
                    if self.settings.write_mode == "stored_procedure":
                        sql, parameters = stored_procedure_command(
                            self.settings, update
                        )
                    else:
                        audit = ""
                        parameters = [
                            update.job_start_time,
                            update.job_end_time,
                            update.job_status,
                        ]
                        if self.settings.update_audit_columns:
                            audit = ", last_updated_date = SYSDATETIME(), last_updated_by = ?"
                            parameters.append(self.settings.updated_by)
                        sql = f"""
                            UPDATE {self.settings.quoted_table}
                            SET job_start_time = ?,
                                job_end_time = ?,
                                job_status = ?
                                {audit}
                            WHERE app_id = ?
                              AND batch_stream_name = ?
                              AND job_name = ?
                        """
                        parameters.extend((
                            update.target.app_id,
                            update.target.batch_stream_name,
                            update.target.job_name,
                        ))
                    cursor.execute(sql, *parameters)
                    if self.settings.write_mode == "direct" and cursor.rowcount != 1:
                        raise DatabaseError(
                            "Expected exactly one database row for "
                            f"{update.target.app_id}/{update.target.job_name}; got {cursor.rowcount}"
                        )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        return len(values)


class MemoryRepository:
    def __init__(self, targets: list[TargetJob]):
        self.targets = targets
        self.updates: list[RuntimeUpdate] = []

    def load_targets(self, autosys: AutoSysSettings) -> list[TargetJob]:
        del autosys
        return list(self.targets)

    def apply_updates(self, updates: Iterable[RuntimeUpdate]) -> int:
        values = list(updates)
        self.updates.extend(values)
        return len(values)
