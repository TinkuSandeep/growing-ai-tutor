from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import asdict, replace
from datetime import datetime
from pathlib import Path

import yaml
from dotenv import load_dotenv

from .aews import AEWSClient, MockAEWSClient
from .config import load_settings
from .database import MemoryRepository, SQLServerRepository
from .models import PipelineResult, TargetJob
from .pipeline import IngestionPipeline


LOG = logging.getLogger("autosys_phase1")


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="AutoSys Phase 1 runtime ingestion")
    parser.add_argument("--config", default="config/settings.yaml")
    parser.add_argument("--env-file", default=".env")
    parser.add_argument("--mock", action="store_true", help="Use local targets and mock AEWS JSON")
    parser.add_argument("--mock-targets", default="config/mock_targets.yaml")
    parser.add_argument("--mock-runs", default="config/mock_job_runs.json")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--dry-run", action="store_true", help="Never update SQL Server")
    mode.add_argument("--write", action="store_true", help="Allow the configured SQL Server write")
    parser.add_argument("--log-level", default="INFO", choices=("DEBUG", "INFO", "WARNING", "ERROR"))
    return parser.parse_args()


def _mock_targets(path: str, settings) -> list[TargetJob]:
    with Path(path).open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}
    targets = []
    for item in raw.get("jobs", []):
        app_id = str(item["app_id"])
        job_name = str(item["job_name"])
        targets.append(TargetJob(
            app_id=app_id,
            batch_stream_name=str(item["batch_stream_name"]),
            job_name=job_name,
            instance=str(item.get("instance") or settings.autosys.instance_for(app_id, job_name)).upper(),
        ))
    return targets


def _json_default(value):
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(type(value).__name__)


def _write_report(result: PipelineResult, output_directory: str) -> Path:
    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / f"phase1_result_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    destination.write_text(json.dumps(asdict(result), indent=2, default=_json_default), encoding="utf-8")
    return destination


def main() -> int:
    args = _arguments()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s - %(message)s",
    )
    load_dotenv(args.env_file, override=False)
    settings = load_settings(args.config)

    if args.mock:
        targets = _mock_targets(args.mock_targets, settings)
        settings = replace(
            settings,
            ingestion=replace(settings.ingestion, require_exact_target_count=len(targets)),
        )
        repository = MemoryRepository(targets)
        source = MockAEWSClient(args.mock_runs)
        effective_dry_run = not args.write
    else:
        repository = SQLServerRepository(settings.database)
        source = AEWSClient(settings.autosys)
        targets = None
        effective_dry_run = True if args.dry_run else (False if args.write else settings.ingestion.dry_run)

    pipeline = IngestionPipeline(settings, source, repository)
    result = pipeline.run(targets=targets, dry_run=effective_dry_run)
    report = _write_report(result, settings.ingestion.output_directory)

    LOG.info(
        "Phase 1 completed: requested=%d extracted=%d updated=%d failures=%d dry_run=%s report=%s",
        result.requested,
        result.extracted,
        result.updated,
        len(result.failures),
        result.dry_run,
        report,
    )
    for failure in result.failures:
        LOG.error("Job failed: %s/%s - %s", failure.target.app_id, failure.target.job_name, failure.reason)
    return 0 if not result.failures else 2


if __name__ == "__main__":
    sys.exit(main())
