from __future__ import annotations

import argparse
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

from .aews import AEWSClient, MockAEWSClient
from .config import load_settings
from .database import SQLServerRepository
from .models import TargetJob
from .models import RuntimeUpdate
from .source_config import SourceJob, load_source_check_settings
from .sql_activity import MockSQLActivityClient, SQLActivityClient
from .transform import latest_runtime_update


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read-only ODIN AEWS and SAPBI activity source validation"
    )
    parser.add_argument("--config", default="config/source_jobs.yaml")
    parser.add_argument("--settings", default="config/settings.yaml")
    parser.add_argument("--env-file", default=".env")
    parser.add_argument(
        "--source",
        choices=("all", "aews", "sql_activity"),
        default="all",
        help="Limit validation to one source type",
    )
    parser.add_argument("--mock-aews", help="AEWS JSON fixture for offline testing")
    parser.add_argument(
        "--mock-sql-activity", help="SAPBI activity JSON fixture for offline testing"
    )
    parser.add_argument(
        "--write",
        action="store_true",
        help="Call the configured target stored procedure after all sources pass",
    )
    return parser.parse_args()


def _json_default(value: Any):
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(type(value).__name__)


def _configure_logging(log_path: Path) -> logging.Logger:
    logger = logging.getLogger("source_check")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger


def _base_result(job: SourceJob) -> dict[str, Any]:
    return {
        "app_id": job.app_id,
        "batch_stream_name": job.batch_stream_name,
        "job_name": job.job_name,
        "source": job.source,
        "instance": job.instance,
    }


def main() -> int:
    args = _arguments()
    load_dotenv(args.env_file, override=False)
    app_settings = load_settings(args.settings)
    source_settings = load_source_check_settings(args.config)
    selected = [
        job
        for job in source_settings.jobs
        if args.source == "all" or job.source == args.source
    ]
    if args.write and args.source != "all":
        raise SystemExit("--write requires --source all to prevent partial updates")
    if args.write and (args.mock_aews or args.mock_sql_activity):
        raise SystemExit("--write cannot be combined with mock source data")
    if args.write and app_settings.database.write_mode != "stored_procedure":
        raise SystemExit("--write requires database.write_mode=stored_procedure")

    output_dir = Path(source_settings.output_directory)
    log_dir = Path(source_settings.log_directory)
    output_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    now = datetime.now(ZoneInfo(source_settings.sql_activity.output_timezone))
    # Microseconds prevent back-to-back ODIN and SAPBI checks from overwriting
    # one another when they start within the same second.
    stamp = now.strftime("%Y%m%d_%H%M%S_%f")
    report_path = output_dir / f"source_validation_{stamp}.json"
    log_path = log_dir / f"source_validation_{stamp}.log"
    logger = _configure_logging(log_path)

    aews = None
    aews_setup_error: Exception | None = None
    if any(job.source == "aews" for job in selected):
        try:
            aews = MockAEWSClient(args.mock_aews) if args.mock_aews else AEWSClient(app_settings.autosys)
        except Exception as exc:
            aews_setup_error = exc
    sql_activity = None
    sql_activity_setup_error: Exception | None = None
    if any(job.source == "sql_activity" for job in selected):
        try:
            sql_activity = (
                MockSQLActivityClient(args.mock_sql_activity)
                if args.mock_sql_activity
                else SQLActivityClient(source_settings.sql_activity)
            )
        except Exception as exc:
            sql_activity_setup_error = exc

    logger.info(
        "Starting %s for %d jobs",
        "source collection and target write" if args.write else "read-only source validation",
        len(selected),
    )
    results: list[dict[str, Any]] = []
    updates: list[RuntimeUpdate] = []
    failed = 0
    for job in selected:
        result = _base_result(job)
        try:
            if job.source == "aews":
                if aews_setup_error:
                    raise aews_setup_error
                target = TargetJob(
                    app_id=job.app_id,
                    batch_stream_name=job.batch_stream_name,
                    job_name=job.job_name,
                    instance=job.instance or app_settings.autosys.default_instance,
                )
                payload = aews.get_job_runs(target)
                update = latest_runtime_update(
                    target,
                    payload,
                    app_settings.autosys.timezone,
                    app_settings.autosys.store_naive_local_time,
                )
                result.update(
                    {
                        "execution_id": update.run_number,
                        "job_start_time_et": update.job_start_time,
                        "job_end_time_et": update.job_end_time,
                        "job_status": update.job_status,
                    }
                )
                updates.append(
                    RuntimeUpdate(
                        target=target,
                        run_number=update.run_number,
                        job_start_time=update.job_start_time,
                        job_end_time=update.job_end_time,
                        job_status=update.job_status,
                    )
                )
            else:
                if sql_activity_setup_error:
                    raise sql_activity_setup_error
                run = sql_activity.get_latest_run(job.job_name)
                result.update(
                    {
                        "execution_id": run.execution_id,
                        "job_start_time_et": run.job_start_time,
                        "job_end_time_et": run.job_end_time,
                        "job_status": run.job_status,
                    }
                )
                updates.append(
                    RuntimeUpdate(
                        target=TargetJob(
                            app_id=job.app_id,
                            batch_stream_name=job.batch_stream_name,
                            job_name=job.job_name,
                            instance=job.instance or "SAPBI",
                        ),
                        run_number=run.execution_id,
                        job_start_time=run.job_start_time,
                        job_end_time=run.job_end_time,
                        job_status=run.job_status,
                    )
                )
            result["result"] = "PASSED"
            logger.info("PASSED source=%s job=%s status=%s", job.source, job.job_name, result["job_status"])
        except Exception as exc:  # preserve the other source results
            failed += 1
            result.update({"result": "FAILED", "error": str(exc)})
            logger.error("FAILED source=%s job=%s error=%s", job.source, job.job_name, exc)
        results.append(result)

    updated = 0
    database_connected = False
    write_error: str | None = None
    if args.write and failed == 0:
        duplicate_names = sorted(
            name for name in {item.target.job_name.casefold() for item in updates}
            if sum(
                update.target.job_name.casefold() == name for update in updates
            ) > 1
        )
        if duplicate_names:
            write_error = (
                "Target procedure identifies rows only by job_name; duplicate "
                f"configured names cannot be written: {duplicate_names}"
            )
        else:
            try:
                updated = SQLServerRepository(app_settings.database).apply_updates(updates)
                database_connected = True
                logger.info(
                    "Committed %d target updates through %s",
                    updated,
                    app_settings.database.stored_procedure,
                )
            except Exception as exc:
                write_error = str(exc)
        if write_error:
            logger.error("TARGET WRITE FAILED error=%s", write_error)

    completed = datetime.now(ZoneInfo(source_settings.sql_activity.output_timezone))
    if failed or write_error:
        overall_result = "INGESTION_FAILED" if args.write else "SOURCE_TEST_FAILED"
    else:
        overall_result = "INGESTION_PASSED" if args.write else "SOURCE_TEST_PASSED"
    report = {
        "result": overall_result,
        "started_at_et": now,
        "completed_at_et": completed,
        "requested": len(selected),
        "succeeded": len(selected) - failed,
        "failed": failed,
        "target_database_connected": database_connected,
        "target_database_updated": updated > 0,
        "target_rows_updated": updated,
        "target_write_error": write_error,
        "jobs": results,
    }
    report_path.write_text(
        json.dumps(report, indent=2, default=_json_default),
        encoding="utf-8",
    )
    logger.info("Report written to %s", report_path)
    logger.info("Log written to %s", log_path)
    print(json.dumps({
        "result": report["result"],
        "requested": report["requested"],
        "succeeded": report["succeeded"],
        "failed": report["failed"],
        "target_database_updated": report["target_database_updated"],
        "target_rows_updated": report["target_rows_updated"],
        "target_write_error": report["target_write_error"],
        "report": str(report_path),
        "log": str(log_path),
    }, indent=2))
    return 0 if failed == 0 and write_error is None else 1


if __name__ == "__main__":
    raise SystemExit(main())
