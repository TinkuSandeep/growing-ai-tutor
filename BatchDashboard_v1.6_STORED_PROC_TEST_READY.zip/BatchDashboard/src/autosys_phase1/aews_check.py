from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from datetime import datetime

from dotenv import load_dotenv

from .aews import AEWSClient, MockAEWSClient
from .config import load_settings
from .models import TargetJob
from .transform import latest_runtime_update


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Test one AEWS job without connecting to SQL Server"
    )
    parser.add_argument("--instance", required=True, help="AutoSys instance, for example PB3")
    parser.add_argument("--job", required=True, help="Exact AutoSys job name")
    parser.add_argument("--app-id", default="AEWS_TEST")
    parser.add_argument("--config", default="config/settings.yaml")
    parser.add_argument("--env-file", default=".env")
    parser.add_argument(
        "--mock-fixture",
        help="Optional local JSON fixture; when supplied, no network call is made",
    )
    return parser.parse_args()


def _json_default(value):
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(type(value).__name__)


def main() -> int:
    args = _arguments()
    load_dotenv(args.env_file, override=False)
    settings = load_settings(args.config)
    target = TargetJob(
        app_id=args.app_id,
        batch_stream_name="AEWS connectivity test",
        job_name=args.job,
        instance=args.instance.upper(),
    )
    source = (
        MockAEWSClient(args.mock_fixture)
        if args.mock_fixture
        else AEWSClient(settings.autosys)
    )
    payload = source.get_job_runs(target)
    update = latest_runtime_update(
        target,
        payload,
        settings.autosys.timezone,
        settings.autosys.store_naive_local_time,
    )
    result = {
        "result": "AEWS_TEST_PASSED",
        "instance": update.target.instance,
        "job_name": update.target.job_name,
        "run_number": update.run_number,
        "job_start_time_et": update.job_start_time,
        "job_end_time_et": update.job_end_time,
        "job_status": update.job_status,
        "database_connected": False,
        "database_updated": False,
    }
    print(json.dumps(result, indent=2, default=_json_default))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

