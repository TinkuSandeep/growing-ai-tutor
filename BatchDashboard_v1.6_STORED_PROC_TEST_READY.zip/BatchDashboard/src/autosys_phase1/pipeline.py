from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Iterable

from .aews import RuntimeSource
from .config import Settings
from .database import RuntimeRepository
from .models import JobFailure, PipelineResult, RuntimeUpdate, TargetJob
from .transform import latest_runtime_update


class IngestionPipeline:
    def __init__(
        self,
        settings: Settings,
        source: RuntimeSource,
        repository: RuntimeRepository,
    ):
        self.settings = settings
        self.source = source
        self.repository = repository

    def _extract(self, target: TargetJob) -> RuntimeUpdate:
        payload = self.source.get_job_runs(target)
        return latest_runtime_update(
            target,
            payload,
            self.settings.autosys.timezone,
            self.settings.autosys.store_naive_local_time,
        )

    def run(self, targets: Iterable[TargetJob] | None = None, dry_run: bool | None = None) -> PipelineResult:
        selected = list(targets if targets is not None else self.repository.load_targets(self.settings.autosys))
        expected = self.settings.ingestion.require_exact_target_count
        if expected is not None and len(selected) != expected:
            failure = JobFailure(
                target=TargetJob("SYSTEM", "SYSTEM", "TARGET_COUNT", self.settings.autosys.default_instance),
                reason=f"Expected {expected} target jobs but loaded {len(selected)}",
            )
            return PipelineResult(len(selected), 0, 0, (failure,), True)

        updates: list[RuntimeUpdate] = []
        failures: list[JobFailure] = []
        with ThreadPoolExecutor(max_workers=self.settings.autosys.workers) as executor:
            future_targets = {executor.submit(self._extract, target): target for target in selected}
            for future in as_completed(future_targets):
                target = future_targets[future]
                try:
                    updates.append(future.result())
                except Exception as exc:  # failures are reported without exposing credentials
                    failures.append(JobFailure(target=target, reason=str(exc)))

        updates.sort(key=lambda item: (item.target.batch_stream_name, item.target.job_name))
        failures.sort(key=lambda item: (item.target.batch_stream_name, item.target.job_name))
        effective_dry_run = self.settings.ingestion.dry_run if dry_run is None else dry_run
        updated = 0
        if not effective_dry_run and not (failures and self.settings.ingestion.abort_on_job_error):
            updated = self.repository.apply_updates(updates)

        return PipelineResult(
            requested=len(selected),
            extracted=len(updates),
            updated=updated,
            failures=tuple(failures),
            dry_run=effective_dry_run or bool(failures and self.settings.ingestion.abort_on_job_error),
        )
