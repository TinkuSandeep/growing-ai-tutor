from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class TargetJob:
    app_id: str
    batch_stream_name: str
    job_name: str
    instance: str


@dataclass(frozen=True)
class RuntimeUpdate:
    target: TargetJob
    run_number: int
    job_start_time: datetime | None
    job_end_time: datetime | None
    job_status: str


@dataclass(frozen=True)
class JobFailure:
    target: TargetJob
    reason: str


@dataclass(frozen=True)
class PipelineResult:
    requested: int
    extracted: int
    updated: int
    failures: tuple[JobFailure, ...]
    dry_run: bool

