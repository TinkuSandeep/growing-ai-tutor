@echo off
setlocal
cd /d "%~dp0.."

if "%~1"=="" (
  echo Usage: scripts\test_aews_only.bat INSTANCE EXACT_JOB_NAME
  echo Example: scripts\test_aews_only.bat PB3 MY_AUTOSYS_JOB
  exit /b 2
)

if "%~2"=="" (
  echo ERROR: Exact AutoSys job name is required.
  exit /b 2
)

set "PYTHONPATH=%CD%\src"
python -m autosys_phase1.aews_check --instance "%~1" --job "%~2"
exit /b %errorlevel%

