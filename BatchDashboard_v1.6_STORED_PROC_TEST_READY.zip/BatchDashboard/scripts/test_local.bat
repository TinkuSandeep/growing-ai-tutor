@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%\src"
python -m pytest
if errorlevel 1 exit /b %errorlevel%
python -m autosys_phase1 --mock --dry-run
exit /b %errorlevel%

