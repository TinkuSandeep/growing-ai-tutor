@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%\src"
set "PYTHON_EXE=%CD%\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"
"%PYTHON_EXE%" -m autosys_phase1.source_check ^
  --source all ^
  --mock-aews config\mock_job_runs_v13.json ^
  --mock-sql-activity config\mock_sql_agent_runs.json
exit /b %errorlevel%
