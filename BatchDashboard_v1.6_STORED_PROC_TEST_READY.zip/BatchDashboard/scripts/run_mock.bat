@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%\src"
python -m autosys_phase1 --mock --dry-run
exit /b %errorlevel%

