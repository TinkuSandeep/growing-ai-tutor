@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%\src"
python -m autosys_phase1.aews_check ^
  --instance PB3 ^
  --job ODIN_OCP_PROD_LENEL_EVENTS_INGESTION_LOAD ^
  --mock-fixture config\mock_job_runs.json
exit /b %errorlevel%

