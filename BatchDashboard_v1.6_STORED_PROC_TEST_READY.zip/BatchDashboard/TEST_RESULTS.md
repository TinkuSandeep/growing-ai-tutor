# Verification Results

## v1.6 approved stored-procedure write

- Approved procedure: `dbo.cp_UpdateJobExecutionStatus`.
- Exact parameters: job name, start time, end time, and status.
- Automated tests: `29 passed`.
- Verified null end-time handling for running jobs.
- Verified two successful calls commit together.
- Verified a later procedure failure rolls back the complete transaction.
- Verified combined offline collection: `7 requested, 7 succeeded, 0 failed`.
- No production target write was performed during packaging.

## v1.5 CPG_Mart SAPBI source

- SAPBI collector reads `dbo.DATA_MGMNT_JOBS_ACTVTY` in `CPG_Mart`.
- No `msdb` access is required.
- `LAST_RUN_DATETIME` is treated as start time.
- `LAST_RUN_DURATION` (`HH:MM:SS`) is added to calculate end time.
- Text status values are normalized to two-character dashboard values.
- Exact configured job names were confirmed from the latest-row query.
- Automated tests: `25 passed`.
- Offline combined validation: `7 requested, 7 succeeded, 0 failed`.
- Production SAPBI connectivity remains to be tested in the approved runtime.

## Previous v1.4 SAPBI least-privilege patch

- Automated tests: `18 passed`.
- Offline end-to-end validation: `7 requested, 7 succeeded, 0 failed`.
- SQL Agent collector uses `sp_help_job` and `sp_help_jobhistory`.
- No direct `SELECT` against `msdb` SQL Agent system tables.
- Same AEWS job name may be configured in different AutoSys instances.

Verification date: 2026-09-21

## v1.3 multi-source validation

- Automated tests: `14 passed`.
- Offline end-to-end source validation: `7 requested, 7 succeeded, 0 failed`.
- Validated three PB3 AEWS jobs through bundled AEWS fixtures.
- Validated four SAPBI SQL Agent jobs through bundled SQL Agent fixtures.
- Confirmed timestamped JSON output and log creation.
- Confirmed the source-validation report records target database connection and
  update values as `false`.

Production endpoints and SAPBI SQL Server connectivity must be validated in the
approved runtime environment.

## Automated tests

```text
.........                                                                [100%]
9 passed in 0.11s
```

Coverage includes:

- latest `runNum` selection;
- UTC-offset timestamp conversion to America/New_York;
- success and running status normalization;
- forced NULL end time for active runs;
- rejection of unknown statuses;
- rejection of incomplete terminal runs;
- dry-run write prevention;
- transactional-cycle abort after an extraction failure;
- SQL object-name safety validation.

## End-to-end mock dry run

```text
requested=3 extracted=3 updated=0 failures=0 dry_run=True
```

## AEWS-only checker

The dedicated one-job checker was executed with the local AEWS fixture. It
returned the latest run number, converted ET timestamps, and `SU` status while
reporting `database_connected=false` and `database_updated=false`.

## End-to-end mock write path

The write path was executed against the in-memory repository only:

```text
requested=3 extracted=3 updated=3 failures=0 dry_run=False
```

No Wells Fargo endpoint, credential, or database was used during verification.
Real AEWS and SQL Server validation must follow the controlled rollout in
`README.md`.
