USE [TCOO_TOOLS];
GO

SELECT
    app_id,
    batch_stream_name,
    job_name,
    job_start_time,
    job_end_time,
    job_status,
    last_updated_date,
    last_updated_by
FROM dbo.cp_critical_batch_jobs
WHERE scheduler = 'AUTOSYS'
ORDER BY last_updated_date DESC, batch_stream_name, job_sequence;
GO

SELECT job_status, COUNT(*) AS job_count
FROM dbo.cp_critical_batch_jobs
WHERE scheduler = 'AUTOSYS'
GROUP BY job_status
ORDER BY job_status;
GO

SELECT app_id, batch_stream_name, job_name, job_status, job_start_time, job_end_time
FROM dbo.cp_critical_batch_jobs
WHERE scheduler = 'AUTOSYS'
  AND (
       job_status IS NULL
       OR (job_status = 'RU' AND job_start_time IS NULL)
       OR (job_status IN ('SU', 'FA', 'TE') AND (job_start_time IS NULL OR job_end_time IS NULL))
      );
GO

