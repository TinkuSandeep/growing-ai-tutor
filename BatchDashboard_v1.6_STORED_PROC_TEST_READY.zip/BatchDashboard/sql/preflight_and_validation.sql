/* Read-only preflight checks. This script creates or changes nothing. */

USE [TCOO_TOOLS];
GO

EXEC sys.sp_help N'dbo.cp_critical_batch_jobs';
GO

SELECT
    app_id,
    batch_stream_name,
    job_name,
    scheduler,
    job_start_time,
    job_end_time,
    job_status,
    last_updated_date,
    last_updated_by
FROM dbo.cp_critical_batch_jobs
WHERE scheduler = 'AUTOSYS'
ORDER BY batch_stream_name, job_sequence, job_name;
GO

SELECT
    COUNT(*) AS autosys_target_count,
    SUM(CASE WHEN job_name IS NULL OR LTRIM(RTRIM(job_name)) = '' THEN 1 ELSE 0 END) AS missing_job_names
FROM dbo.cp_critical_batch_jobs
WHERE scheduler = 'AUTOSYS';
GO

SELECT
    SCHEMA_NAME(p.schema_id) AS schema_name,
    p.name AS procedure_name
FROM sys.procedures AS p
JOIN sys.sql_modules AS m ON p.object_id = m.object_id
WHERE m.definition LIKE '%cp_critical_batch_jobs%'
   OR m.definition LIKE '%job_start_time%'
   OR m.definition LIKE '%job_end_time%'
   OR m.definition LIKE '%job_status%'
ORDER BY p.name;
GO

