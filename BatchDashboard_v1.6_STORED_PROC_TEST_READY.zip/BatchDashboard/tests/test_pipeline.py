from dataclasses import replace

from autosys_phase1.aews import MockAEWSClient
from autosys_phase1.config import load_settings
from autosys_phase1.database import MemoryRepository
from autosys_phase1.models import TargetJob
from autosys_phase1.pipeline import IngestionPipeline


def _settings():
    settings = load_settings("config/settings.yaml")
    return replace(
        settings,
        ingestion=replace(settings.ingestion, require_exact_target_count=None),
    )


def test_pipeline_dry_run_does_not_write():
    targets = [TargetJob(
        "ODIN",
        "RTO In-Office Reporting",
        "ODIN_OCP_PROD_LENEL_EVENTS_INGESTION_LOAD",
        "PB3",
    )]
    repository = MemoryRepository(targets)
    result = IngestionPipeline(
        _settings(), MockAEWSClient("config/mock_job_runs.json"), repository
    ).run(dry_run=True)
    assert result.extracted == 1
    assert result.updated == 0
    assert repository.updates == []


def test_pipeline_write_updates_memory_repository():
    targets = [TargetJob(
        "SAPBI",
        "RTO In-Office Reporting",
        "CPG_DAILY_STATUS_ON_RTO",
        "PB3",
    )]
    repository = MemoryRepository(targets)
    result = IngestionPipeline(
        _settings(), MockAEWSClient("config/mock_job_runs.json"), repository
    ).run(dry_run=False)
    assert result.failures == ()
    assert result.updated == 1
    assert repository.updates[0].job_status == "RU"


def test_pipeline_aborts_write_when_one_job_fails():
    targets = [
        TargetJob("SAPBI", "RTO", "CPG_DAILY_STATUS_ON_RTO", "PB3"),
        TargetJob("ODIN", "RTO", "NOT_IN_FIXTURE", "PB3"),
    ]
    repository = MemoryRepository(targets)
    result = IngestionPipeline(
        _settings(), MockAEWSClient("config/mock_job_runs.json"), repository
    ).run(dry_run=False)
    assert len(result.failures) == 1
    assert result.updated == 0
    assert result.dry_run is True
    assert repository.updates == []

