import pytest

from autosys_phase1.config import ConfigurationError, quote_sql_object_name


def test_quotes_three_part_table_name():
    assert quote_sql_object_name("TCOO_TOOLS.dbo.cp_critical_batch_jobs") == (
        "[TCOO_TOOLS].[dbo].[cp_critical_batch_jobs]"
    )


def test_rejects_unsafe_table_name():
    with pytest.raises(ConfigurationError):
        quote_sql_object_name("dbo.jobs; DROP TABLE dbo.jobs")

