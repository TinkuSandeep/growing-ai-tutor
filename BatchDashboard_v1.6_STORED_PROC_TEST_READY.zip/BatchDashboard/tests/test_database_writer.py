from datetime import datetime
import sys
import types

import pytest

from autosys_phase1.config import load_settings
from autosys_phase1.database import SQLServerRepository, stored_procedure_command
from autosys_phase1.errors import DatabaseError
from autosys_phase1.models import RuntimeUpdate, TargetJob


def test_approved_stored_procedure_uses_exactly_four_parameters():
    settings = load_settings("config/settings.yaml").database
    update = RuntimeUpdate(
        target=TargetJob("SAPBI", "WF In-Office Reporting", "JOB_ONE", "SAPBI"),
        run_number=1,
        job_start_time=datetime(2026, 9, 22, 7, 0),
        job_end_time=datetime(2026, 9, 22, 7, 12, 51),
        job_status="SU",
    )

    sql, parameters = stored_procedure_command(settings, update)

    assert "[dbo].[cp_UpdateJobExecutionStatus]" in sql
    assert "@job_name = ?" in sql
    assert "@job_start_time = ?" in sql
    assert "@job_end_time = ?" in sql
    assert "@job_status = ?" in sql
    assert parameters == (
        "JOB_ONE",
        datetime(2026, 9, 22, 7, 0),
        datetime(2026, 9, 22, 7, 12, 51),
        "SU",
    )


def test_running_job_passes_null_end_time():
    settings = load_settings("config/settings.yaml").database
    update = RuntimeUpdate(
        target=TargetJob("ODIN", "WF In-Office Reporting", "RUNNING_JOB", "PB3"),
        run_number=2,
        job_start_time=datetime(2026, 9, 22, 8, 0),
        job_end_time=None,
        job_status="RU",
    )

    _, parameters = stored_procedure_command(settings, update)

    assert parameters[2] is None
    assert parameters[3] == "RU"


class _FakeCursor:
    def __init__(self, fail_on_call=None):
        self.calls = []
        self.fail_on_call = fail_on_call

    def execute(self, sql, *parameters):
        self.calls.append((sql, parameters))
        if self.fail_on_call == len(self.calls):
            raise RuntimeError("simulated procedure failure")


class _FakeConnection:
    def __init__(self, fail_on_call=None):
        self._cursor = _FakeCursor(fail_on_call)
        self.committed = False
        self.rolled_back = False
        self.closed = False

    def cursor(self):
        return self._cursor

    def commit(self):
        self.committed = True

    def rollback(self):
        self.rolled_back = True

    def close(self):
        self.closed = True


def _updates():
    return [
        RuntimeUpdate(
            target=TargetJob("APP", "Stream", f"JOB_{number}", "PB3"),
            run_number=number,
            job_start_time=datetime(2026, 9, 22, 8, number),
            job_end_time=datetime(2026, 9, 22, 8, number + 1),
            job_status="SU",
        )
        for number in (1, 2)
    ]


def test_stored_procedure_updates_commit_as_one_transaction(monkeypatch):
    connection = _FakeConnection()
    monkeypatch.setenv("SQLSERVER_CONNECTION_STRING", "test-connection")
    monkeypatch.setitem(
        sys.modules,
        "pyodbc",
        types.SimpleNamespace(connect=lambda *args, **kwargs: connection),
    )

    count = SQLServerRepository(
        load_settings("config/settings.yaml").database
    ).apply_updates(_updates())

    assert count == 2
    assert len(connection._cursor.calls) == 2
    assert connection.committed is True
    assert connection.rolled_back is False
    assert connection.closed is True


def test_stored_procedure_failure_rolls_back_all_updates(monkeypatch):
    connection = _FakeConnection(fail_on_call=2)
    monkeypatch.setenv("SQLSERVER_CONNECTION_STRING", "test-connection")
    monkeypatch.setitem(
        sys.modules,
        "pyodbc",
        types.SimpleNamespace(connect=lambda *args, **kwargs: connection),
    )

    with pytest.raises(DatabaseError):
        SQLServerRepository(
            load_settings("config/settings.yaml").database
        ).apply_updates(_updates())

    assert connection.committed is False
    assert connection.rolled_back is True
    assert connection.closed is True
