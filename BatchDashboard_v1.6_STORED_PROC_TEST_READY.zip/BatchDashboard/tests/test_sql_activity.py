import pytest

from autosys_phase1.errors import DataValidationError
from autosys_phase1.sql_activity import (
    _quoted_table,
    duration_text_to_seconds,
    normalize_activity_status,
)


def test_duration_text_to_seconds():
    assert duration_text_to_seconds("00:12:51") == 771
    assert duration_text_to_seconds("25:01:02") == 90062


@pytest.mark.parametrize("value", ["12:70:00", "001251", "", None])
def test_invalid_duration_text(value):
    with pytest.raises(DataValidationError):
        duration_text_to_seconds(value)


@pytest.mark.parametrize(
    ("source", "expected"),
    [
        ("Succeeded", "SU"),
        ("Failed", "FA"),
        ("Running", "RU"),
        ("Executing", "RU"),
        ("Cancelled", "CA"),
        ("Retry", "RE"),
    ],
)
def test_activity_status_mapping(source, expected):
    assert normalize_activity_status(source) == expected


def test_unknown_activity_status():
    with pytest.raises(DataValidationError):
        normalize_activity_status("Unexpected")


def test_table_identifier_is_quoted():
    assert _quoted_table("dbo.DATA_MGMNT_JOBS_ACTVTY") == (
        "[dbo].[DATA_MGMNT_JOBS_ACTVTY]"
    )
    assert _quoted_table("CPG_Mart.dbo.DATA_MGMNT_JOBS_ACTVTY") == (
        "[CPG_Mart].[dbo].[DATA_MGMNT_JOBS_ACTVTY]"
    )


def test_unsafe_table_identifier_is_rejected():
    with pytest.raises(DataValidationError):
        _quoted_table("dbo.DATA_MGMNT_JOBS_ACTVTY; DROP TABLE x")
