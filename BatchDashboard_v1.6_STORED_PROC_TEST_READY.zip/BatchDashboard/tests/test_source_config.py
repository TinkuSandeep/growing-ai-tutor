from pathlib import Path

from autosys_phase1.source_config import load_source_check_settings


def test_source_configuration_loads():
    config = Path(__file__).parents[1] / "config" / "source_jobs.yaml"
    settings = load_source_check_settings(config)
    assert len(settings.jobs) == 7
    assert sum(job.source == "aews" for job in settings.jobs) == 3
    assert sum(job.source == "sql_activity" for job in settings.jobs) == 4
    assert settings.sql_activity.connection_string_env == "SAPBI_SQL_CONNECTION_STRING"
    assert settings.sql_activity.table == "dbo.DATA_MGMNT_JOBS_ACTVTY"


def test_same_aews_job_name_is_allowed_in_different_instances(tmp_path):
    config = tmp_path / "sources.yaml"
    config.write_text(
        """
jobs:
  - app_id: APP
    batch_stream_name: Stream
    job_name: SHARED_JOB
    source: aews
    instance: PB3
  - app_id: APP
    batch_stream_name: Stream
    job_name: SHARED_JOB
    source: aews
    instance: PC3
""",
        encoding="utf-8",
    )
    settings = load_source_check_settings(config)
    assert [job.instance for job in settings.jobs] == ["PB3", "PC3"]
