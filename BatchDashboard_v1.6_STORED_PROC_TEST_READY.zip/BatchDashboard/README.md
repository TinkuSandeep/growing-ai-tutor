# BatchDashboard Phase 1

This application collects runtime information for the configured critical jobs
and updates the existing Batch Dashboard through the approved stored procedure.

Current production sources:

- ODIN: AutoSys AEWS REST API, with an instance configured per job.
- SAPBI: `CPG_Mart.dbo.DATA_MGMNT_JOBS_ACTVTY`.

Target write:

- `dbo.cp_UpdateJobExecutionStatus`
- `job_name`
- `job_start_time`
- `job_end_time`
- `job_status`

The job list and AutoSys instances are defined in `config/source_jobs.yaml`.
Connection strings and service credentials are read from `.env`; they are not
hard-coded.

## Quick start on Windows

```bat
python -m venv venv
set PIP_USER=false
venv\Scripts\python.exe -m pip install --no-user -r requirements-sqlserver.txt
copy .env.example .env
```

Populate `.env` locally, then run these commands in order:

```bat
scripts\test_all_sources_mock.bat
scripts\run_prod_dry_run.bat
scripts\run_prod_write.bat
```

Run the write command only after the dry-run JSON output is reviewed and the
execution identity has `EXECUTE` permission on the target procedure.

## Safety controls

- Dry run is the default.
- A target write requires the explicit `--write` option.
- Partial-source writes and mock-data writes are blocked.
- Any source failure prevents all target updates.
- All stored-procedure calls commit in one transaction.
- Any target procedure failure rolls back the entire cycle.
- SQL values are parameterized.
- Unknown source statuses fail validation.
- Running jobs send a null end time.

## Output

Every run produces:

- `output/source_validation_<timestamp>.json`
- `logs/source_validation_<timestamp>.log`

The detailed report records whether the target database was connected and how
many rows were submitted successfully.

## AutoSys schedule

After controlled production validation, use
`autosys_phase1_ingestion.jil.example` as the reviewed five-minute schedule
template. The example keeps the complete deployment under `D:\BatchDashboard`.

See `README_V1.6_STORED_PROCEDURE.md` for the complete configuration and test
sequence.
