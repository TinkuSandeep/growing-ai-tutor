# BatchDashboard Phase 1 v1.6

Version 1.6 completes the Phase 1 collection-and-write path.

## Data flow

1. Collect ODIN runtime values from read-only AutoSys AEWS GET calls.
2. Collect SAPBI runtime values from `CPG_Mart.dbo.DATA_MGMNT_JOBS_ACTVTY`.
3. Validate and normalize all configured jobs.
4. When `--write` is explicitly supplied, call the approved procedure once
   for every job inside one SQL transaction.

## Approved target procedure

```sql
EXEC dbo.cp_UpdateJobExecutionStatus
    @job_name = ?,
    @job_start_time = ?,
    @job_end_time = ?,
    @job_status = ?;
```

Only these four parameters are sent. Values are parameterized; they are not
concatenated into SQL.

| Procedure parameter | Source value |
|---|---|
| `@job_name` | exact name from `config/source_jobs.yaml` |
| `@job_start_time` | AEWS start or SAPBI `LAST_RUN_DATETIME` |
| `@job_end_time` | AEWS end or calculated SAPBI end |
| `@job_status` | normalized two-character status |

Python `None` is sent as SQL `NULL`. Running jobs therefore send a null end
time. If a source supplies a not-started job without start/end timestamps,
those values are passed as null.

## Environment

Copy `.env.example` to `.env` and populate the three local connection areas:

```text
AUTOSYS_API_USER=
AUTOSYS_API_PASSWORD=
SAPBI_SQL_CONNECTION_STRING=...;DATABASE=CPG_Mart;...
SQLSERVER_CONNECTION_STRING=...;DATABASE=TCOO_TOOLS;...
```

Never commit `.env`.

The execution identity needs:

- read access to `CPG_Mart.dbo.DATA_MGMNT_JOBS_ACTVTY`;
- `EXECUTE` permission on `dbo.cp_UpdateJobExecutionStatus` in the target DB;
- read-only AEWS access to every configured AutoSys instance.

## Safe test order

### 1. Offline test

```bat
scripts\test_all_sources_mock.bat
```

### 2. Production sources without target writes

```bat
scripts\run_prod_dry_run.bat
```

Expected summary:

```json
{
  "result": "SOURCE_TEST_PASSED",
  "requested": 7,
  "succeeded": 7,
  "failed": 0
}
```

### 3. Approved target write

After reviewing the JSON source report:

```bat
scripts\run_prod_write.bat
```

Expected summary result: `INGESTION_PASSED`. The detailed JSON report records
`target_database_connected`, `target_database_updated`, and
`target_rows_updated`.

## Write protections

- No target connection occurs unless `--write` is supplied.
- `--write` requires `--source all`; partial-source writes are blocked.
- Mock source values cannot be written.
- Any source failure prevents all target writes.
- Duplicate job names are blocked because the procedure identifies a row only
  by `job_name`.
- Every procedure call belongs to one transaction.
- Any procedure failure rolls back the whole transaction.
- Credentials and connection strings remain outside Python and YAML.

## Five-minute AutoSys scheduling

Schedule this command after production validation:

```bat
scripts\run_prod_write.bat
```

Configure the controlling AutoSys job to run every five minutes. Do not place
connection strings or service credentials directly in JIL.
