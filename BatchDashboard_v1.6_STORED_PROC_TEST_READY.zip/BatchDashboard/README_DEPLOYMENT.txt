BatchDashboard Phase 1 v1.6
===========================

This version collects the configured AutoSys and SAPBI job values and writes
them through dbo.cp_UpdateJobExecutionStatus only when explicitly requested.

Setup
-----
1. Open Command Prompt in the BatchDashboard folder.
2. Run: python -m venv venv
3. Run: set PIP_USER=false
4. Run: venv\Scripts\python.exe -m pip install --no-user -r requirements-sqlserver.txt
5. Copy .env.example to .env.
6. Populate the AutoSys, CPG_Mart, and target DB values locally.

Safe test order
---------------
1. scripts\test_all_sources_mock.bat
2. scripts\run_prod_dry_run.bat
3. Review the JSON report under output.
4. After approval, run scripts\run_prod_write.bat

Target write
------------
The write script executes:

  dbo.cp_UpdateJobExecutionStatus

with only:

  job_name, job_start_time, job_end_time, job_status

All configured jobs are committed in one transaction. Any failure rolls back
the entire write cycle.

Full instructions: README_V1.6_STORED_PROCEDURE.md
