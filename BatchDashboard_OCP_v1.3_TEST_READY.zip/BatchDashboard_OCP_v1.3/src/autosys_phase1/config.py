from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .errors import ConfigurationError


_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise ConfigurationError(f"Required environment variable is not set: {name}")
    return value


def quote_sql_object_name(value: str) -> str:
    """Safely quote a two- or three-part SQL Server object name."""
    parts = value.split(".")
    if len(parts) not in (2, 3) or any(not _IDENTIFIER.fullmatch(part) for part in parts):
        raise ConfigurationError(f"Unsafe SQL Server object name: {value!r}")
    return ".".join(f"[{part}]" for part in parts)


@dataclass(frozen=True)
class AutoSysSettings:
    base_url_template: str
    verify_ssl: bool
    ca_bundle_path: str | None
    timeout_seconds: int
    request_delay_seconds: float
    max_retries: int
    retry_backoff_seconds: float
    retry_backoff_max_seconds: float
    honor_retry_after: bool
    api_version: int
    timezone: str
    store_naive_local_time: bool
    api_principal_env: str = "AUTOSYS_API_USER"
    api_secret_env: str = "AUTOSYS_API_PASSWORD"

    def credentials(self) -> tuple[str, str]:
        return _required_env(self.api_principal_env), _required_env(self.api_secret_env)

    def tls_verification(self) -> bool | str:
        """Return the Requests TLS verification value.

        A configured CA bundle is preferred over the container default trust
        store. The application fails closed when the configured file is not
        present or cannot be read.
        """
        if not self.verify_ssl:
            return False
        if not self.ca_bundle_path:
            return True

        certificate = Path(self.ca_bundle_path)
        if not certificate.is_file():
            raise ConfigurationError(
                f"AEWS CA bundle was not found: {certificate}"
            )
        if not os.access(certificate, os.R_OK):
            raise ConfigurationError(
                f"AEWS CA bundle is not readable: {certificate}"
            )
        return str(certificate)


@dataclass(frozen=True)
class DatabaseSettings:
    connection_string_env: str
    discovery_stored_procedure: str
    update_stored_procedure: str
    summary_stored_procedure: str
    stream_stored_procedure: str
    job_name_column: str
    instance_column: str

    @property
    def quoted_discovery_stored_procedure(self) -> str:
        return quote_sql_object_name(self.discovery_stored_procedure)

    @property
    def quoted_update_stored_procedure(self) -> str:
        return quote_sql_object_name(self.update_stored_procedure)

    @property
    def quoted_summary_stored_procedure(self) -> str:
        return quote_sql_object_name(self.summary_stored_procedure)

    @property
    def quoted_stream_stored_procedure(self) -> str:
        return quote_sql_object_name(self.stream_stored_procedure)

    def connection_string(self) -> str:
        return _required_env(self.connection_string_env)


@dataclass(frozen=True)
class IngestionSettings:
    output_directory: str
    log_directory: str
    file_output_enabled: bool
    abort_on_job_error: bool
    require_minimum_target_count: int | None


@dataclass(frozen=True)
class Settings:
    autosys: AutoSysSettings
    database: DatabaseSettings
    ingestion: IngestionSettings


def _load_yaml(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle) or {}
    if not isinstance(value, dict):
        raise ConfigurationError("Configuration root must be a YAML mapping")
    return value


def load_settings(path: str | Path) -> Settings:
    raw = _load_yaml(path)
    a = raw.get("autosys", {})
    d = raw.get("database", {})
    i = raw.get("ingestion", {})

    autosys = AutoSysSettings(
        base_url_template=str(
            a.get(
                "base_url_template",
                "https://{instance}-autosyswebapi.wellsfargo.com/AEWS",
            )
        ),
        verify_ssl=bool(a.get("verify_ssl", True)),
        ca_bundle_path=(
            str(a["ca_bundle_path"]).strip()
            if a.get("ca_bundle_path")
            else None
        ),
        timeout_seconds=int(a.get("timeout_seconds", 120)),
        request_delay_seconds=float(a.get("request_delay_seconds", 0.2)),
        max_retries=int(a.get("max_retries", 3)),
        retry_backoff_seconds=float(a.get("retry_backoff_seconds", 1.0)),
        retry_backoff_max_seconds=float(a.get("retry_backoff_max_seconds", 30.0)),
        honor_retry_after=bool(a.get("honor_retry_after", True)),
        api_version=int(a.get("api_version", 3)),
        timezone=str(a.get("timezone", "America/New_York")),
        store_naive_local_time=bool(a.get("store_naive_local_time", True)),
        api_principal_env=str(a.get("api_principal_env", "AUTOSYS_API_USER")),
        api_secret_env=str(a.get("api_secret_env", "AUTOSYS_API_PASSWORD")),
    )

    database = DatabaseSettings(
        connection_string_env=str(
            d.get("connection_string_env", "SQLSERVER_CONNECTION_STRING")
        ),
        discovery_stored_procedure=str(
            d.get("discovery_stored_procedure", "dbo.cp_Get_Critical_Batch_Jobs")
        ),
        update_stored_procedure=str(
            d.get("update_stored_procedure", "dbo.cp_Update_Job_Execution_Status")
        ),
        summary_stored_procedure=str(
            d.get(
                "summary_stored_procedure",
                "dbo.cp_Update_Critical_Batch_Summary",
            )
        ),
        stream_stored_procedure=str(
            d.get(
                "stream_stored_procedure",
                "dbo.cp_Update_Critical_Batch_Stream",
            )
        ),
        job_name_column=str(d.get("job_name_column", "job_name")),
        instance_column=str(d.get("instance_column", "scheduler_instance")),
    )
    database.quoted_discovery_stored_procedure
    database.quoted_update_stored_procedure
    database.quoted_summary_stored_procedure
    database.quoted_stream_stored_procedure
    if autosys.request_delay_seconds < 0:
        raise ConfigurationError("request_delay_seconds cannot be negative")
    if autosys.max_retries < 0:
        raise ConfigurationError("max_retries cannot be negative")
    if autosys.retry_backoff_seconds < 0 or autosys.retry_backoff_max_seconds < 0:
        raise ConfigurationError("Retry backoff values cannot be negative")
    for column in (database.job_name_column, database.instance_column):
        if not _IDENTIFIER.fullmatch(column):
            raise ConfigurationError(f"Unsafe stored procedure output column: {column!r}")

    minimum = i.get("require_minimum_target_count")
    ingestion = IngestionSettings(
        output_directory=str(i.get("output_directory", "output")),
        log_directory=str(i.get("log_directory", "logs")),
        file_output_enabled=bool(i.get("file_output_enabled", True)),
        abort_on_job_error=bool(i.get("abort_on_job_error", True)),
        require_minimum_target_count=int(minimum) if minimum is not None else None,
    )
    return Settings(autosys=autosys, database=database, ingestion=ingestion)
