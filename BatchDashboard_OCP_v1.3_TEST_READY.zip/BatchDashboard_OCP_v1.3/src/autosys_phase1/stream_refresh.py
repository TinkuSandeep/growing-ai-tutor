from __future__ import annotations

import argparse
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

from .config import load_settings
from .database import SQLServerRepository


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Refresh critical batch stream status, completion and SLA values"
    )
    parser.add_argument("--settings", default="config/settings.yaml")
    parser.add_argument("--env-file", default=".env")
    return parser.parse_args()


def _json_default(value: Any):
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(type(value).__name__)


def _configure_logging(log_path: Path | None) -> logging.Logger:
    logger = logging.getLogger("batch_dashboard_stream_refresh")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    if log_path is not None:
        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    return logger


def main() -> int:
    args = _arguments()
    load_dotenv(args.env_file, override=False)
    settings = load_settings(args.settings)

    timezone = ZoneInfo(settings.autosys.timezone)
    started = datetime.now(timezone)
    stamp = started.strftime("%Y%m%d_%H%M%S_%f")
    report_path: Path | None = None
    log_path: Path | None = None
    if settings.ingestion.file_output_enabled:
        output_dir = Path(settings.ingestion.output_directory)
        log_dir = Path(settings.ingestion.log_directory)
        output_dir.mkdir(parents=True, exist_ok=True)
        log_dir.mkdir(parents=True, exist_ok=True)
        report_path = output_dir / f"stream_refresh_{stamp}.json"
        log_path = log_dir / f"stream_refresh_{stamp}.log"
    logger = _configure_logging(log_path)

    procedure = settings.database.stream_stored_procedure
    logger.info("Starting stream refresh through %s", procedure)
    error: str | None = None
    try:
        SQLServerRepository(settings.database).refresh_stream()
        logger.info("Committed stream refresh through %s", procedure)
    except Exception as exc:
        error = str(exc)
        logger.error("STREAM REFRESH FAILED error=%s", error)

    completed = datetime.now(timezone)
    result = "STREAM_REFRESH_PASSED" if error is None else "STREAM_REFRESH_FAILED"
    report = {
        "version": "1.3.0",
        "result": result,
        "stored_procedure": procedure,
        "started_at_et": started,
        "completed_at_et": completed,
        "stream_database_updated": error is None,
        "error": error,
    }
    if report_path is not None:
        report_path.write_text(
            json.dumps(report, indent=2, default=_json_default), encoding="utf-8"
        )
        logger.info("Report written to %s", report_path)
        logger.info("Log written to %s", log_path)
    print(
        json.dumps(
            {
                "result": result,
                "stored_procedure": procedure,
                "stream_database_updated": error is None,
                "error": error,
                "report": str(report_path) if report_path is not None else None,
                "log": str(log_path) if log_path is not None else None,
            },
            indent=2,
        )
    )
    return 0 if error is None else 1


if __name__ == "__main__":
    raise SystemExit(main())
