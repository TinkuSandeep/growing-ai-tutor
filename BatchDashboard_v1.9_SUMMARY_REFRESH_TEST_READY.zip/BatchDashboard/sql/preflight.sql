-- Run using the same database identity configured for the application.

EXEC dbo.cp_Get_Critical_Batch_Jobs;

-- Confirm the result contains exact column names:
--   job_name
--   scheduler_instance
-- and contains AutoSys jobs only.

SELECT
    OBJECT_ID(N'dbo.cp_Get_Critical_Batch_Jobs', N'P') AS discovery_procedure_id,
    OBJECT_ID(N'dbo.cp_UpdateJobExecutionStatus', N'P') AS update_procedure_id,
    OBJECT_ID(N'dbo.cp_Update_Critical_Batch_Summary', N'P') AS summary_procedure_id;

SELECT
    HAS_PERMS_BY_NAME(N'dbo.cp_Get_Critical_Batch_Jobs', N'OBJECT', N'EXECUTE')
        AS can_execute_discovery,
    HAS_PERMS_BY_NAME(N'dbo.cp_UpdateJobExecutionStatus', N'OBJECT', N'EXECUTE')
        AS can_execute_update,
    HAS_PERMS_BY_NAME(N'dbo.cp_Update_Critical_Batch_Summary', N'OBJECT', N'EXECUTE')
        AS can_execute_summary_refresh;

-- Run this only during an approved validation window. It refreshes the live
-- summary table using database-owned business logic.
-- EXEC dbo.cp_Update_Critical_Batch_Summary;
