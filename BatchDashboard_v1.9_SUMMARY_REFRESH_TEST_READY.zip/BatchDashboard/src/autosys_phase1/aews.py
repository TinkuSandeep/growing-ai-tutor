from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import quote

import requests
from requests.adapters import HTTPAdapter
from requests.auth import HTTPBasicAuth
from urllib3.util.retry import Retry

from .config import AutoSysSettings
from .errors import AEWSError
from .models import TargetJob


class RuntimeSource(Protocol):
    def get_job_runs(self, target: TargetJob) -> Any: ...


class AEWSClient:
    """Read-only AutoSys Web Services client."""

    def __init__(self, settings: AutoSysSettings):
        self.settings = settings
        principal, secret = settings.credentials()
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(principal, secret)
        self.session.headers.update({"Accept": "application/json"})
        retry = Retry(
            total=3,
            connect=3,
            read=3,
            backoff_factor=0.5,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET"}),
            raise_on_status=False,
        )
        self.session.mount("https://", HTTPAdapter(max_retries=retry))

    def _base_url(self, instance: str) -> str:
        template = self.settings.base_url_template
        try:
            value = template.format(instance=instance.lower(), INSTANCE=instance.upper())
        except KeyError as exc:
            raise AEWSError(f"Unknown placeholder in base_url_template: {exc}") from exc
        return value.rstrip("/")

    def get_job_runs(self, target: TargetJob) -> Any:
        url = f"{self._base_url(target.instance)}/job-run-info/{quote(target.job_name, safe='')}"
        params = {"version": self.settings.api_version, "verbose": 1}
        try:
            response = self.session.get(
                url,
                params=params,
                timeout=self.settings.timeout_seconds,
                verify=self.settings.verify_ssl,
            )
        except requests.RequestException as exc:
            raise AEWSError(f"AEWS request failed for {target.job_name}: {exc}") from exc

        if response.status_code != 200:
            body = response.text[:300].replace("\n", " ")
            raise AEWSError(
                f"AEWS returned HTTP {response.status_code} for {target.job_name}: {body}"
            )
        try:
            return response.json()
        except ValueError as exc:
            raise AEWSError(f"AEWS returned non-JSON data for {target.job_name}") from exc

    def health_check(self, instance: str) -> None:
        url = f"{self._base_url(instance)}/job"
        response = self.session.get(
            url,
            params={"count": 1, "version": self.settings.api_version},
            timeout=self.settings.timeout_seconds,
            verify=self.settings.verify_ssl,
        )
        if response.status_code != 200:
            raise AEWSError(f"AEWS health check returned HTTP {response.status_code} for {instance}")


class MockAEWSClient:
    def __init__(self, fixture_path: str | Path):
        with Path(fixture_path).open("r", encoding="utf-8") as handle:
            self.payload = json.load(handle)

    def get_job_runs(self, target: TargetJob) -> Any:
        key = f"{target.instance}:{target.job_name}"
        if key not in self.payload:
            raise AEWSError(f"Mock fixture has no entry for {key}")
        return self.payload[key]

