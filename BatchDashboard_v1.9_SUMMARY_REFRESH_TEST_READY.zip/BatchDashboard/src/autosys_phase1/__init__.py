"""Standalone Phase 1 AutoSys runtime ingestion application."""

__version__ = "1.9.0"
