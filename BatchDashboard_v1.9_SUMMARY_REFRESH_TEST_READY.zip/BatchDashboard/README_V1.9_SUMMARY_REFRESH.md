# v1.9 Summary Refresh Release Notes

## Purpose

Version 1.9 adds the second AutoSys step requested by the Batch Dashboard team.
It refreshes `dbo.cp_critical_batch_summary` only after the existing AEWS
ingestion completes successfully.

## Database contract

The configured service identity requires `EXECUTE` permission on:

- `dbo.cp_Get_Critical_Batch_Jobs`
- `dbo.cp_UpdateJobExecutionStatus`
- `dbo.cp_Update_Critical_Batch_Summary`

The discovery procedure must return `job_name` and `scheduler_instance`.
The summary procedure is parameterless and owns all summary business logic,
including the `not_started` column and any database-calculated statistics.

## AutoSys contract

- Job 1 runs `scripts\run_prod_write.bat`.
- Job 2 runs `scripts\run_summary_refresh.bat`.
- Job 2 has the condition
  `s(BATCH_DASHBOARD_AUTOSYS_RUNTIME_INGESTION)`.
- A failure in Job 1 prevents Job 2 from refreshing the summary with incomplete
  source data.

Replace the sample job names, execution machine, owner and approved install
path in `autosys_two_job_flow.jil.example` before deployment.
