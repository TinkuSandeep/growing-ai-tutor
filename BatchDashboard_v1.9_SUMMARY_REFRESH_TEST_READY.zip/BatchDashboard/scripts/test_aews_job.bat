@echo off
setlocal
cd /d "%~dp0.."
if "%~1"=="" (
  echo Usage: scripts\test_aews_job.bat INSTANCE EXACT_JOB_NAME
  exit /b 2
)
if "%~2"=="" (
  echo ERROR: Exact AutoSys job name is required.
  exit /b 2
)
set "PYTHONPATH=%CD%\src"
set "PYTHON_EXE=%CD%\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"
"%PYTHON_EXE%" -m autosys_phase1.aews_check --instance "%~1" --job "%~2"
exit /b %errorlevel%
