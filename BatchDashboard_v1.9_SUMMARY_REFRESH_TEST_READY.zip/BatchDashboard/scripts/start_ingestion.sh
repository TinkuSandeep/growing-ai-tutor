#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD/src"
exec python -m autosys_phase1.source_check --write
