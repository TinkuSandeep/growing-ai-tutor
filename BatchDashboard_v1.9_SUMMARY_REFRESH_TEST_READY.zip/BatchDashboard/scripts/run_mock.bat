@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%\src"
set "PYTHON_EXE=%CD%\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"
"%PYTHON_EXE%" -m autosys_phase1.source_check ^
  --mock-targets config\mock_targets.json ^
  --mock-aews config\mock_job_runs.json
exit /b %errorlevel%
