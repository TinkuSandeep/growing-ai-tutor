Batch Dashboard v1.9 - Production Deployment
============================================

1. Confirm database objects
   - dbo.cp_Get_Critical_Batch_Jobs exists.
   - It returns job_name and scheduler_instance for AutoSys jobs only.
   - RTO and SAPBI activity-table jobs have been removed from the POC catalog.
   - dbo.cp_UpdateJobExecutionStatus accepts:
       @job_name, @job_start_time, @job_end_time, @job_status
   - dbo.cp_Update_Critical_Batch_Summary exists and accepts no parameters.
   - Summary schema/procedures use not_started rather than jobs_waiting.

2. Configure access
   - AEWS service identity: read access to every returned AutoSys instance.
   - Database service identity: EXECUTE on all three approved procedures:
       dbo.cp_Get_Critical_Batch_Jobs
       dbo.cp_UpdateJobExecutionStatus
       dbo.cp_Update_Critical_Batch_Summary
   - Do not grant source-table or target-table access when procedure execution is sufficient.

3. Install
   python -m venv venv
   venv\Scripts\python.exe -m pip install -r requirements-sqlserver.txt
   copy .env.example .env

4. Validate
   scripts\run_mock.bat
   scripts\run_prod_dry_run.bat

5. Controlled write
   scripts\run_prod_write.bat

6. Verify
   - All discovered jobs show PASSED.
   - target_rows_updated equals requested.
   - Dashboard start, end and status values match AEWS.
   - Logs and JSON reports were generated.

7. Validate summary refresh manually
   scripts\run_summary_refresh.bat

   Confirm:
   - result is SUMMARY_REFRESH_PASSED.
   - summary_database_updated is true.
   - dbo.cp_critical_batch_summary contains current counts.
   - the renamed not_started value is populated as expected.

8. Schedule two AutoSys jobs
   - Job 1 calls scripts\run_prod_write.bat every five minutes.
   - Job 2 calls scripts\run_summary_refresh.bat only after Job 1 succeeds.
   - Use autosys_two_job_flow.jil.example as the starting template.
   - Capture return codes, standard output and standard error for both jobs.
