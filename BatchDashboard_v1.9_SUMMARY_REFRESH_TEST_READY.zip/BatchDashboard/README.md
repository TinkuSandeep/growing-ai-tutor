# Batch Dashboard AutoSys Runtime Ingestion v1.9

This release is **AutoSys-only**, **stored-procedure driven**, and includes a
separate database summary-refresh job.

## What changed in v1.9

- Retained the validated v1.8 ingestion flow and four-parameter runtime update.
- Changed the discovery instance column to `scheduler_instance`.
- Added a separate summary command that executes
  `dbo.cp_Update_Critical_Batch_Summary`.
- Added `scripts\run_summary_refresh.bat` for the second AutoSys job.
- Added a two-job JIL example with a success dependency.
- The Python layer does not calculate `not_started`, averages, SLA or other
  dashboard statistics; the summary procedure owns that business logic.

## Existing design retained from v1.8

- Removed SAPBI, RTO activity-table and SQL_ACTIVITY source code.
- Removed `source_jobs.yaml`; production job names are not stored in code or YAML.
- Removed Python calculations for averages, SLA and baseline runs.
- Added dynamic job discovery through `dbo.cp_Get_Critical_Batch_Jobs`.
- Python uses only `job_name` and `scheduler_instance` from that result set.
- Added multi-instance AEWS routing from the returned instance value.
- Restored the four-parameter `dbo.cp_UpdateJobExecutionStatus` call.
- Added CREEP CTR/MIL offline examples; no production job name is hard-coded.

## Production flow

1. Connect to the Batch Dashboard database using `SQLSERVER_CONNECTION_STRING`.
2. Execute `dbo.cp_Get_Critical_Batch_Jobs`.
3. Read only `job_name` and `scheduler_instance` from every returned row.
4. Build the AEWS URL from each instance, such as PB3 or PC3.
5. Retrieve the latest AutoSys run in JSON format.
6. Normalize start time, end time and status to the dashboard contract.
7. In write mode, call `dbo.cp_UpdateJobExecutionStatus` once per job.
8. Commit all updates together; roll back the complete cycle on a write failure.
9. Write a JSON report under `output` and a text log under `logs`.

The Python layer contains no SLA, average-time or dashboard business logic. Those
rules belong to the database/dashboard layer.

## Required discovery procedure columns

`dbo.cp_Get_Critical_Batch_Jobs` must return:

- `job_name`: exact AutoSys job name.
- `scheduler_instance`: AutoSys instance such as PB3, PC3, PG3, PA3, DB3, DC3, UB3 or UC3.

Other returned columns are ignored. If the DBA uses a different column name,
change only `job_name_column` or `instance_column` in `config/settings.yaml`.

## Two-job production sequence

1. AutoSys runs `scripts\run_prod_write.bat`.
2. The first job discovers jobs, collects AEWS data and commits individual
   runtime updates through `dbo.cp_UpdateJobExecutionStatus`.
3. Only when the first job exits successfully, AutoSys runs
   `scripts\run_summary_refresh.bat`.
4. The second job executes `dbo.cp_Update_Critical_Batch_Summary` and commits
   the database-owned summary refresh.
5. If ingestion fails, the summary job does not run and the prior consistent
   summary remains available.

## First-time setup

```bat
python -m venv venv
venv\Scripts\python.exe -m pip install -r requirements-sqlserver.txt
copy .env.example .env
```

Populate `.env` using the approved service identities. Never commit `.env`.

## Test order

```bat
scripts\run_mock.bat
scripts\run_prod_dry_run.bat
scripts\run_prod_write.bat
scripts\run_summary_refresh.bat
```

- `run_mock.bat`: no network or database access and no write.
- `run_prod_dry_run.bat`: calls the discovery procedure and AEWS, but does not update the dashboard.
- `run_prod_write.bat`: performs discovery, AEWS collection and the target procedure calls.
- `run_summary_refresh.bat`: calls only the summary procedure; schedule it as
  the dependent second AutoSys job, not as part of the ingestion command.

To test one AutoSys job directly:

```bat
scripts\test_aews_job.bat PB3 EXACT_AUTOSYS_JOB_NAME
```

## Production safety

- Mock data cannot be used with `--write`.
- Zero discovery rows fail the execution.
- Duplicate job names fail before any AEWS call because the update procedure identifies rows by name.
- By default, one AEWS failure blocks the complete target write.
- All target updates use bound SQL parameters and a single database transaction.
- The summary refresh is committed in its own transaction and returns a
  non-zero exit code on failure so AutoSys can alert correctly.
